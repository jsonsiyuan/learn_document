package com.beacons.demo;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.Date;
import java.util.List;

public class MainActivity extends ActionBarActivity
{
    final private static int BT_REQUEST_ID = 1;
    final private BeaconsAdapter mAdapter = new BeaconsAdapter();
    final private Handler mHandler = new Handler();
    final private static long VALIDATION_PERIOD = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView tmpListView = (ListView) findViewById(R.id.list_view);
        tmpListView.setAdapter(mAdapter);

        initializeCallback();
    }

    @Override
    protected void onResume() {
        super.onResume();
        startScanning();
        startValidating();
    }

    @Override
    protected void onPause() {
        stopScanning();
        stopValidating();
        super.onPause();
    }

    private void requestForBluetooth() {
        Intent request = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(request, BT_REQUEST_ID);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BT_REQUEST_ID) {
            if (isBluetoothAvailableAndEnabled()) {
                startScanning();
            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void startScanning() {
        if (!isBluetoothAvailableAndEnabled()) {
            requestForBluetooth();
            return;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            mBtAdapter.startLeScan(mLeOldCallback);
        }
        else {
            BluetoothLeScanner scanner = mBtAdapter.getBluetoothLeScanner();
            if (scanner != null) {
                ScanSettings settings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .setReportDelay(0)
                        .build();

                scanner.startScan(null, settings, mLeNewCallback);
            }
        }
    }

    private void stopScanning() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            mBtAdapter.stopLeScan(mLeOldCallback);
        }
        else {
            BluetoothLeScanner scanner = mBtAdapter.getBluetoothLeScanner();
            if (scanner != null) {
                scanner.stopScan(mLeNewCallback);
            }
        }
    }

    private void startValidating() {
        mHandler.postDelayed(periodicValidationTask, VALIDATION_PERIOD);
    }

    private void stopValidating() {
        mHandler.removeCallbacks(periodicValidationTask);
    }

    private final Runnable periodicValidationTask = new Runnable() {
        @Override
        public void run() {
            if (mAdapter.validateAllBeacons()) {
                mAdapter.notifyDataSetChanged();
            }
            // add it again to queue:
            startValidating();
        }
    };

    private BluetoothAdapter mBtAdapter = null;
    private boolean isBluetoothAvailableAndEnabled() {
        BluetoothManager btManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        mBtAdapter = btManager.getAdapter();
        return mBtAdapter != null && mBtAdapter.isEnabled();
    }

    private BluetoothAdapter.LeScanCallback mLeOldCallback = null;
    private ScanCallback mLeNewCallback = null;

    private void initializeCallback() {
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            mLeOldCallback = new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
                    handleNewBeaconDiscovered(device, rssi, scanRecord);
                }
            };
        }
        else {
            mLeNewCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                    {
                        if (result.getScanRecord() == null ||
                            result.getScanRecord().getBytes() == null) {
                            return;
                        }

                        handleNewBeaconDiscovered(
                                result.getDevice(),
                                result.getRssi(),
                                result.getScanRecord().getBytes());
                    }
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    for(final ScanResult result : results) {
                        onScanResult(0, result);
                    }
                }
            };
        }
    }

    private void handleNewBeaconDiscovered(final BluetoothDevice device,
                                           final int rssi,
                                           final byte[] advertisement)
    {
        if (!BeaconModel.isAltBeacon(advertisement)) return;

        final BeaconModel beaconToAdd;
        BeaconModel beacon = mAdapter.findBeaconWithId(device.getAddress());
        if (beacon == null) {
            // new item
            beacon = new BeaconModel();
            beacon.updateFrom(device, rssi, advertisement);
            beaconToAdd = beacon;
        }
        else {
            // we have that in the list.. just update and notify adapter about changes
            beaconToAdd = null;
            beacon.rssi = rssi;
            beacon.timestamp = new Date().getTime();
        }

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (beaconToAdd != null) {
                    mAdapter.addNewBeacon(beaconToAdd);
                }
                else {
                    // just notify about changes in underlying data
                    mAdapter.notifyDataSetChanged();
                }
            }
        });
    }
}
