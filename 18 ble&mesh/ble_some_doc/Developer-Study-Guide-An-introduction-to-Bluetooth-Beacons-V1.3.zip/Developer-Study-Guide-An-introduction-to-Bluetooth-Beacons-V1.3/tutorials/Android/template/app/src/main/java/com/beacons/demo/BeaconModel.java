package com.beacons.demo;

import android.bluetooth.BluetoothDevice;

import java.util.Date;

public class BeaconModel
{

}
