//
//  ViewController.swift
//  demo
//
//  Created by RenKai on 2019/8/5.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

import UIKit
import CoreBluetooth

class ViewController: UITableViewController, CBCentralManagerDelegate {
    private var beacons:NSMutableArray = NSMutableArray()
    private var bleManager: CBCentralManager?
    private var timer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        beacons = []
        
        bleManager = CBCentralManager(delegate: self, queue: nil)

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        timer?.invalidate()
        timer = nil
        stopScanning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        startScanning()
        timer = Timer.scheduledTimer(timeInterval: 2.5 /* 2.5 [seconds] */,
            target: self,
            selector: #selector(ViewController.repeatableValidationTask(_:)),
            userInfo: nil,
            repeats: true)
        timer?.fire()

    }


    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            startScanning()
        } else {
            stopScanning()
        }
    }
    
    func startScanning() {
        bleManager?.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
    }
    
    func stopScanning() {
        bleManager?.stopScan()
    }
    
    let BEACON_CODE_INDEX: Int = 2
    let BEACON_CODE_VALUE: Int = 0xbeac
    let UUID_START: Int = 4
    let UUID_STOP: Int = 19
    let CONTENT_START: Int = 20
    let REFERENCE_RSSI_START: Int = 24
    
    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any],
                        rssi: NSNumber) {
        // reporting callback
        let data = advertisementData[CBAdvertisementDataManufacturerDataKey] as? Data
        if data == nil {
            return
        }
        
        let bytes = [UInt8](data!)
        
        let code:UInt16 = UInt16(bytes[BEACON_CODE_INDEX]) << 8 | UInt16(bytes[BEACON_CODE_INDEX + 1])
        
        if code != BEACON_CODE_VALUE {
            return
        }
        
        //get beacon id
        let beaconId = peripheral.identifier.uuidString
        
        var beacon: BeaconModel?
        for tmp in beacons {
            beacon = (tmp as! BeaconModel)
            if beacon!.beaconId == beaconId {
                //beacon = test
                break
            }
        }
        if beacon == nil {
            // reported for the first time - create new model
            beacon = BeaconModel()
            beacon?.beaconId = beaconId
            beacon?.referenceRssi = (Int(bytes[REFERENCE_RSSI_START]) & 0xff) - 256
            beacon?.arg1 = Int16(((Int(bytes[CONTENT_START]) << 8) & 0x0000ff00) | (Int((bytes[CONTENT_START + 1])) & 0x000000ff))
            beacon?.arg2 = Int16(((Int(bytes[CONTENT_START + 2]) << 8) & 0x0000ff00) | (Int((bytes[CONTENT_START + 3])) & 0x000000ff))
            beacon?.uuid = getBeaconUuid(fromAdvertisement: bytes)!
            
            beacons.add(beacon!)
        }
        // update current RSSI field and timestamp
        beacon?.currentRssi = rssi.intValue
        beacon?.timestamp = NSNumber(value: Date().timeIntervalSince1970).intValue
        
        tableView.reloadData()
        
    }

    func getBeaconUuid(fromAdvertisement adv:[UInt8] ) -> String? {
        var val = ""
        var i = UUID_START, offset = 0
        while i <= UUID_STOP {
            val += String(format: "%02x", Int(adv[i] ?? 0) & 0x000000ff)
            if offset == 3 || offset == 5 || offset == 7 || offset == 9 {
                val += "-"
            }
            i += 1
            offset += 1
        }
        return val
    }

    let BEACON_DURATION = Int(8.5) // 8.5 [seconds]
    
    func validateBeacons() -> Bool {
        var anythingWasRemoved = false
        let earliestTimestampAllowed: Int = NSNumber(value: Date().timeIntervalSince1970).intValue - BEACON_DURATION
        
        
        let newArray = NSMutableArray.init(capacity: beacons.count)
        for tmp in beacons {
            let beacon:BeaconModel = tmp as! BeaconModel
            if beacon.timestamp >= earliestTimestampAllowed {
                newArray.add(beacon)
            }
            else{
                anythingWasRemoved = true
            }
        }
        
        if (anythingWasRemoved) {
            //newArray.setArray(beacons as! [Any])
            beacons.setArray(newArray as! [Any])
        }
        
        return anythingWasRemoved;
    }

    @objc func repeatableValidationTask(_ theTimer: Timer?) {
        if validateBeacons() {
            tableView.reloadData()
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return beacons.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "BeaconItemCell"
        
        let cell:UITableViewCell = tableView .dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        
        let beacon:BeaconModel = beacons[indexPath.row] as! BeaconModel
        
        cell.textLabel?.text = beacon.uuid
        cell.detailTextLabel!.text = "arg1:\(beacon.arg1) arg2:\(beacon.arg2), RSSI:\(beacon.currentRssi), TxPower:\(beacon.referenceRssi)"
        
        return cell
    }

    

}

