//
//  BeaconModel.swift
//  demo
//
//  Created by RenKai on 2019/8/6.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

import Foundation

public class BeaconModel: NSObject {
    var uuid = ""
    var arg1: Int16 = 0
    var arg2: Int16 = 0
    var referenceRssi: Int = 0
    var currentRssi: Int = 0
    var beaconId:String = ""
    var timestamp: Int = 0
}

