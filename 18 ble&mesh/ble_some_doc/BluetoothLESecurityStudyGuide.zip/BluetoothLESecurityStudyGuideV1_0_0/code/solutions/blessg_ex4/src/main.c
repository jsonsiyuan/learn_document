#include <zephyr/types.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <misc/printk.h>
#include <misc/byteorder.h>
#include <zephyr.h>
#include <device.h>
#include <gpio.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/conn.h>
#include <bluetooth/uuid.h>
#include <bluetooth/gatt.h>
#include <settings/settings.h>

#include <services/custom_service.h>

// GPIO for the buttons

struct device *button_device[2];

static struct gpio_callback gpio_btnA_cb;
static struct gpio_callback gpio_btnB_cb;
static struct k_work buttonA_work;
static struct k_work buttonB_work;

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

bool authenticating = false;

struct bt_conn *default_conn;

static const struct bt_data ad[] = {
		BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
		BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static void pairing_cancel(struct bt_conn *conn)
{
	printk("Pairing cancelled\n");
	authenticating = false;
}

// will result in Just Works being used
static struct bt_conn_auth_cb pairing_cb_display = {
		.passkey_display = NULL,
		.passkey_entry = NULL,
		.cancel = pairing_cancel,
};

static void connected(struct bt_conn *conn, u8_t err)
{
	if (err)
	{
	}
	else
	{
		printk("Connected\n");
		default_conn = bt_conn_ref(conn);

		int rc = bt_conn_security(default_conn, BT_SECURITY_FIPS);
	}
}

static void disconnected(struct bt_conn *conn, u8_t reason)
{
	if (default_conn)
	{
		bt_conn_unref(default_conn);
		default_conn = NULL;
	}
}

static void security_level_changed(struct bt_conn *conn, bt_security_t level)
{
	printk("security_level_changed to %d\n", level);
}

static struct bt_conn_cb conn_callbacks = {
		.connected = connected,
		.disconnected = disconnected,
		.security_changed = security_level_changed,
};

static void bt_ready(int err)
{
	if (err)
	{
		return;
	}

	custom_service_init();

	if (IS_ENABLED(CONFIG_SETTINGS))
	{
		settings_load();
	}

	err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), NULL, 0);
	if (err)
	{
		return;
	}
}
void buttonA_work_handler(struct k_work *work)
{
	if (!authenticating)
	{
		return;
	}
	printk("User indicated YES\n");
	bt_conn_auth_passkey_confirm(default_conn);
	authenticating = false;
}

void buttonB_work_handler(struct k_work *work)
{
	if (!authenticating)
	{
		return;
	}
	printk("User indicated NO\n");
	bt_conn_auth_cancel(default_conn);
	authenticating = false;
}

void button_A_pressed(struct device *gpiob, struct gpio_callback *cb,
											u32_t pins)
{
	printk("Button A pressed\n");
	if (!authenticating)
	{
		return;
	}
	k_work_submit(&buttonA_work);
}

void button_B_pressed(struct device *gpiob, struct gpio_callback *cb,
											u32_t pins)
{
	printk("Button B pressed\n");
	k_work_submit(&buttonB_work);
}

void configureButtons(void)
{
	// Button A
	k_work_init(&buttonA_work, buttonA_work_handler);
	button_device[0] = device_get_binding(SW0_GPIO_CONTROLLER);
	gpio_pin_configure(button_device[0], SW0_GPIO_PIN,
										 (GPIO_DIR_IN | GPIO_INT | GPIO_INT_EDGE |
											GPIO_PUD_PULL_UP |
											GPIO_INT_DEBOUNCE | GPIO_INT_ACTIVE_LOW));
	gpio_init_callback(&gpio_btnA_cb, button_A_pressed, BIT(SW0_GPIO_PIN));
	gpio_add_callback(button_device[0], &gpio_btnA_cb);
	gpio_pin_enable_callback(button_device[0], SW0_GPIO_PIN);

	// Button B
	k_work_init(&buttonB_work, buttonB_work_handler);
	button_device[1] = device_get_binding(SW1_GPIO_CONTROLLER);
	gpio_pin_configure(button_device[1], SW1_GPIO_PIN,
										 (GPIO_DIR_IN | GPIO_INT | GPIO_INT_EDGE |
											GPIO_PUD_PULL_UP |
											GPIO_INT_DEBOUNCE | GPIO_INT_ACTIVE_LOW));
	gpio_init_callback(&gpio_btnB_cb, button_B_pressed, BIT(SW1_GPIO_PIN));
	gpio_add_callback(button_device[1], &gpio_btnB_cb);
	gpio_pin_enable_callback(button_device[1], SW1_GPIO_PIN);
}

void clear_all_bonds()
{

	/** Clear pairing information.
  *
  * @param id    Local identity (mostly just BT_ID_DEFAULT).
  * @param addr  Remote address, NULL or BT_ADDR_LE_ANY to clear all remote
  *              devices.
  *
  * @return 0 on success or negative error value on failure.
  */
	printk("clearing all bonds\n");
	int rc = bt_unpair(BT_ID_DEFAULT, BT_ADDR_LE_ANY);
	printk("done [%d]\n", rc);
}

void main(void)
{

	printk("starting JWLECATT\n");
	int err;
	configureButtons();
	err = bt_enable(bt_ready);
	if (err)
	{
		return;
	}

	clear_all_bonds();

	bt_conn_cb_register(&conn_callbacks);

	bt_conn_auth_cb_register(&pairing_cb_display);
}
