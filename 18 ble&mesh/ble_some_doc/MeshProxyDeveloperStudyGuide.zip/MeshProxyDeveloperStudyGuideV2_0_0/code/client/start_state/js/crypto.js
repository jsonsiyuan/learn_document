var crypto = {};

var ZERO = '00000000000000000000000000000000';
var k2_salt;
var k3_salt;
var k4_salt;
var id64_hex = utils.bytesToHex(utils.toAsciiCodes('id64'));
var id6_hex = utils.bytesToHex(utils.toAsciiCodes('id6'));



