#!/bin/bash

# Tested with Cygwin on Windows 10
#
# run with a node number in decimal with no leading zero
# e.g.
# ./install.sh 8

if [ "$#" -lt 1 ]; then
    echo "Illegal number of parameters"
    echo "usage: ./install.sh node#"
    echo "node# is mandatory and must not have a leading zero"
    echo "e.g."
    echo "./install.sh 7"
    exit 1
fi

nodex=$( printf "%02x" $1 )

cd ..

west flash --hex-file binaries/thingy_demo_$nodex.hex

cd scripts