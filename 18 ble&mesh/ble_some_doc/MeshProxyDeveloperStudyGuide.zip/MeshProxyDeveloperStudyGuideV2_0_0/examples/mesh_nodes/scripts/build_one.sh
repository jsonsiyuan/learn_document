#!/bin/bash

# Tested with Cygwin on Windows 10
#
# run with a node number in decimal with no leading zero and Y if you want the proxy feature enabling
# e.g.
# ./build_one.sh 8
# ./build_one.sh 15 Y

if [ "$#" -lt 1 ]; then
    echo "Illegal number of parameters"
    echo "usage: ./build_one.sh node#"
    echo "node# is mandatory and must not have a leading zero"
    echo "e.g."
    echo "./build_one.sh 7"
    exit 1
fi

proxy="BT_MESH_GATT_PROXY_NOT_SUPPORTED"

if [ "$#" -eq 2 ]; then
   if [ "$2" = "Y" ]; then
      proxy="BT_MESH_GATT_PROXY_ENABLED"
   fi
fi

echo $proxy 

nodex=$( printf "%02x" $1 )
Eaddr=" -e 's/ZZ/$nodex/g'"

E='sed'

i=1

for var in "$@"
do
    if [ "$i" -eq 1 ]
    then
      i=0
      E=$E$Eaddr
    fi   
done

Eaddr=" -e 's/ZZ/$nodex/g'"
E="$E ../template/main.c > ../src/main.c"
echo $E
eval $E

E='sed'
Eproxy=" -i 's/PPPPP/$proxy/g'"
E=$E$Eproxy
E="$E ../src/main.c"
echo $E
eval $E

cd ..

west build -b nrf52_pca20020

echo "build phase completed"

cp build/zephyr/zephyr.hex binaries/thingy_demo_$nodex.hex
cp build/zephyr/zephyr.elf binaries/thingy_demo_$nodex.elf

cd scripts