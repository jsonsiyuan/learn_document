#!/bin/bash

# Tested with Cygwin on Windows 10
#
# run with a start and end node number in decimal with no leading zeroes, separated by a space and Y if you want the proxy function
# e.g.
# ./build_one.sh 65 80 
# ./build_one.sh 1 16 Y 

SECONDS=0 

echo "BUILDING FOR NODES $1 to $2 INCLUSIVE"
echo

proxy="BT_MESH_GATT_PROXY_NOT_SUPPORTED"

if [ "$#" -eq 3 ]; then
   if [ "$3" = "Y" ]; then
      proxy="BT_MESH_GATT_PROXY_ENABLED"
   fi
fi

echo $proxy 

for i in $(seq $1 $2);
do
    nodex=$( printf "%02x" $i )
    echo "***************************"
    echo "*********   i  $i     *********"
    echo "********* node $nodex *********"
    echo "***************************"
    echo ""
    sed "s/ZZ/$nodex/" ../template/main.c > ../src/main.c
    E='sed'
    Eproxy=" -i 's/PPPPP/$proxy/g'"
    E=$E$Eproxy
    E="$E ../src/main.c"
    echo $E
    eval $E
    cd ..
    west build -b nrf52_pca20020
    cp build/zephyr/zephyr.hex binaries/thingy_demo_$nodex.hex
    cp build/zephyr/zephyr.elf binaries/thingy_demo_$nodex.elf
    cd scripts
done

echo "Time to build binaries: $SECONDS seconds"
