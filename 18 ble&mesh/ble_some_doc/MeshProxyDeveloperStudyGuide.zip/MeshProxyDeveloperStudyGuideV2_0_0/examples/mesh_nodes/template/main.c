/**
 * Server Node - generic onoff server and (very minimal and not compliant because I only implement one message type and no other related models) Light HSL Server.
 * For Nordic Thingy
 * 
 **/

#include <stdlib.h>
#include <logging/log.h>
#include <bluetooth/bluetooth.h>
#include <gpio.h>
#include <bluetooth/mesh.h>

LOG_MODULE_REGISTER(app);

// GPIO for the Thingy LED controller
struct device *led_ctrlr;

#define PORT "GPIO_P0"
#define LED_R 7
#define LED_G 5
#define LED_B 6

// states and state changes
u8_t onoff_state;
u8_t target_onoff_state;
u8_t transition_in_progress = 0;
u8_t transition_stop_requested = 0;
s64_t transition_start_timestamp;
u8_t transition_time = 0;
u32_t total_transition_duration = 0;
u8_t delay = 0;

u16_t hsl_lightness;
u16_t hsl_hue;
u16_t hsl_saturation;
u16_t target_hsl_lightness;
u16_t target_hsl_hue;
u16_t target_hsl_saturation;
u16_t rgb_r;
u16_t rgb_g;
u16_t rgb_b;

// addresses
u16_t remote_addr = 0;
#define NODE_NUM 0xZZ
#define NODE_ADDR 0x00ZZ
static u16_t row_group_addr;
static u16_t col_group_addr;

// security keys
static const u8_t net_key[16] = {
		0xaf, 0xc3, 0x27, 0x0e, 0xda, 0x88, 0x02, 0xf7, 0x2c, 0x1e, 0x53, 0x24, 0x38, 0xa9, 0x79, 0xeb};

static const u8_t app_key[16] = {
		0x42, 0x2b, 0xf4, 0x56, 0xf5, 0xf3, 0xe6, 0xb7, 0xc5, 0xe9, 0x00, 0x6a, 0x02, 0x2b, 0x6d, 0x8e};

static const u8_t dev_key[16] = {
		0x96, 0x4a, 0xf6, 0xfc, 0x03, 0x38, 0x8c, 0x73, 0xea, 0xff, 0x94, 0x61, 0x57, 0xff, 0x66, 0xZZ};

// device UUID
static const uint8_t dev_uuid[16] = {0x19, 0xec, 0xf3, 0x40, 0x5e, 0x08, 0xc0, 0x99, 0x0f, 0x07, 0x80, 0x25, 0x9c, 0xf7, 0x53, 0xZZ};

static const struct bt_mesh_prov prov = {
		.uuid = dev_uuid,
};

static struct k_work onoff_set_work;
static struct k_work onoff_status_work;
static struct k_work hsl_set_work;

// indexes
static const u16_t net_idx = 0;
static const u16_t app_idx = 3;
static const u32_t iv_index = 0;

// other
static u8_t flags;
static u16_t node_addr = NODE_ADDR;
static int panel_group_addr = 0xC001;

void thingy_led_on(int r, int g, int b)
{
	printk("r=%d,g=%d,b=%d\n",r,g,b);
	// LEDs on Thingy are "active low" so zero means on. Args are expressed as RGB 0-255 values so we map them to GPIO low/high.
	r = !(r / 255);
	g = !(g / 255);
	b = !(b / 255);

	gpio_pin_write(led_ctrlr, LED_R, r);
	gpio_pin_write(led_ctrlr, LED_G, g);
	gpio_pin_write(led_ctrlr, LED_B, b);
}

void thingy_led_off()
{
	gpio_pin_write(led_ctrlr, LED_R, 1);
	gpio_pin_write(led_ctrlr, LED_G, 1);
	gpio_pin_write(led_ctrlr, LED_B, 1);
}

/*
 * The following two functions were converted from the one provided in the mesh models specification, section 6.1.1 Introduction
 */

double Hue_2_RGB(double v1, double v2, double vH ) {

	// printf("Hue_2_RGB: v1=%f v2=%f vH=%f\n",v1,v2,vH);

    if ( vH < 0.0f ) {
		vH += 1.0f;
	}
    if ( vH > 1.0f ) {
		vH -= 1.0f;
	}
    if (( 6.0f * vH ) < 1.0f ) {
		return ( v1 + ( v2 - v1 ) * 6.0f * vH );
	}
    if (( 2.0f * vH ) < 1.0f ) {
		return ( v2 );
	}
    if (( 3.0f * vH ) < 2.0f ) {
		return ( v1 + ( v2 - v1 ) * ( ( 2.0f / 3.0f ) - vH ) * 6.0f );
	}
    return ( v1 );
}	

void convert_hsl_to_rgb(unsigned short hsl_h,unsigned short hsl_s,unsigned short hsl_l ) {
	// printf("hsl_h=%d hsl_s=%d hsl_l=%d\n",hsl_h,hsl_s,hsl_l);
    double H = hsl_h / 65535.0f;
    double S = hsl_s / 65535.0f;
    double L = hsl_l / 65535.0f;
	double var_1 = 0.0f;
	double var_2 = 0.0f;
	
    if ( S == 0 ) {
      rgb_r = L * 255;
      rgb_g = L * 255;
      rgb_b = L * 255;
    } else {
      if ( L < 0.5f ) {
	      var_2 = L * ( 1.0f + S );
	  } else { 
		  var_2 = ( L + S ) - ( S * L );
	  }
      var_1 = 2.0f * L - var_2;
	  
      double R = Hue_2_RGB( var_1, var_2, H + ( 1.0f / 3.0f ));
      double G = Hue_2_RGB( var_1, var_2, H );
      double B = Hue_2_RGB( var_1, var_2, H - ( 1.0f / 3.0f ));
	  
	  // printf("R=%f G=%f B=%f\n",R,G,B);
	  
	  rgb_r = 256 * R;
	  rgb_g = 256 * G;
	  rgb_b = 256 * B;
    }
}

// message opcodes
#define BT_MESH_MODEL_OP_gen_onoff_get BT_MESH_MODEL_OP_2(0x82, 0x01)
#define BT_MESH_MODEL_OP_GENERIC_ONOFF_SET BT_MESH_MODEL_OP_2(0x82, 0x02)
#define BT_MESH_MODEL_OP_GENERIC_ONOFF_SET_UNACK BT_MESH_MODEL_OP_2(0x82, 0x03)
#define BT_MESH_MODEL_OP_GENERIC_ONOFF_STATUS BT_MESH_MODEL_OP_2(0x82, 0x04)

// need to forward declare as we have circular dependencies
void generic_onoff_status(u8_t on_or_off, u16_t dest_addr, u8_t transitioning, u8_t target_on_or_off, u8_t remaining_time);

// generic onoff worker

void onoff_work_handler(struct k_work *work)
{

	if (work == &onoff_set_work)
	{

		onoff_state = target_onoff_state;
		transition_in_progress = 0;

		if (onoff_state == 0)
		{
			thingy_led_off();
		}
		else
		{
			thingy_led_on(rgb_r,rgb_g,rgb_b);
		}
		return;
	}

	if (work == &onoff_status_work)
	{
		generic_onoff_status(onoff_state, remote_addr, 0, 0, 0);
		return;
	}
}

static void set_onoff_state(struct bt_mesh_model *model, struct bt_mesh_msg_ctx *ctx, struct net_buf_simple *buf)
{
	target_onoff_state = net_buf_simple_pull_u8(buf);
	u8_t tid = net_buf_simple_pull_u8(buf);
	LOG_INF("set onoff state: onoff=%u TID=%u", target_onoff_state, tid);
	transition_time = 0;
	delay = 0;
	k_work_submit(&onoff_set_work);
}

static void generic_onoff_get(struct bt_mesh_model *model, struct bt_mesh_msg_ctx *ctx, struct net_buf_simple *buf)
{
	LOG_INF("gen_onoff_get - not implemented");
}

static void generic_onoff_set(struct bt_mesh_model *model,
															struct bt_mesh_msg_ctx *ctx,
															struct net_buf_simple *buf)
{
	LOG_INF("gen_onoff_set - not implemented");
}

static void generic_onoff_set_unack(struct bt_mesh_model *model,
																		struct bt_mesh_msg_ctx *ctx,
																		struct net_buf_simple *buf)
{
	LOG_INF("generic_onoff_set_unack");
	remote_addr = 0;
	set_onoff_state(model, ctx, buf);

}

static const struct bt_mesh_model_op generic_onoff_op[] = {
		{BT_MESH_MODEL_OP_gen_onoff_get, 0, generic_onoff_get},
		{BT_MESH_MODEL_OP_GENERIC_ONOFF_SET, 2, generic_onoff_set},
		{BT_MESH_MODEL_OP_GENERIC_ONOFF_SET_UNACK, 2, generic_onoff_set_unack},
		BT_MESH_MODEL_OP_END,
};

// model publication context
static struct bt_mesh_model_pub generic_onoff_pub;


// Light HSL Server Model - minimal subset only - would not be deemed compliant
// -------------------------------------------------------------------------------------------------------

// message opcodes
#define BT_MESH_MODEL_OP_LIGHT_HSL_SET_UNACK BT_MESH_MODEL_OP_2(0x82, 0x77)

// need to forward declare as we have circular dependencies
void generic_onoff_status(u8_t on_or_off, u16_t dest_addr, u8_t transitioning, u8_t target_on_or_off, u8_t remaining_time);

// generic onoff worker

void hsl_work_handler(struct k_work *work)
{

	transition_in_progress = 0;

    convert_hsl_to_rgb(hsl_hue,hsl_saturation,hsl_lightness);

    if (onoff_state == 1) {
		thingy_led_on(rgb_r, rgb_g, rgb_b);
	}

}

static void set_hsl_state(struct bt_mesh_model *model, struct bt_mesh_msg_ctx *ctx, struct net_buf_simple *buf)
{
	hsl_lightness = net_buf_simple_pull_le16(buf);
	hsl_hue = net_buf_simple_pull_le16(buf);
	hsl_saturation = net_buf_simple_pull_le16(buf);
	// u8_t tid = net_buf_simple_pull_u8(buf);
	LOG_INF("set HSL state: lightness=%u hue=%u saturation=%u", hsl_lightness, hsl_hue, hsl_saturation);
	transition_time = 0;
	delay = 0;
	k_work_submit(&hsl_set_work);
}


static void light_hsl_set_unack(struct bt_mesh_model *model,
             					struct bt_mesh_msg_ctx *ctx,
								struct net_buf_simple *buf)
{
	LOG_INF("light_hsl_set_unack");
	remote_addr = 0;
	set_hsl_state(model, ctx, buf);

}

static const struct bt_mesh_model_op light_hsl_op[] = {
		{BT_MESH_MODEL_OP_LIGHT_HSL_SET_UNACK, 7, light_hsl_set_unack},
		BT_MESH_MODEL_OP_END,
};

// model publication context
static struct bt_mesh_model_pub light_hsl_pub;


// Configuration Client Model
// -------------------------------------------------------------------------------------------------------
static struct bt_mesh_cfg_cli cfg_cli = {};

// -------------------------------------------------------------------------------------------------------
// Configuration Server
// --------------------
static struct bt_mesh_cfg_srv cfg_srv = {
		.relay = BT_MESH_RELAY_DISABLED,
		.beacon = BT_MESH_BEACON_DISABLED,
		.frnd = BT_MESH_FRIEND_NOT_SUPPORTED,
		.gatt_proxy = PPPPP,
		.default_ttl = 7,
		/* 3 transmissions with 20ms interval */
		.net_transmit = BT_MESH_TRANSMIT(2, 20),
};

// -------------------------------------------------------------------------------------------------------
// Health Server
// -------------
BT_MESH_HEALTH_PUB_DEFINE(health_pub, 0);
static struct bt_mesh_health_srv health_srv = {};

// -------------------------------------------------------------------------------------------------------
// Composition
// -----------

static struct bt_mesh_model sig_models[] = {
		BT_MESH_MODEL_CFG_SRV(&cfg_srv),
		BT_MESH_MODEL_CFG_CLI(&cfg_cli),
		BT_MESH_MODEL_HEALTH_SRV(&health_srv, &health_pub),
		BT_MESH_MODEL(BT_MESH_MODEL_ID_GEN_ONOFF_SRV, generic_onoff_op,
									&generic_onoff_pub, NULL),
		BT_MESH_MODEL(BT_MESH_MODEL_ID_LIGHT_HSL_SRV, light_hsl_op,
									&light_hsl_pub, NULL),
};

// node contains elements.note that BT_MESH_MODEL_NONE means "none of this type" ands here means "no vendor models"
static struct bt_mesh_elem elements[] = {
		BT_MESH_ELEM(0, sig_models, BT_MESH_MODEL_NONE),
};

// node
static const struct bt_mesh_comp comp = {
		.elem = elements,
		.elem_count = ARRAY_SIZE(elements),
};

// ----------------------------------------------------------------------------------------------------
// generic onoff status TX message producer

void generic_onoff_status(u8_t present_on_or_off, u16_t dest_addr, u8_t transitioning, u8_t target_on_or_off, u8_t remaining_time)
{
	// 2 bytes for the opcode
	// 1 bytes parameters: present onoff value
	// 2 optional bytes for target onoff and remaining time
	// 4 additional bytes for the TransMIC

	struct bt_mesh_msg_ctx ctx = {
			.net_idx = net_idx,
			.app_idx = app_idx,
			.addr = dest_addr,
			.send_ttl = BT_MESH_TTL_DEFAULT,
	};

	u8_t buflen = 7;

	NET_BUF_SIMPLE_DEFINE(msg, buflen);

	bt_mesh_model_msg_init(&msg, BT_MESH_MODEL_OP_GENERIC_ONOFF_STATUS);
	net_buf_simple_add_u8(&msg, present_on_or_off);

	if (transitioning == 1)
	{
		net_buf_simple_add_u8(&msg, target_on_or_off);
		net_buf_simple_add_u8(&msg, remaining_time);
	}

	if (bt_mesh_model_send(&sig_models[3], &ctx, &msg, NULL, NULL))
	{
		LOG_INF("Unable to send generic onoff status message");
	}

	LOG_INF("onoff status message %d sent", present_on_or_off);
}

// -------------------------------------------------------------------------------------------------------
static int selfConfigure(void)
{
	int err;
	LOG_INF("configuring...");

	/* Add Application Key */
	err = bt_mesh_cfg_app_key_add(net_idx, node_addr, net_idx, app_idx, app_key, NULL);
	if (err)
	{
		LOG_INF("ERROR adding appkey (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("added appkey");
	}

	/* Bind to generic onoff server model */
	err = bt_mesh_cfg_mod_app_bind(net_idx, node_addr, node_addr, app_idx, BT_MESH_MODEL_ID_GEN_ONOFF_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR binding to generic onoff server model (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("bound appkey to generic onoff server model");
	}

	/* Bind to Light HSL server model */
	err = bt_mesh_cfg_mod_app_bind(net_idx, node_addr, node_addr, app_idx, BT_MESH_MODEL_ID_LIGHT_HSL_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR binding to light hsl server model (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("bound appkey to light hsl server model");
	}

	/* Bind to Health model */
	err = bt_mesh_cfg_mod_app_bind(net_idx, node_addr, node_addr, app_idx, BT_MESH_MODEL_ID_HEALTH_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR binding to health server model (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("bound appkey to health server model");
	}

	// subscribe onoff server to the group addresses
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, panel_group_addr, BT_MESH_MODEL_ID_GEN_ONOFF_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing onoff server to panel group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed onoff server to panel group address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, row_group_addr, BT_MESH_MODEL_ID_GEN_ONOFF_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing onoff server to row group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed onoff server to row group address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, col_group_addr, BT_MESH_MODEL_ID_GEN_ONOFF_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing onoff server to column group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed onoff server to column group address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, node_addr, BT_MESH_MODEL_ID_GEN_ONOFF_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing onoff server to node group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed onoff server to node group address");
	}

	// subscribe light hsl server to the group addresses
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, panel_group_addr, BT_MESH_MODEL_ID_LIGHT_HSL_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing light hsl server to panel group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed light hsl server to panel group address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, row_group_addr, BT_MESH_MODEL_ID_LIGHT_HSL_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing light hsl server to row group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed light hsl server to panel row address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, col_group_addr, BT_MESH_MODEL_ID_LIGHT_HSL_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing light hsl server to column group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed light hsl server to column group address");
	}
	err = bt_mesh_cfg_mod_sub_add(net_idx, NODE_ADDR, NODE_ADDR, node_addr, BT_MESH_MODEL_ID_LIGHT_HSL_SRV, NULL);
	if (err)
	{
		LOG_INF("ERROR subscribing light hsl server to node group address (err %d)", err);
		return err;
	}
	else
	{
		LOG_INF("subscribed light hsl server to node group address");
	}

	return 0;
}


// -------------------------------------------------------------------------------------------------------
// Self Provisioning

static int selfProvision(void)
{
	// now we provision ourselves... this is not how it would normally be done!
	LOG_INF("Provisioning....");
	int err = bt_mesh_provision(net_key, net_idx, flags, iv_index, node_addr, dev_key);
	if (err)
	{
		LOG_INF("Provisioning failed (err %d)", err);
		return err;
	}
	LOG_INF("Provisioning completed");

	return 0;
}

static void bt_ready(int err)
{
	LOG_INF("entering bt_ready");
	LOG_INF("bt_enable returned %d", err);
	if (err)
	{
		LOG_INF("bt_enable init failed with err %d", err);
		return;
	}

	LOG_INF("Calling bt_mesh_init");
	err = bt_mesh_init(&prov, &comp);
	LOG_INF("bt_mesh_init return code %d", err);
	LOG_INF("Done calling bt_mesh_init");
	if (err)
	{
    	LOG_INF("Mesh stack initialisation failed!!!");
		LOG_INF("bt_mesh_init failed with err %d", err);
		return;
	}

	LOG_INF("Calling selfProvision");
	err = selfProvision();
	LOG_INF("Done calling selfProvision");
	if (err)
	{
		LOG_INF("ERROR: SELF-PROVISIONING FAILED");
	}
	else
	{
		LOG_INF("self-provisioned OK");
	}

	LOG_INF("Calling selfConfigure");
	err = selfConfigure();
	LOG_INF("Done calling selfConfigure");

	if (err)
	{
		LOG_INF("ERROR: CONFIGURATION FAILED");
	}
	else
	{
		LOG_INF("Mesh initialised OK");
	}

	LOG_INF("exiting bt_ready");

}

static void configure_thingy_led_controller()
{
	led_ctrlr = device_get_binding(PORT);
	gpio_pin_configure(led_ctrlr, LED_R, GPIO_DIR_OUT);
	gpio_pin_configure(led_ctrlr, LED_G, GPIO_DIR_OUT);
	gpio_pin_configure(led_ctrlr, LED_B, GPIO_DIR_OUT);
}

void led_test() {
	int r = 255, g = 0, b = 0;
    printk("red\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 0, g = 255, b = 0;
    printk("green\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 0, g = 0, b = 255;
    printk("blue\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 255, g = 255, b = 0;
    printk("yellow\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 0, g = 255, b = 255;
    printk("cyan\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 255, g = 0, b = 255;
    printk("magenta\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 255, g = 255, b = 255;
    printk("white\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);

    r = 0, g = 0, b = 0;
    printk("off\n");
	printk("rgb(%d,%d,%d)\n",r,g,b);
	thingy_led_on(r, g, b);
    k_sleep(5000);
}

void indicate_on() {
	int r = 255, g = 0, b = 0;
	thingy_led_on(r, g, b);
    k_sleep(1000);
    r = 0, g = 0, b = 0;
	thingy_led_on(r, g, b);	
}

void main(void)
{
	LOG_INF("thingy demo v1.0.1");

	// Row Number
	int row_num = ((int)(node_addr - 1) / 4);
	row_group_addr = 0xC010 + row_num + 1;
	// Col Number
	int col_num = ((int)(node_addr - 1) % 4);
	col_group_addr = 0xC021 + col_num;

	// panel address - only one 4 x 4 panel with the Thingy demo
	panel_group_addr = 0xC001;

	printk("panel_group_addr: 0x%04x\n", panel_group_addr);
	printk("row_group_addr  : 0x%04x\n", row_group_addr);
	printk("col_group_addr  : 0x%04x\n", col_group_addr);
	printk("node_addr: 0x%04x\n", node_addr);

	configure_thingy_led_controller();

    indicate_on();

	// set default colour to white
	rgb_r = 255;
	rgb_g = 255;
	rgb_b = 255;

    // led_test();

	// set up the workers for handling set operations
	k_work_init(&onoff_set_work, onoff_work_handler);
	k_work_init(&onoff_status_work, onoff_work_handler);
	k_work_init(&hsl_set_work, hsl_work_handler);

	LOG_INF("Calling bt_enable");
	int err = bt_enable(bt_ready);
	if (err)
	{
		LOG_INF("bt_enable failed with err %d", err);
	}


}
