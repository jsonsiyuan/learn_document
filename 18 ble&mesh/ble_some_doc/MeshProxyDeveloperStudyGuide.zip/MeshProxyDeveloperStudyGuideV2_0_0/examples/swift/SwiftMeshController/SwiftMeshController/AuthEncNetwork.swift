import Foundation

struct AuthEncNetwork {
    var enc_key : [UInt8] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    var enc_dst : [UInt8] = [0,0]
    var enc_transport_pdu : [UInt8] = [0]
    var netMIC : [UInt8] = [0,0,0,0]
}
