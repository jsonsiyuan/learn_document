import Foundation

class BluetoothMesh {
    
    static let sharedInstance = BluetoothMesh()
    var crypto: Crypto! = Crypto.sharedInstance
    var adapter: BLEAdapter! = BLEAdapter.sharedInstance
    var utils: Utils! = Utils.sharedInstance
    let userDefaults = UserDefaults.standard

    var seq_number : Int = 0
    let SEQ_KEY = "SEQ"
    
    let netkey : [UInt8] = [0xaf, 0xc3, 0x27, 0x0e, 0xda, 0x88, 0x02, 0xf7, 0x2c, 0x1e, 0x53, 0x24, 0x38, 0xa9, 0x79, 0xeb]
    var appkey : [UInt8] = [0x42, 0x2b, 0xf4, 0x56, 0xf5, 0xf3, 0xe6, 0xb7, 0xc5, 0xe9, 0x00, 0x6a, 0x02, 0x2b, 0x6d, 0x8e]

    let iv_index : [UInt8] = [0x00, 0x00, 0x00, 0x00]
    
    // encryption_key: 0x1f3c13b5bec90e54ce497f915bbe7b89
    var encryption_key : [UInt8] = []
    
    // privacy_key: 0xfdea6a4a28afdf660b5e4bc1f995d060
    var privacy_key : [UInt8] = []
    
    // network_id: 0x7a88b7c398197b01
    var network_id : [UInt8] = []
    
    var sar : UInt8 = 0
    var msg_type : UInt8 = 0
    // network PDU fields
    var ivi : UInt8 = 0
    var nid : UInt8 = 0
    var ctl : UInt8 = 0x00
    var ttl : UInt8 = 0x03
    var seq : [UInt8] = [0x00, 0x00, 0x01]
    let src : [UInt8] = [0x12, 0x35]
    var seg : UInt8 = 0
    var akf : UInt8 = 1 // means application key is in use
    var aid : UInt8 = 0
    var opcode : [UInt8] = [0x00, 0x00]
    var opparams : [UInt8] = []

    func initialise() throws {
        try crypto.initialise()
        let k2_material : K2KeyMaterial = try! crypto.k2(N : netkey, P : [0x00])
        encryption_key = k2_material.encryption_key
        print("encryption_key: "+encryption_key.toHexString())
        privacy_key = k2_material.privacy_key
        print("privacy_key: "+privacy_key.toHexString())
        nid = k2_material.NID[0]
        print("nid: "+utils.hexStringForByte(byte: nid))
        network_id = try! crypto.k3(N : netkey)
        print("network_id: "+network_id.toHexString())
        aid = try! crypto.k4(N : appkey);
        print("aid="+utils.hexStringForByte(byte: aid))
        ivi = utils.leastSignificantBit(number: iv_index[3])
        
        // restore last used sequence number
        seq_number = userDefaults.integer(forKey: SEQ_KEY)
        seq = utils.intSeqToByteArraySeq(int_seq: seq_number)
    }

    func incrementSequenceNumber() {
        seq_number = seq_number + 1
        if (seq_number > 0xFFFFFF) {
            seq_number = 0
        }
        seq = utils.intSeqToByteArraySeq(int_seq: seq_number)
        // persist
        userDefaults.set(seq_number, forKey: SEQ_KEY)
    }

    func meshAuthEncAccessPayload(key : [UInt8], nonce : [UInt8], payload : [UInt8]) -> EncAccessPayloadTransMic {
        print("meshAuthEncAccessPayload: key="+key.toHexString()+" nonce="+nonce.toHexString()+" payload="+payload.toHexString())
        var result = EncAccessPayloadTransMic()
        var ciphertext = crypto.aesccm(key : key, nonce : nonce , plaintext : payload)
        let eap = ciphertext.prefix(ciphertext.count - 4)
        let tmic = ciphertext.suffix(4)
        result.enc_access_payload = Array(eap)
        result.transMIC = Array(tmic)
        return result;
    };

    func meshAuthEncNetwork(encryption_key : [UInt8], nonce : [UInt8], dst : [UInt8], transport_pdu : [UInt8]) -> AuthEncNetwork
    {
        print("meshAuthEncNetwork: encryption_key="+encryption_key.toHexString()+" dst="+dst.toHexString()+" transport_pdu="+transport_pdu.toHexString())

        var result = AuthEncNetwork()

        let dst_plus_transport_pdu = dst + transport_pdu
        var ciphertext = crypto.aesccm(key : encryption_key, nonce : nonce , plaintext : dst_plus_transport_pdu)
        let len = ciphertext.count
        result.enc_dst = [ciphertext[0],ciphertext[1]]
        let etp = Array(ciphertext[2..<(len - 4)])
        result.enc_transport_pdu = etp
        result.netMIC = [ciphertext[len - 4],ciphertext[len - 3],ciphertext[len - 2],ciphertext[len - 1]]
        return result;
    }

    func finaliseProxyPdu(network_pdu : [UInt8]) -> [UInt8] {
        var proxy_pdu : [UInt8] = []
        let sm = (sar << 6) | msg_type;
        proxy_pdu = proxy_pdu + [sm]
        proxy_pdu = proxy_pdu + network_pdu
        return proxy_pdu;
    }
    
    func deriveSecureUpperTransportPdu(access_payload : [UInt8], dst : [UInt8]) -> EncAccessPayloadTransMic {
        print("deriveSecureUpperTransportPdu: access_payload="+access_payload.toHexString()+" dst="+dst.toHexString())
        var upper_trans_pdu : EncAccessPayloadTransMic
        // derive Application Nonce (ref 3.8.5.2)
        let app_nonce = [0x01, 0x00] + seq + src + dst + iv_index
        print("deriveSecureUpperTransportPdu: app_nonce="+app_nonce.toHexString())
        upper_trans_pdu = meshAuthEncAccessPayload(key : appkey, nonce : app_nonce, payload : access_payload)
        return upper_trans_pdu;
    }
    
    func deriveLowerTransportPdu(upper_transport_pdu : EncAccessPayloadTransMic) -> [UInt8] {
        var lower_transport_pdu : [UInt8] = []
        // seg=0 (1 bit), akf=1 (1 bit), aid (6 bits) already derived from k4
        print("seg="+utils.hexStringForByte(byte: seg)+" akf="+utils.hexStringForByte(byte: akf)+" aid="+utils.hexStringForByte(byte: aid))
        let ltpdu1 : UInt8 = (seg << 7) | (akf << 6) | aid;
        print("ltpdu1="+utils.hexStringForByte(byte: ltpdu1))
        lower_transport_pdu = [ltpdu1] + upper_transport_pdu.enc_access_payload + upper_transport_pdu.transMIC
        return lower_transport_pdu;
    }

    func deriveSecureNetworkLayer(lower_transport_pdu : [UInt8] , dst : [UInt8]) -> AuthEncNetwork {
        let ctl_ttl : UInt8 = (ctl | ttl)
        var net_nonce = [0x00] + [ctl_ttl]
        net_nonce = net_nonce + seq
        net_nonce = net_nonce + src
        net_nonce = net_nonce + [0,0]
        net_nonce = net_nonce + iv_index
        
        let authencnet = meshAuthEncNetwork(encryption_key : encryption_key, nonce : net_nonce, dst : dst, transport_pdu : lower_transport_pdu)
        return authencnet
    }
    
    func finaliseNetworkPdu(ivi : UInt8, nid : UInt8, obfuscated_ctl_ttl_seq_src : [UInt8], enc_dst : [UInt8], enc_transport_pdu : [UInt8], netmic : [UInt8]) -> [UInt8] {

        var finalised_network_pdu : [UInt8] = []
        
        let npdu1 : UInt8 = ((ivi << 7) | nid);
        finalised_network_pdu = [npdu1] + obfuscated_ctl_ttl_seq_src + enc_dst + enc_transport_pdu + netmic;

        return finalised_network_pdu
    }

    func deriveLowerLayers(access_payload : [UInt8], dst : [UInt8]) -> [UInt8] {
        // upper transport PDU
        let upper_transport_pdu_obj : EncAccessPayloadTransMic = deriveSecureUpperTransportPdu(access_payload : access_payload, dst : dst)
        let upper_transport_pdu : [UInt8] = upper_transport_pdu_obj.enc_access_payload + upper_transport_pdu_obj.transMIC
        print("upper_transport_pdu enc_access_payload="+upper_transport_pdu_obj.enc_access_payload.toHexString())
        print("upper_transport_pdu transMIC="+upper_transport_pdu_obj.transMIC.toHexString())
        print("upper_transport_pdu="+upper_transport_pdu.toHexString())

        // derive lower transport PDU
        let lower_transport_pdu : [UInt8] = deriveLowerTransportPdu(upper_transport_pdu : upper_transport_pdu_obj)
        print("lower_transport_pdu="+lower_transport_pdu.toHexString())

        // encrypt network PDU
        let auth_enc_network : AuthEncNetwork = deriveSecureNetworkLayer(lower_transport_pdu : lower_transport_pdu, dst : dst)
        print("EncDST="+auth_enc_network.enc_dst.toHexString()+" EncTransportPDU="+auth_enc_network.enc_transport_pdu.toHexString())

        // obfuscate
        let obfuscated_ctl_ttl_seq_src  : [UInt8] = crypto.obfuscate(enc_dst : auth_enc_network.enc_dst, enc_transport_pdu : auth_enc_network.enc_transport_pdu, netmic : auth_enc_network.netMIC, ctl : ctl, ttl : ttl, seq : seq, src : src, iv_index : iv_index, privacy_key : privacy_key)
        print("obfuscated_ctl_ttl_seq_src="+obfuscated_ctl_ttl_seq_src.toHexString())

        let network_pdu = finaliseNetworkPdu(ivi: ivi, nid: nid, obfuscated_ctl_ttl_seq_src: obfuscated_ctl_ttl_seq_src, enc_dst: auth_enc_network.enc_dst, enc_transport_pdu: auth_enc_network.enc_transport_pdu, netmic: auth_enc_network.netMIC)

        return network_pdu
    }
    
    func sendGenericOnOffSetUnack(dst : [UInt8] , onoff : UInt8) -> Bool {
        
        if (!adapter.connected!) {
            return false;
        }

        // access layer
        var access_payload : [UInt8] = [];
        let opcode : [UInt8] = [0x82, 0x03]
        access_payload = opcode
        access_payload = access_payload + [onoff]
        // TID
        access_payload = access_payload + [01]
        print("access payload:  "+access_payload.toHexString())

        let obfuscated_network_pdu : [UInt8] = deriveLowerLayers(access_payload : access_payload, dst : dst)
        print("obfuscated_network_pdu="+obfuscated_network_pdu.toHexString())
        
        let pdu = finaliseProxyPdu(network_pdu: obfuscated_network_pdu)
        
        print("Proxy PDU: "+pdu.toHexString())
        
        adapter.writeMeshProxyDataIn(proxy_pdu: pdu)

        incrementSequenceNumber()

        return true
    }

    func sendLightHslSetUnack(dst : [UInt8] , h : UInt16, s : UInt16, l : UInt16) -> Bool {
        
        if (!adapter.connected!) {
            return false;
        }
        
        print("H: \(h) S: \(s) L: \(l)")
        
        // access layer
        var access_payload : [UInt8] = [];
        let opcode : [UInt8] = [0x82, 0x77]
        access_payload = opcode
        access_payload = access_payload + utils.uint16ToUint8ArrayLE(sixteen_bits: l) + utils.uint16ToUint8ArrayLE(sixteen_bits: h) + utils.uint16ToUint8ArrayLE(sixteen_bits: s)
        // TID
        access_payload = access_payload + [01]
        print("access payload:  "+access_payload.toHexString())
        
        let obfuscated_network_pdu : [UInt8] = deriveLowerLayers(access_payload : access_payload, dst : dst)
        print("obfuscated_network_pdu="+obfuscated_network_pdu.toHexString())
        
        let pdu = finaliseProxyPdu(network_pdu: obfuscated_network_pdu)
        
        print("Proxy PDU: "+pdu.toHexString())
        
        adapter.writeMeshProxyDataIn(proxy_pdu: pdu)
        
        incrementSequenceNumber()
        
        return true
    }


}
