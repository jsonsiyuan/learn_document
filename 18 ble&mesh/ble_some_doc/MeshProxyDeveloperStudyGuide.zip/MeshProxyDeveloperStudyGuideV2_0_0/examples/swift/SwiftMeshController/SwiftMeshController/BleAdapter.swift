import UIKit
import CoreBluetooth

protocol ScanResultsConsumer {
    func onDeviceDiscovered(_ device: CBPeripheral)
}

protocol BluetoothOperationsConsumer {
    func onConnected()
    func onFailedToConnect(_ error: Error?)
    func onDisconnected()
    func onServicesDiscovered()
    func onMeshProxyServiceDiscovered()
    func onMeshProxyDataInDiscovered()
    func onMeshProxyDataOutDiscovered()
    func onDiscoveryFinished()
    func onMeshProxyDataOutWritten()
}

class BLEAdapter: NSObject,CBCentralManagerDelegate, CBPeripheralDelegate {
    
    var central_manager: CBCentralManager?
    var selected_peripheral: CBPeripheral?
    var peripherals: NSMutableArray = []
    var powered_on : Bool?
    var scanning: Bool?
    var connecting: Bool?
    var connected: Bool?
    var scan_results_consumer: ScanResultsConsumer?
    var required_name : String?
    var bluetooth_operations_consumer: BluetoothOperationsConsumer?
    var rssi_timer = Timer()
    
    static let sharedInstance = BLEAdapter()
    
    let MESH_PROXY_SERVICE_UUID      = "00001828-0000-1000-8000-00805f9b34fb"
    let MESH_PROXY_DATA_IN           = "00002add-0000-1000-8000-00805f9b34fb"
    let MESH_PROXY_DATA_OUT          = "00002ade-0000-1000-8000-00805f9b34fb"

    let NUM_CHARS_OF_INTEREST = 2
    
    var mesh_proxy_data_in: CBCharacteristic?
    var mesh_proxy_data_out: CBCharacteristic?

    var mesh_char_discovery_count: Int?
    
    func initBluetooth(_ device_list : DeviceListViewController)->Int
    {
        powered_on = false
        scanning = false
        connected = false
        connecting = false
        self.central_manager = CBCentralManager(delegate: self, queue: nil, options: [CBCentralManagerOptionRestoreIdentifierKey:"SBMC"])
        self.scan_results_consumer = device_list

        return 0
    }
    
    func centralManagerStateToString(_ state: CBManagerState)->[CChar]?
    {
        var returnVal = "Unknown state"
        
        if(state == CBManagerState.unknown)
        {
            returnVal = "State unknown (CBManagerStateUnknown)"
        }
        else if(state == CBManagerState.resetting)
        {
            returnVal = "State resetting (CBManagerStateUnknown)"
        }
        else if(state == CBManagerState.unsupported)
        {
            returnVal = "State BLE unsupported (CBCentralManagerStateResetting)"
        }
        else if(state == CBManagerState.unauthorized)
        {
            returnVal = "State unauthorized (CBCentralManagerStateUnauthorized)"
        }
        else if(state == CBManagerState.poweredOff)
        {
            returnVal = "State BLE powered off (CBCentralManagerStatePoweredOff)"
        }
        else if(state == CBManagerState.poweredOn)
        {
            returnVal = "State powered up and ready (CBCentralManagerStatePoweredOn)"
        }
        else
        {
            returnVal = "State unknown"
        }
        
        return (returnVal.cString(using: String.Encoding.utf8))
    }
    
    func printKnownPeripherals(){
        print("List of currently known peripherals : ");
        let count = self.peripherals.count
        if(count > 0)
        {
            for i in 0...count - 1
            {
                let p = self.peripherals.object(at: i) as! CBPeripheral
                self.printDeviceDetails(p)
            }
        }
        
    }
    
    func printDeviceDetails(_ peripheral: CBPeripheral)
    {
        print("Peripheral Info :");
        print("Name : \(String(describing: peripheral.name))")
        print("ID   : \(peripheral.identifier)")
    }
    
    // API
    
    func connect(_ result_consumer: BluetoothOperationsConsumer)
    {
        if (selected_peripheral != nil) {
            selected_peripheral?.delegate = self
            bluetooth_operations_consumer = result_consumer
            connecting = true
            central_manager?.connect(selected_peripheral!, options: nil)
        }
    }
    
    func disconnect(_ result_consumer: BluetoothOperationsConsumer)
    {
        if (selected_peripheral != nil) {
            bluetooth_operations_consumer = result_consumer
            central_manager?.cancelPeripheralConnection(selected_peripheral!)
        }
    }
    
    func discoverServices() {
        self.selected_peripheral?.discoverServices(nil)
    }
    
    func discoverCharacteristics() {
        if let services = selected_peripheral?.services {
            mesh_char_discovery_count = 0
            for service in services {
                if (service.uuid == CBUUID(string: MESH_PROXY_SERVICE_UUID)) {
                    bluetooth_operations_consumer?.onMeshProxyServiceDiscovered()
                    selected_peripheral?.discoverCharacteristics(nil, for: service)
                }
            }
        }
    }
    
    func writeMeshProxyDataIn(proxy_pdu: [UInt8]) {
        let pdu = Data(bytes: proxy_pdu)
        selected_peripheral?.writeValue(pdu, for: mesh_proxy_data_in!, type: .withoutResponse)
    }
    
    // CBCentralManagerDelegate
    func centralManager(_ central: CBCentralManager, willRestoreState dict: [String : Any]) {
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if(central.state == CBManagerState.poweredOn)
        {
            powered_on = true
            return
        }
        if(central.state == CBManagerState.poweredOff)
        {
            powered_on = false
            return
        }
    }
    
    func findDevices(_ timeout: Int, _ consumer: ScanResultsConsumer)->Int
    {
        if(self.central_manager?.state != CBManagerState.poweredOn)
        {
            print("Bluetooth is not powered on");
            return -1
        }
        
        peripherals.removeAllObjects()
        
        Timer.scheduledTimer(timeInterval: Double(timeout), target: self, selector: #selector(BLEAdapter.stopScanning(_:)), userInfo: nil, repeats: false)
        
        scanning = true
        self.central_manager?.scanForPeripherals(withServices: [CBUUID(string: MESH_PROXY_SERVICE_UUID)], options: nil)
        return 0
        
    }
    
    @objc func stopScanning(_ timer: Timer)
    {
        if (scanning == true) {
            self.central_manager?.stopScan()
            scanning = false
        }
    }
    
    func stopScanning()
    {
        if (scanning == true) {
            self.central_manager?.stopScan()
            scanning = false
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        print("Found "+peripheral.identifier.uuidString)
                var i = 0
        while i < self.peripherals.count
        {
            let p = self.peripherals.object(at: i)
            if((p as AnyObject).identifier == peripheral.identifier)
            {
                self.peripherals.replaceObject(at: i, with: peripheral)
                return
            }
            i = i + 1
        }
        // did not find device in our array so it must be a new device
        self.peripherals.add(peripheral)
        scan_results_consumer?.onDeviceDiscovered(peripheral)
        
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected")
        connected = true
        connecting = false
        bluetooth_operations_consumer?.onConnected()
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("didFailToConnect")
        bluetooth_operations_consumer?.onFailedToConnect(error)
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("Disconnected")
        connected = false
        bluetooth_operations_consumer?.onDisconnected()
    }
    
    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverServices error: Error?){
        print("didDiscoverServices")
        bluetooth_operations_consumer?.onServicesDiscovered()
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverCharacteristicsFor service: CBService,
                    error: Error?) {
        if let characteristics = service.characteristics {
            for characteristic in characteristics {
                print("service: \(service.uuid) characteristic: \(characteristic.uuid)")
                if service.uuid == CBUUID(string: MESH_PROXY_SERVICE_UUID) && characteristic.uuid == CBUUID(string: MESH_PROXY_DATA_IN) {
                    mesh_proxy_data_in = characteristic
                    print("discovered mesh proxy data in")
                    mesh_char_discovery_count = mesh_char_discovery_count! + 1
                    bluetooth_operations_consumer?.onMeshProxyDataInDiscovered()
                } else if service.uuid == CBUUID(string: MESH_PROXY_SERVICE_UUID) && characteristic.uuid == CBUUID(string: MESH_PROXY_DATA_OUT) {
                    mesh_proxy_data_out = characteristic
                    print("discovered mesh proxy data out")
                    mesh_char_discovery_count = mesh_char_discovery_count! + 1
                    bluetooth_operations_consumer?.onMeshProxyDataOutDiscovered()
                }
            }
            if (mesh_char_discovery_count == NUM_CHARS_OF_INTEREST) {
                bluetooth_operations_consumer?.onDiscoveryFinished()
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral,
                    didWriteValueFor characteristic: CBCharacteristic,
                    error: Error?){
        print("didWriteValueFor characteristic: service=\(characteristic.service.uuid.uuidString) characteristic=\(characteristic.uuid.uuidString)")
        if characteristic.service.uuid == CBUUID(string: MESH_PROXY_SERVICE_UUID) && characteristic.uuid == CBUUID(string: MESH_PROXY_DATA_IN) {
            bluetooth_operations_consumer?.onMeshProxyDataOutWritten()
        }
    }
}
