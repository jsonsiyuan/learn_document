import Foundation
import CryptoSwift

class Crypto {
    
    // uses https://github.com/krzyzanowskim/CryptoSwift
    
    static let sharedInstance = Crypto()

    var utils: Utils!

    var ZERO : [UInt8] = []
    var k2_salt : [UInt8] = []
    var k3_salt : [UInt8] = []
    var k4_salt : [UInt8] = []
    let id64 : [UInt8] = [0x69, 0x64, 0x36, 0x34]
    let id6 : [UInt8] = [0x69, 0x64, 0x36]

    func initialise() throws {
        utils = Utils.sharedInstance
        ZERO = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        var bytes = Array<UInt8>(hex: "0x736d6b32")
        k2_salt = try s1(M: bytes) // "smk2"
        bytes = Array<UInt8>(hex: "0x736d6b33")
        k3_salt = try s1(M: bytes) // "smk3"
        bytes = Array<UInt8>(hex: "0x736d6b34")
        k4_salt = try s1(M: bytes) // "smk4"
    }
    
    func getAesCmac(key : [UInt8], message : [UInt8]) throws -> [UInt8] {
        let cmac_bytes : [UInt8] = try CMAC(key: key).authenticate(message)
        return cmac_bytes
    }
    
    func s1(M : [UInt8]) throws -> [UInt8] {
        let cmac = try getAesCmac(key: ZERO, message: M);
        // result must be a hex encoded string
        return cmac
    }
    
    func k2(N : [UInt8], P : [UInt8]) throws -> K2KeyMaterial {
        var k2_material = K2KeyMaterial()
        
        // T = AES-CMACsalt (N)
        let T = try getAesCmac(key: k2_salt, message: N);
    
        let T0 : [UInt8] = [];
        //  T1 = AES-CMACt (T0 || P || 0x01)
        let M1 : [UInt8] = T0 + P + [01];
        let T1 : [UInt8] = try getAesCmac(key: T, message: M1)

        // T2 = AES-CMACt (T1 || P || 0x02)
        let M2 : [UInt8] = T1 + P + [02];
        let T2 : [UInt8] = try getAesCmac(key: T, message: M2);

        // T3 = AES-CMACt (T2 || P || 0x03)
        let M3 : [UInt8] = T2 + P + [03];
        let T3 : [UInt8] = try getAesCmac(key: T, message: M3)

        let T123 : [UInt8] = T1 + T2 + T3

//    // see https://github.com/mkrd/Swift-BigInt.git
        let TWO_POW_263 = BInt("800000000000000000000000000000000000000000000000000000000000000000",radix: 16)
        let T123_BIGINT : BInt? = BInt(utils.bytesToHex(bytes: T123),radix: 16)
        let modval = T123_BIGINT! % TWO_POW_263!;
        let modval_hex = modval.asString(radix: 16)
        
        k2_material.NID = (utils.substring(str: modval_hex, start: 0, end: 2)).hexToBytes
        k2_material.encryption_key = (utils.substring(str: modval_hex, start: 2, end: 34)).hexToBytes
        k2_material.privacy_key = (utils.substring(str: modval_hex, start: 34, end: 66)).hexToBytes
        
        return k2_material;
    };

    func k3(N : [UInt8]) throws -> [UInt8] {

        // T = AES-CMACsalt (N)
        let T = try getAesCmac(key: k3_salt, message: N);
    
        // k3(N) = AES-CMACt ( “id64” || 0x01 ) mod 2^64
        let k3_cmac = try getAesCmac(key: T, message: id64 + [01]);

        
        let k3_cmac_bigint : BInt? = BInt(utils.bytesToHex(bytes: k3_cmac),radix: 16)
        let TWO_POW_64 = BInt("10000000000000000",radix: 16)

        let k3_modval = k3_cmac_bigint! % TWO_POW_64!;
    
        return k3_modval.asString(radix: 16).hexToBytes;
    };

    func k4(N : [UInt8]) throws -> UInt8 {

        // K4(N) = AES-CMACt ( “id6” || 0x01 ) mod 2^6
        
        // T = AES-CMACsalt (N)
        let T = try getAesCmac(key: k4_salt, message: N);
        
        //  k4_cmac = crypto.getAesCmac(T.toString(), id6_hex + "01");
        let k4_cmac = try getAesCmac(key: T, message: id6 + [01]);
        
        
        let k4_cmac_bigint : BInt? = BInt(utils.bytesToHex(bytes: k4_cmac),radix: 16)
        
        let k4_modval = k4_cmac_bigint! % 64;
        
        return k4_modval.asString(radix: 16).hexToBytes[0];
    };

    func aesccm(key : [UInt8], nonce : [UInt8] , plaintext : [UInt8]) -> [UInt8] {
        print("aesccm: key="+key.toHexString()+" nonce="+nonce.toHexString()+" plaintext="+plaintext.toHexString())
        let aes = try! AES(key: key, blockMode: CCM(iv: nonce, tagLength: 4, messageLength: plaintext.count, additionalAuthenticatedData: []), padding: .noPadding)
        print("AES object created")
        let encrypted = try! aes.encrypt(plaintext)
        print("encrypted: "+encrypted.toHexString())
        return encrypted
    }
    
    func aesecb(key : [UInt8] , plaintext : [UInt8]) -> [UInt8] {
        print("aesecb: plaintext="+plaintext.toHexString())
        let aes = try! AES(key: key, blockMode: ECB(),padding: .noPadding)
        let encrypted = try! aes.encrypt(plaintext)
        return encrypted
    }

    func e(key : [UInt8], plaintext : [UInt8]) -> [UInt8] {
        let ecb_encrypted = aesecb(key: key, plaintext: plaintext)
        return ecb_encrypted;
    }
    
    func privacyRandom(enc_dst : [UInt8], enc_transport_pdu : [UInt8], netmic : [UInt8]) -> [UInt8] {
        let pr = enc_dst + enc_transport_pdu + netmic;
        let pr06 = Array(pr[0...6])
        return pr06;
    }

    func obfuscate(enc_dst : [UInt8], enc_transport_pdu : [UInt8], netmic : [UInt8], ctl : UInt8, ttl : UInt8, seq : [UInt8], src : [UInt8], iv_index : [UInt8], privacy_key : [UInt8]) -> [UInt8] {
        // 1. Create Privacy Random
        var privacy_random = privacyRandom(enc_dst : enc_dst, enc_transport_pdu : enc_transport_pdu, netmic : netmic);
        print("privacy_random: "+privacy_key.toHexString())
        
        // 2. Calculate PECB
        let pecb_input = [0,0,0,0,0] + iv_index + privacy_random;
        print("pecb input: "+pecb_input.toHexString())
        let pecb = e(key : privacy_key, plaintext: pecb_input)
        let pecb05 = Array(pecb[0...5])
        print("pecb (e): "+pecb05.toHexString())

        // 3. Obfuscate
        let ctl_ttl : UInt8 = ctl | ttl;
        let ctl_ttl_seq_src : [UInt8] = [ctl_ttl] + seq + src;
        let obf : [UInt8] = utils.xorU8Arrays(arrayA : ctl_ttl_seq_src, arrayB : pecb05);
        return obf;
    }
    
}
