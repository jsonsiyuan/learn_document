import UIKit

extension Data {
    struct HexEncodingOptions: OptionSet {
        let rawValue: Int
        static let upperCase = HexEncodingOptions(rawValue: 1 << 0)
    }
    
    func hexEncodedString(options: HexEncodingOptions = []) -> String {
        let format = options.contains(.upperCase) ? "%02hhX" : "%02hhx"
        return map { String(format: format, $0) }.joined()
    }
}

extension UInt8 {
    static func from(hexString: String) -> UInt8 {
        return UInt8(strtoul(hexString, nil, 16))
    }
}

extension StringProtocol {
    var hexToBytes: [UInt8] {
        var startIndex = self.startIndex
        return stride(from: 0, to: count, by: 2).compactMap { _ in
            let endIndex = index(startIndex, offsetBy: 2, limitedBy: self.endIndex) ?? self.endIndex
            defer { startIndex = endIndex }
            return UInt8(self[startIndex..<endIndex], radix: 16)
        }
    }
}

extension StringProtocol {
    var byte_values: [UInt8] {
        var startIndex = self.startIndex
        return stride(from: 0, to: count, by: 2).compactMap { _ in
            let endIndex = index(startIndex, offsetBy: 2, limitedBy: self.endIndex) ?? self.endIndex
            defer { startIndex = endIndex }
            return UInt8(self[startIndex..<endIndex], radix: 16)
        }
    }
}

class Utils {
    
    static let sharedInstance = Utils()
    
    
    func hexStringForByte(byte: UInt8) -> String {
        return String(format: "%02x", UInt(byte))
    }
    
    func bytesToHex(bytes : [UInt8]) -> String {
        var data = Data(bytes: bytes)
        return data.hexEncodedString()
    }
    
    /* Same semantics as JavaScript substring function. From start index up to but not including the end index */
    
    func substring(str : String, start : Int, end : Int) -> String {
        //        print("   str:" + str)
        //        print(" start:" + String(start))
        //        print("   end:" + String(end))
        //        print("   len:" + String(str.count))
        var from_end = (str.count - end) * -1
        if from_end > 0 {
            from_end = 0
        }
        //        print("from_end:" + String(from_end))
        let start = str.index(str.startIndex, offsetBy: start)
        let the_end = str.index(str.endIndex, offsetBy: from_end)
        let range = start..<the_end
        let substr = str[range]
        //        print("substr:"+String(substr))
        return String(substr)
    }
    
    func xorU8Arrays(arrayA : [UInt8] , arrayB : [UInt8]) -> [UInt8] {
        var result = [UInt8](repeating: 0, count: arrayA.count)
        for i in 0..<arrayA.count {
            result[i] = arrayA[i] ^ arrayB[i]
        }
        return result
    }

    func leastSignificantBit(number : UInt8) -> UInt8 {
        return number & 1;
    }
    
    func uint16ToUint8ArrayLE(sixteen_bits : UInt16) -> [UInt8] {
        let lsb : UInt8 = (UInt8) (sixteen_bits & 0xFF)
        let msb : UInt8 = (UInt8) (sixteen_bits >> 8)
        return [lsb , msb]
    }

    func uint16ToUint8ArrayBE(sixteen_bits : UInt16) -> [UInt8] {
        let lsb : UInt8 = (UInt8) (sixteen_bits & 0xFF)
        let msb : UInt8 = (UInt8) (sixteen_bits >> 8)
        return [msb , lsb]
    }
    
    func intSeqToByteArraySeq(int_seq : Int) -> [UInt8] {
        let b1 : UInt8 = (UInt8) (int_seq  & 0x0000FF)
        let b2 : UInt8 = (UInt8) ((int_seq & 0x00FF00) >> 8)
        let b3 : UInt8 = (UInt8) ((int_seq & 0xFF0000) >> 16)
        return [b3 , b2, b1]
    }

    /*
     * Use this function as follows:
     *
     * utils.info(message : "Scanning", ui : self,
     *            cbOK: {
     *               print("OK callback")
     *             })
     *
     */
    func info(message: String, ui: UIViewController, cbOK: @escaping () -> Void) {
        let dialog = UIAlertController(title: "Information", message: message, preferredStyle: UIAlertController.Style.alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) {
            (action) in cbOK()
        }
        dialog.addAction(OKAction)
        // Present the dialog
        ui.present(dialog,animated: false, completion: nil)
    }
    
    func error(message: String, ui: UIViewController, cbOK: @escaping () -> Void) {
        let dialog = UIAlertController(title: "ERROR", message: message, preferredStyle: UIAlertController.Style.alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) {
            (action) in cbOK()
        }
        dialog.addAction(OKAction)
        // Present the dialog
        ui.present(dialog,animated: false, completion: nil)
    }
    
}

