import UIKit

class DeviceViewController: UIViewController, BluetoothOperationsConsumer {

    var adapter: BLEAdapter!
    var utils: Utils!
    var mesh : BluetoothMesh!
    var ready : Bool = true
    var got_mesh_proxy_service: Bool?
    var got_mesh_proxy_data_in: Bool?
    var got_mesh_proxy_data_out: Bool?
    var destination_address : String?
    var last_dst_btn : UIButton?
    let default_btn_colour = UIColor(red: 247.0/255.0, green: 249.0/255.0, blue: 249.0/255.0, alpha: 1.0)
    let default_text_colour_disabled = UIColor.gray
    let default_text_colour_enabled = UIColor.black
    
    let WHITE = 0
    let RED = 1
    let GREEN = 2
    let BLUE = 3
    let YELLOW = 4
    let CYAN = 5
    let MAGENTA = 6
    let BLACK = 7
    
    let H : [UInt16] = [    0,      0,  21845,  43690,  10922,  32768,  54613,  0]
    let S : [UInt16] = [    0,  65535,  65535,  65535,  65535,  65535,  65535,  0]
    let L : [UInt16] = [65535,  32767,  32767,  32767,  32767,  32767,  32767,  0]

    @IBOutlet weak var device_details: UILabel!
    @IBOutlet weak var dst_address: UILabel!
    @IBOutlet weak var btn_all: UIButton!
    @IBOutlet weak var btn_c1: UIButton!
    @IBOutlet weak var btn_c2: UIButton!
    @IBOutlet weak var btn_c3: UIButton!
    @IBOutlet weak var btn_c4: UIButton!
    @IBOutlet weak var btn_r1: UIButton!
    @IBOutlet weak var btn_r2: UIButton!
    @IBOutlet weak var btn_r3: UIButton!
    @IBOutlet weak var btn_r4: UIButton!
    @IBOutlet weak var btn_on: UIButton!
    @IBOutlet weak var btn_off: UIButton!
    @IBOutlet weak var lbl_status: UILabel!
    @IBOutlet weak var btn_connect: UIButton!
    @IBOutlet weak var btn_white: UIButton!
    @IBOutlet weak var btn_red: UIButton!
    @IBOutlet weak var btn_green: UIButton!
    @IBOutlet weak var btn_blue: UIButton!
    @IBOutlet weak var btn_yellow: UIButton!
    @IBOutlet weak var btn_cyan: UIButton!
    @IBOutlet weak var btn_magenta: UIButton!
    @IBOutlet weak var btn_black: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("DeviceViewController did load")
        adapter = BLEAdapter.sharedInstance
        utils = Utils.sharedInstance
        mesh = BluetoothMesh.sharedInstance
        device_details.text = adapter.selected_peripheral!.identifier.uuidString
        destination_address = "C001"
        dst_address.text = "DST: 0xC001"
        last_dst_btn = btn_all
        set_ui_disconnected()
        got_mesh_proxy_service = false
        got_mesh_proxy_data_in = false
        got_mesh_proxy_data_out = false
        do {
            try mesh.initialise()
        } catch {
            lbl_status.text = "ERROR: could not init security"
            ready = false
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func set_ui_disconnected() {
        btn_connect.setTitle("CONNECT", for: .normal)
        btn_all.setTitleColor(UIColor.black, for: .normal)
        last_dst_btn?.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_all.isEnabled = false
        btn_all.backgroundColor = default_btn_colour
        btn_all.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_on.isEnabled = false
        btn_on.backgroundColor = default_btn_colour
        btn_on.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_off.isEnabled = false
        btn_off.backgroundColor = default_btn_colour
        btn_off.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_c1.isEnabled = false
        btn_c1.backgroundColor = default_btn_colour
        btn_c1.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_c2.isEnabled = false
        btn_c2.backgroundColor = default_btn_colour
        btn_c2.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_c3.isEnabled = false
        btn_c3.backgroundColor = default_btn_colour
        btn_c3.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_c4.isEnabled = false
        btn_c4.backgroundColor = default_btn_colour
        btn_c4.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_r1.isEnabled = false
        btn_r1.backgroundColor = default_btn_colour
        btn_r1.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_r2.isEnabled = false
        btn_r2.backgroundColor = default_btn_colour
        btn_r2.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_r3.isEnabled = false
        btn_r3.backgroundColor = default_btn_colour
        btn_r3.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_r4.isEnabled = false
        btn_r4.backgroundColor = default_btn_colour
        btn_r4.setTitleColor(default_text_colour_disabled, for: .normal)
        btn_white.isEnabled = false
        btn_white.backgroundColor = default_btn_colour
        btn_red.isEnabled = false
        btn_red.backgroundColor = default_btn_colour
        btn_green.isEnabled = false
        btn_green.backgroundColor = default_btn_colour
        btn_blue.isEnabled = false
        btn_blue.backgroundColor = default_btn_colour
        btn_yellow.isEnabled = false
        btn_yellow.backgroundColor = default_btn_colour
        btn_cyan.isEnabled = false
        btn_cyan.backgroundColor = default_btn_colour
        btn_magenta.isEnabled = false
        btn_magenta.backgroundColor = default_btn_colour
        btn_black.isEnabled = false
        btn_black.backgroundColor = default_btn_colour
    }

    func set_ui_connected() {
        btn_connect.setTitle("DISCONNECT", for: .normal)
        btn_connect.setTitleColor(UIColor.white, for: .normal)
        btn_all.isEnabled = true
        btn_all.backgroundColor = UIColor.black
        btn_all.setTitleColor(UIColor.white, for: .normal)
        btn_on.isEnabled = true
        btn_on.backgroundColor = UIColor.lightGray
        btn_on.setTitleColor(UIColor.white, for: .normal)
        btn_off.isEnabled = true
        btn_off.backgroundColor = UIColor.lightGray
        btn_off.setTitleColor(UIColor.white, for: .normal)
        btn_c1.isEnabled = true
        btn_c1.backgroundColor = UIColor.black
        btn_c1.setTitleColor(UIColor.white, for: .normal)
        btn_c2.isEnabled = true
        btn_c2.backgroundColor = UIColor.black
        btn_c2.setTitleColor(UIColor.white, for: .normal)
        btn_c3.isEnabled = true
        btn_c3.backgroundColor = UIColor.black
        btn_c3.setTitleColor(UIColor.white, for: .normal)
        btn_c3.setTitleColor(UIColor.white, for: .normal)
        btn_c4.isEnabled = true
        btn_c4.backgroundColor = UIColor.black
        btn_c4.setTitleColor(UIColor.white, for: .normal)
        btn_r1.isEnabled = true
        btn_r1.backgroundColor = UIColor.black
        btn_r1.setTitleColor(UIColor.white, for: .normal)
        btn_r2.isEnabled = true
        btn_r2.backgroundColor = UIColor.black
        btn_r2.setTitleColor(UIColor.white, for: .normal)
        btn_r3.isEnabled = true
        btn_r3.backgroundColor = UIColor.black
        btn_r3.setTitleColor(UIColor.white, for: .normal)
        btn_r4.isEnabled = true
        btn_r4.backgroundColor = UIColor.black
        btn_r4.setTitleColor(UIColor.white, for: .normal)
        btn_white.isEnabled = true
        btn_white.backgroundColor = UIColor.white
        btn_red.isEnabled = true
        btn_red.backgroundColor = UIColor.red
        btn_green.isEnabled = true
        btn_green.backgroundColor = UIColor.green
        btn_blue.isEnabled = true
        btn_blue.backgroundColor = UIColor.blue
        btn_yellow.isEnabled = true
        btn_yellow.backgroundColor = UIColor.yellow
        btn_cyan.isEnabled = true
        btn_cyan.backgroundColor = UIColor.cyan
        btn_magenta.isEnabled = true
        btn_magenta.backgroundColor = UIColor.magenta
        btn_black.isEnabled = true
        btn_black.backgroundColor = UIColor.black
        set_dst_address_button_colour()
    }

    func set_dst_address_button_colour() {
        print("destination_address="+destination_address!)
        if destination_address == "C003" {
            btn_all.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C021" {
            btn_c1.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C022" {
            btn_c2.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C023" {
            btn_c3.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C024" {
            btn_c4.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C011" {
            btn_r1.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C012" {
            btn_r2.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C013" {
            btn_r3.setTitleColor(UIColor.red, for: .normal)
        } else if destination_address == "C014" {
            btn_r4.setTitleColor(UIColor.red, for: .normal)
        }
    }

    func set_dst_address_label(button : UIButton , address : String) {
        destination_address = address
        dst_address.text = "DST: 0x" + destination_address!
        last_dst_btn?.setTitleColor(UIColor.white, for: .normal)
        button.setTitleColor(UIColor.red, for: .normal)
        last_dst_btn = button

    }
    
    @IBAction func on_btn_all(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C001")
    }
    
    @IBAction func on_btn_c1(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C021")
    }
    
    @IBAction func on_btn_c2(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C022")
    }
    
    @IBAction func on_btn_c3(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C023")
    }
    
    @IBAction func on_btn_c4(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C024")
    }
    
    @IBAction func on_btn_r1(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C011")
    }
    
    @IBAction func on_btn_r2(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C012")
    }
    
    @IBAction func on_btn_r3(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C013")
    }
    
    @IBAction func on_btn_r4(_ sender: UIButton) {
        set_dst_address_label(button : sender, address: "C014")
    }
    
    @IBAction func on_btn_on(_ sender: UIButton) {
        print("ON")
        lbl_status.text = "Sending...."
        let ok : Bool = mesh.sendGenericOnOffSetUnack(dst : destination_address!.hexToBytes, onoff : 1)
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_off(_ sender: UIButton) {
        print("OFF")
        lbl_status.text = "Sending...."
        let ok : Bool = mesh.sendGenericOnOffSetUnack(dst : destination_address!.hexToBytes, onoff : 0)
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_connect(_ sender: UIButton) {
        if ready {
            print("CONNECT")
            if (adapter.connected == false) {
                if (adapter.connecting == false) {
                    btn_connect.setTitle("CONNECTING....", for: .normal)
                    btn_connect.setTitleColor(UIColor.red, for: .normal)
                    adapter.connect(self)
                }
            } else {
                adapter.disconnect(self)
            }
        } else {
            lbl_status.text = "ERROR: Application did not initialise"
        }
    }
    
    @IBAction func on_btn_white(_ sender: UIButton) {
        print("white")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[WHITE], s: S[WHITE], l: L[WHITE])
        messageStatus(ok : ok)
    }
 
    @IBAction func on_btn_red(_ sender: UIButton) {
        print("red")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[RED], s: S[RED], l: L[RED])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_green(_ sender: UIButton) {
        print("green")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[GREEN], s: S[GREEN], l: L[GREEN])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_blue(_ sender: UIButton) {
        print("blue")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[BLUE], s: S[BLUE], l: L[BLUE])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_yellow(_ sender: UIButton) {
        print("yellow")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[YELLOW], s: S[YELLOW], l: L[YELLOW])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_cyan(_ sender: UIButton) {
        print("cyan")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[CYAN], s: S[CYAN], l: L[CYAN])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_magenta(_ sender: UIButton) {
        print("magenta")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[MAGENTA], s: S[MAGENTA], l: L[MAGENTA])
        messageStatus(ok : ok)
    }
    
    @IBAction func on_btn_black(_ sender: UIButton) {
        print("black")
        let ok : Bool = mesh.sendLightHslSetUnack(dst : destination_address!.hexToBytes, h: H[BLACK], s: S[BLACK], l: L[BLACK])
        messageStatus(ok : ok)
    }
    
    //START BluetoothOperationsConsumer
    func onConnected() {
        print("onConnected")
        btn_connect.setTitleColor(UIColor.white, for: .normal)
        btn_connect.setTitle("DISCONNECT", for: .normal)
        lbl_status.text = "connected to proxy"
        adapter.discoverServices()
    }
    
    func onFailedToConnect(_ error: Error?) {
        print("onFailedToConnect")
        utils.error(message : "Failed to connect:  \(error)",
            ui : self,
            cbOK: {
        })
        lbl_status.text = "not connected to proxy"
    }
    
    func onDisconnected() {
        print("onDisconnected")
        set_ui_disconnected()
        lbl_status.text = "not connected to proxy"
    }
    
    func onServicesDiscovered() {
        print("onServicesDiscovered")
        adapter.discoverCharacteristics()
    }

    func onMeshProxyServiceDiscovered() {
        print("onMeshProxyServiceDiscovered")
        got_mesh_proxy_service = true
    }

    func onMeshProxyDataInDiscovered() {
        print("onMeshProxyDataInDiscovered")
        got_mesh_proxy_data_in = true
    }
    
    func onMeshProxyDataOutDiscovered() {
        print("onMeshProxyDataOutDiscovered")
        got_mesh_proxy_data_out = true
    }
    
    func onDiscoveryFinished() {
        print("onDiscoveryFinished")
        if (got_mesh_proxy_service! && got_mesh_proxy_data_in! && got_mesh_proxy_data_out!) {
            set_ui_connected()
        } else {
            utils.error(message : "Device is not a valid mesh proxy",
                ui : self,
                cbOK: {
            })
            adapter.disconnect(self)
        }
    }
    
    func onMeshProxyDataOutWritten() {
        print("onMeshProxyDataOutWritten")
    }
    
    //END BluetoothOperationsConsumer
    

    func messageStatus(ok : Bool) {
        if ok {
            lbl_status.text = "OK"
        } else {
            lbl_status.text = "ERROR"
        }
    }
}
