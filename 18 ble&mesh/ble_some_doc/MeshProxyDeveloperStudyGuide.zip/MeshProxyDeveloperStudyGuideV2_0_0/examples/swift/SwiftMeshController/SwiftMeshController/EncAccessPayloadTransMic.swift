
import Foundation

struct EncAccessPayloadTransMic {
    var enc_access_payload : [UInt8] = [0,0,0,0]
    var transMIC : [UInt8] = [0,0,0,0]
}
