SwiftMeshController
-------------------

Libraries
---------

1. Crypto

https://github.com/krzyzanowskim/CryptoSwift

* Installation Notes

git submodule add https://github.com/krzyzanowskim/CryptoSwift.git

Drag and drop CryptoSwift.xcodeproj into the Xcode project.

In Xcode, in the Build Phases screen:
A. Add CryptoSwift (satchel icon) to the Target Dependencies
B. Add CryptoSwift.framework to Link Binaries with Libraries
C. Now select app and choose the General tab for the app target. Find Embedded Binaries and press "+", then select CryptoSwift.framework (iOS, OS X, watchOS or tvOS). Sometimes “embedded framework” option is not available. In that case, you have to add new build phase for the target (Build Phases, +, Copy Files, Destination Frameworks, CryptoSwift.framework)


2. Big Integer Arithmetic

https://github.com/mkrd/Swift-BigInt 

* Installation Notes

Drag and drop Swift-Big-Number-Core.swift from Finder into the Xcode workspace.
