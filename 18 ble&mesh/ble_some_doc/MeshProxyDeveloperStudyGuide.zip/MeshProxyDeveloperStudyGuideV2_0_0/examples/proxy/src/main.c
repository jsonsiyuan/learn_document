/**
 * Proxy Node
 **/

#include <stdlib.h>
#include <misc/printk.h>
#include <gpio.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/mesh.h>

// addresses
#define NODE_NUM 99
#define NODE_ADDR 0x0063

// security keys
static const u8_t net_key[16] = {
		0xaf, 0xc3, 0x27, 0x0e, 0xda, 0x88, 0x02, 0xf7, 0x2c, 0x1e, 0x53, 0x24, 0x38, 0xa9, 0x79, 0xeb};

static const u8_t app_key[16] = {
		0x42, 0x2b, 0xf4, 0x56, 0xf5, 0xf3, 0xe6, 0xb7, 0xc5, 0xe9, 0x00, 0x6a, 0x02, 0x2b, 0x6d, 0x8e};

static const u8_t dev_key[16] = {
		0x96, 0x4a, 0xf6, 0xfc, 0x03, 0x38, 0x8c, 0x73, 0xea, 0xff, 0x94, 0x61, 0x57, 0xff, 0x66, 0x63};

// device UUID
static const uint8_t dev_uuid[16] = {0x19, 0xec, 0xf3, 0x40, 0x5e, 0x08, 0xc0, 0x99, 0x0f, 0x07, 0x80, 0x25, 0x9c, 0xf7, 0x53, 0x63};


// indexes
static const u16_t net_idx;
static const u16_t app_idx;
static const u32_t iv_index;

// other
#define MAX_LEVEL 32767
static u8_t flags;
static u16_t node_addr = NODE_ADDR;

static const struct bt_mesh_prov prov = {
		.uuid = dev_uuid,
};

// Configuration Client Model
// -------------------------------------------------------------------------------------------------------
static struct bt_mesh_cfg_cli cfg_cli = {};

// -------------------------------------------------------------------------------------------------------
// Configuration Server
// --------------------
static struct bt_mesh_cfg_srv cfg_srv = {
		.relay = BT_MESH_RELAY_DISABLED,
		.beacon = BT_MESH_BEACON_DISABLED,
		.frnd = BT_MESH_FRIEND_NOT_SUPPORTED,
		.gatt_proxy = BT_MESH_GATT_PROXY_ENABLED,
		.default_ttl = 7,
		.net_transmit = BT_MESH_TRANSMIT(5, 23),
};

// -------------------------------------------------------------------------------------------------------
// Health Server
// -------------
BT_MESH_HEALTH_PUB_DEFINE(health_pub, 0);
static struct bt_mesh_health_srv health_srv = {};


// -------------------------------------------------------------------------------------------------------
// Composition
// -----------

static struct bt_mesh_model sig_models[] = {
		BT_MESH_MODEL_CFG_SRV(&cfg_srv),
		BT_MESH_MODEL_CFG_CLI(&cfg_cli),
		BT_MESH_MODEL_HEALTH_SRV(&health_srv, &health_pub)};

// node contains elements.note that BT_MESH_MODEL_NONE means "none of this type" ands here means "no vendor models"
static struct bt_mesh_elem elements[] = {
		BT_MESH_ELEM(0, sig_models, BT_MESH_MODEL_NONE),
};

// node
static const struct bt_mesh_comp comp = {
		.elem = elements,
		.elem_count = ARRAY_SIZE(elements),
};

// -------------------------------------------------------------------------------------------------------
// Self Provisioning

static int selfProvision(void)
{
	// now we provision ourselves... this is not how it would normally be done!
	int err = bt_mesh_provision(net_key, net_idx, flags, iv_index, node_addr, dev_key);
	if (err)
	{
		printk("Provisioning failed (err %d)\n", err);
		return err;
	}
	printk("Provisioning completed\n");

	return 0;
}

// -------------------------------------------------------------------------------------------------------
static int selfConfigure(void)
{
	int err;
	printk("configuring...\n");

	/* Add Application Key */
	err = bt_mesh_cfg_app_key_add(net_idx, node_addr, net_idx, app_idx, app_key, NULL);
	if (err)
	{
		printk("ERROR adding appkey (err %d)\n", err);
		return err;
	}
	else
	{
		printk("added appkey\n");
	}

	/* Bind to Health model */
	err = bt_mesh_cfg_mod_app_bind(net_idx, node_addr, node_addr, app_idx, BT_MESH_MODEL_ID_HEALTH_SRV, NULL);
	if (err)
	{
		printk("ERROR binding to health server model (err %d)\n", err);
		return err;
	}
	else
	{
		printk("bound appkey to health server model\n");
	}

	return 0;
}

static void bt_ready(int err)
{
	if (err)
	{
		printk("bt_enable init failed with err %d\n", err);
		return;
	}

	printk("Bluetooth initialised OK\n");

	// self-provision and initialise with node composition data
	err = bt_mesh_init(&prov, &comp);
	if (err)
	{
		printk("bt_mesh_init failed with err %d\n", err);
		return;
	}

	err = selfProvision();
	if (err)
	{
		printk("ERROR: SELF-PROVISIONING FAILED");
	}
	else
	{
		printk("self-provisioned OK\n");
	}

	err = selfConfigure();

	if (err)
	{
		printk("ERROR: INITIALISATION FAILED");
	}
	else
	{
		printk("Mesh initialised OK\n");
	}
}

void main(void)
{
	int err;
	printk("proxy node      : 0x%04x\n", node_addr);

	/* Initialize the Bluetooth Subsystem */
	err = bt_enable(bt_ready);
	if (err)
	{
		printk("bt_enable failed with err %d\n", err);
	}
}
