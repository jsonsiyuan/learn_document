# onoff_client binaries

A selection of binaries with buttons A and B programmed to send different types of generic client onoff messages for testing purposes.

# onoff\_client\_set\_on\_set\_off.hex

    Button A
        GENERIC ONOFF SET ON
    Button B
        GENERIC ONOFF SET OFF

# onoff\_client\_set\_unack\_on\_get.hex

    Button A
        GENERIC ONOFF SET UNACKNOWLEDGED ON
    Button B
        GENERIC ONOFF GET

# onoff\_client\_set\_unack\_on\_set\_unack\_off.hex

    Button A
        GENERIC ONOFF SET UNACKNOWLEDGED ON
    Button B
        GENERIC ONOFF SET UNACKNOWLEDGED OFF

