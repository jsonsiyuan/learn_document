//
//  SequenceNumber.h
//
//  Created by RenKai on 2018/10/22.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NVM : NSObject

- (instancetype)init;
- (NSData *)retrieveSequenceNumber;

@end

NS_ASSUME_NONNULL_END
