//
//  provisioning.h
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <Security/Security.h>
#import "ECDH.h"

NS_ASSUME_NONNULL_BEGIN

@interface Provisioning : NSObject

@property(nonatomic, weak)CBCharacteristic *meshProvDataIn;
@property(nonatomic, weak)CBCharacteristic *meshProvDataOut;
@property(nonatomic, weak)NSString *meshProvServiceUUIDString;
@property(nonatomic, weak)NSString *meshProvDataInCharacteristicUUIDString ;
@property(nonatomic, weak)NSString *meshProvDataOutCharacteristicUUIDString ;

@property(nonatomic, strong)NSData *randomValue;
@property(nonatomic, strong)NSData *publicKey;
@property(nonatomic, strong)NSData *privateKey;
@property(nonatomic, strong)NSData *confirmationValue;
@property(nonatomic, strong)ECDH *ecdhCrypto;

- (instancetype)init;

//- (void)provPDUParser:(NSData *)PDU;

- (void)provPDUParser: (CBPeripheral *)peripheral
           dataInChar: (CBCharacteristic *)dataInChar
          dataOutChar: (CBCharacteristic *)dataOutChar;

- (NSData *)provInvitation;

@end

NS_ASSUME_NONNULL_END
