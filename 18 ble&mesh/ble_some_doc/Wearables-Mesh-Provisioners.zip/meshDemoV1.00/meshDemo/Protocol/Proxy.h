//
//  proxy.h
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>


NS_ASSUME_NONNULL_BEGIN

typedef struct {
    BOOL SZMIC;
    UInt16 seqZero;
    UInt8 segO;
    UInt8 segN;
} segInfo;

@interface Proxy : NSObject
@property(nonatomic, weak)CBCharacteristic *meshProxyDataIn;
@property(nonatomic, weak)CBCharacteristic *meshProxyDataOut;
@property(nonatomic, weak)NSString *meshProxyServiceUUIDString ;
@property(nonatomic, weak)NSString *meshProxyDataInCharacteristicUUIDString ;
@property(nonatomic, weak)NSString *meshProxyDataOutCharacteristicUUIDString ;
@property (strong, nonatomic) NSData *deviceKey;
@property UInt8 numOfElements;
@property (strong, nonatomic) NSData *primaryElement;


- (instancetype)initWith; 
//- (NSData *)prepareNetworkPDU:(bool) value;
- (NSData *)getPDUForGenericOnOffServer:(BOOL)OnOff; 
//- (NSData *)proxyReturnSeq;

- (NSData *) prepareModelConfig:(NSData *)devKey destAddr: (NSData *)dst modelID:(NSData *)id value:(NSData *)value;

- (void)proxyPDUParser:(CBPeripheral *)peripheral
            dataInChar: (CBCharacteristic *)dataInChar
           dataOutChar: (CBCharacteristic *)dataOutChar ;

@end

NS_ASSUME_NONNULL_END
