//
//  provisioning.m
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "Provisioning.h"
#import "crypto.h"

//https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.service.mesh_provisioning.xml
//mesh provisioning service uuid: 0x1827
//mesh provisioning data in char uuid: 0x2add
//mesh provisioning data out char uuid: 0x2ade

@interface Provisioning()

@property SecKeyRef PublicKeyProvisioner;       //provisioner public key locally
@property SecKeyRef PrivateKeyProvisioner;      //provisioner private key locally
@property SecKeyRef PublicKeyDevice;            //unprovisioned device public key @ phase 3 of provisioning

@property (strong, nonatomic)NSTimer *ProvisionerTimer; //a timer to indicate a timeout if no response from unprovisioned device

@property (strong, nonatomic)NSData *randomNumberProvisioner;   //random number of provisioner locally
@property (strong, nonatomic)NSData *randomNumberDevice;        //random number of unprovisioned device @ phase 4 of provisioning

@property (strong, nonatomic)NSData *ecdhSecret;                 //ecdhSecret

@property (strong, nonatomic)NSData *ProvisioningInvitePDUValue;    
@property (strong, nonatomic)NSData *ProvisioningCapabilitiesPDUValue;
@property (strong, nonatomic)NSData *ProvisioningStartPDUValue;
@property (strong, nonatomic)NSData *ConfirmationKey;       //ConfirmationKey is used to encryption ConfirmationValue @ phase 4 of provisioning
@property (strong, nonatomic)NSData *ConfirmationSALT;      //ConfirmationSALT is used to calculate ConfirmationKey
@property (strong, nonatomic)NSData *ConfirmationDevice;    //ConfirmationValue from unprovisioned device

@property (strong, nonatomic)crypto *ccm;
@property (strong, nonatomic)NSData *DevKey;        //for deviceKey which is calculate during provisioning
@property UInt8 numOfElements;                      //for how many elements on this unprovisioned device which is 1st octet of provisioning capability

@end

enum{
    ProvisioningPDUTypeInvitation = 0,
    ProvisioningPDUTypeCapability,
    ProvisioningPDUTypeStart,
    ProvisioningPDUTypePublicKey,
    ProvisioningPDUTypeInputComplete,
    provisioningPDUTypeConfirmation,
    ProvisioningPDUTypeRandom,
    ProvisioningPDUTypeData,
    ProvisioningPDUTypeComplete,
    ProvisioningPDUTypeFailed
} ;

//Mesh Provisioning Service, https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.service.mesh_provisioning.xml
NSString *meshProvisioningServiceUUIDString = @"1827";   

//Mesh Provisioning Data In, https://www.bluetooth.com/specifications/mesh-specifications/mesh-viewer?xmlFile=org.bluetooth.characteristic.mesh_provisioning_data_in&attributeXmlFile=org.bluetooth.characteristic.mesh_provisioning_data_in.xml
NSString *meshProvisioningDataInCharacteristicUUIDString = @"2ADB"; 

//Mesh Provisioning Data Out, https://www.bluetooth.com/specifications/mesh-specifications/mesh-viewer?xmlFile=org.bluetooth.characteristic.mesh_provisioning_data_out&attributeXmlFile=org.bluetooth.characteristic.mesh_provisioning_data_out.xml
NSString *meshProvisioningDataOutCharacteristicUUIDString = @"2ADC";

//Mesh Network Layer Key
NSString *netkeyString1 = @"18eed9c2a56add85049ffc3c59ad0e1f";

//Mesh Provisioning Data
NSString *KeyIndexStriing = @"0000";
NSString *FlagsString = @"00";
NSString *IVIndexString = @"00000000";

@implementation Provisioning

- (instancetype)init{
    if (self = [super init]) {
        _meshProvServiceUUIDString = @"1827";
        _meshProvDataInCharacteristicUUIDString = @"2ADB";
        _meshProvDataOutCharacteristicUUIDString = @"2ADC";
        
        [ECDH generateKeyPair:&_PublicKeyProvisioner privateTag:&_PrivateKeyProvisioner];

        _ccm = [[crypto alloc]init];

        _ProvisioningInvitePDUValue = [[NSData alloc]initWithBytes:(char[]){05} length:1];
        _ProvisioningStartPDUValue = [[NSData alloc]initWithBytes:(char[]){0x00, 0x00, 0x00, 0x00, 0x00} length:5];
        _ConfirmationKey    = [[NSData alloc]init];
        _ConfirmationSALT   = [[NSData alloc]init];
        
        _randomNumberProvisioner = [ECDH getRandomNumber];
        _randomNumberDevice = [[NSData alloc]init];
        
        _ProvisionerTimer = [[NSTimer alloc]init];
    {
        //Initial unicastAddressIdentifier
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        UInt16 unicastAddress = [user integerForKey:@"unicastAddressIdentifier"];
        if (!unicastAddress) {
            unicastAddress = 0x5000;
            [user setInteger:unicastAddress forKey:@"unicastAddressIdentifier"];
        }
    }
        
    }
    return self;
}

//timerFired callback for provisioning timeout
- (void)ProvisionerTimerFired:(NSTimer *)timer{
    
    NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus" object:nil userInfo:@{@"1":@"ProvisioningStatusTimerFired"}];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    
}

#pragma mark - provisioning protocol

//provisioning PDUs Parser method
- (void)provPDUParser: (CBPeripheral *)peripheral
    dataInChar: (CBCharacteristic *)dataInChar
          dataOutChar: (CBCharacteristic *)dataOutChar
{
    SecKeyRef deviceSecPublicKey = nil;

    //byte[0] is Proxy PDU message type
    //byte[1] is Provisioning PDU message type, get it for Provisioning PDU parser 
    UInt8 pduType ;
    [dataOutChar.value getBytes:&pduType range:NSMakeRange(1, 1)];
    
    //byte[2] ~ tail is Provisioning PDU payload/parameter
    NSData *pduPayload = [dataOutChar.value subdataWithRange:NSMakeRange(2, dataOutChar.value.length - 2)];
    
    //Provisioning outcome PDU for Provisioning, 0x03 is Provisioning PDU type of Proxy message, Table 6.3 on Mesh Profile v1.0 
    NSMutableData *ProvisioningSendingPDU = [[NSMutableData alloc]initWithBytes:(char[]){0x03} length:1];
    //NSLog(@"provisioning data parser, pdyType: 0x%X, PDU: %@", pduType, pduPayload);
    
    switch (pduType) {
#pragma mark - ProvisioningPDUTypeCapability
        case ProvisioningPDUTypeCapability: //0x01
            NSLog(@"ProvisioningPDUTypeCapability");
            _ProvisioningCapabilitiesPDUValue = [[NSData alloc]initWithData:pduPayload];
            
            [_ProvisioningCapabilitiesPDUValue getBytes:&_numOfElements range:NSMakeRange(0, 1)];
            NSLog(@"numOfElements: 0x%X", _numOfElements);
            
            [NSThread sleepForTimeInterval:1.0];
            
            //sending Provisioning Start
            [peripheral writeValue:[self provStart]
                 forCharacteristic:dataInChar
                              type:CBCharacteristicWriteWithoutResponse];

            //sending Provisioning Public Key of provisioner
            [ProvisioningSendingPDU appendBytes:(char[]){0x03} length:1];   //append pduType
            [ProvisioningSendingPDU appendData:[ECDH getPublicKeyFromSecKey:&_PublicKeyProvisioner]];
            [peripheral writeValue:ProvisioningSendingPDU
                 forCharacteristic:dataInChar
                              type:CBCharacteristicWriteWithoutResponse];
            
            _ProvisionerTimer = [NSTimer scheduledTimerWithTimeInterval:5
                                                                 target:self
                                                               selector:@selector(ProvisionerTimerFired:)
                                                               userInfo:nil
                                                                repeats:NO];
            
            break;
#pragma mark - ProvisioningPDUTypePublicKey
        case ProvisioningPDUTypePublicKey:  //0x03
            NSLog(@"ProvisioningPDUTypePublicKey");
            deviceSecPublicKey = [ECDH getSecKeyFromPublicKey:pduPayload];
            //NSLog(@"deviceSecPublicKey: %@", deviceSecPublicKey);
            _ecdhSecret = [[NSData alloc] initWithData: [ECDH ecdhSecretCalculation:&deviceSecPublicKey private:&_PrivateKeyProvisioner]];
            //NSLog(@"_ecdhSecret: %@", _ecdhSecret);
        {
            //ConfirmationInputs
            NSMutableData *ConfirmationInputs = [[NSMutableData alloc]init];
            [ConfirmationInputs appendData:_ProvisioningInvitePDUValue];
            [ConfirmationInputs appendData:_ProvisioningCapabilitiesPDUValue];
            [ConfirmationInputs appendData:_ProvisioningStartPDUValue];
            [ConfirmationInputs appendData:[ECDH getPublicKeyFromSecKey:&_PublicKeyProvisioner]];
            [ConfirmationInputs appendData:[ECDH getPublicKeyFromSecKey:&deviceSecPublicKey]];
            NSLog(@"ConfirmationInputs: %@", ConfirmationInputs);
            
            //calculate ConfirmationSalt
            _ConfirmationSALT = [_ccm SALT:ConfirmationInputs];
            NSLog(@"ConfirmationSalt: %@", _ConfirmationSALT);
            
            //calculate ConfirmationKey
            NSData *andP = [[NSData alloc]initWithBytes:(char[]){'p', 'r', 'c', 'k'} length:4];
            _ConfirmationKey = [_ccm k1N:_ecdhSecret salt:_ConfirmationSALT P:andP];
            NSLog(@"ConfirmationKey: %@", _ConfirmationKey);

            
            //calculate ConfirmationProvisioner
            NSMutableData *RandomProvisionerAuthValue = [[NSMutableData alloc]initWithData:_randomNumberProvisioner];
            [RandomProvisionerAuthValue appendData:[ECDH getAuthValue]];
            NSLog(@"RandomProvisionerAuthValue: %@", RandomProvisionerAuthValue);
            NSData *confirmationValue = [[NSData alloc]initWithData:[_ccm mesh_CMAC:RandomProvisionerAuthValue
                                                                                 K:_ConfirmationKey]];
            NSLog(@"confirmationValue: %@", confirmationValue);
            
            //sending provisioner public key to unprovisioned device
            [ProvisioningSendingPDU appendBytes:(char[]){0x05} length:1];   //append pduType
            [ProvisioningSendingPDU appendData:confirmationValue];
            
            [peripheral writeValue:ProvisioningSendingPDU
                 forCharacteristic:dataInChar
                              type:CBCharacteristicWriteWithoutResponse];

        }
            break;
            
#pragma mark - provisioningPDUTypeConfirmation
        case provisioningPDUTypeConfirmation: //0x05
            NSLog(@"provisioningPDUTypeConfirmation");
            
            //Retrieve ConfirmationValue from unprovisioned device
            _ConfirmationDevice = [[NSData alloc]initWithData:pduPayload];
            
        {
            
            //sending Random Number of Provisioner to unprovisioned device for ConfirmationValue calculation and check
            NSMutableData *RandomNumberProvisioner = [[NSMutableData alloc]initWithData: _randomNumberProvisioner];
            [ProvisioningSendingPDU appendBytes:(char[]){0x06} length:1];   //append pduType
            [ProvisioningSendingPDU appendData:RandomNumberProvisioner];
            [peripheral writeValue:ProvisioningSendingPDU
                 forCharacteristic:dataInChar
                              type:CBCharacteristicWriteWithoutResponse];
        }
            break;

#pragma mark - ProvisioningPDUTypeRandom
        case ProvisioningPDUTypeRandom: //0x06
            NSLog(@"ProvisioningPDUTypeRandom: %@", pduPayload);
            
            //retrieve random number from unprovisioned device
            _randomNumberDevice = pduPayload;
        {
            NSMutableData *RandomDevicePlusAuthValue = [[NSMutableData alloc]initWithData:pduPayload];
            [RandomDevicePlusAuthValue appendData:[ECDH getAuthValue]];
            
            //calculate ConfirmationValueUnprovisionedDevice and check
            if ([_ConfirmationDevice isEqual:[_ccm mesh_CMAC:RandomDevicePlusAuthValue K:_ConfirmationKey]]) {
                NSLog(@"authentication successful");
                
                {
                    //authentication successful, good time to save numOfElements
                    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                    [user setInteger:_numOfElements forKey:@"numOfElementsIdentifier"];
                    
                    //calculate ProvisioningSALT
                    NSMutableData *ProvisioningSaltInput = [[NSMutableData alloc]init];
                    [ProvisioningSaltInput appendData:_ConfirmationSALT];
                    [ProvisioningSaltInput appendData:_randomNumberProvisioner];
                    [ProvisioningSaltInput appendData:_randomNumberDevice];
                    NSData *ProvisioningSalt = [_ccm SALT:ProvisioningSaltInput];
                    NSLog(@"ProvisioningSalt: %@", ProvisioningSalt);
                    
                    //calculate SessionKey which will be used to encrypt ProvisioningData
                    NSData *prsk = [[NSData alloc]initWithBytes:(char[]){'p', 'r', 's', 'k'} length:4];
                    NSData *SessionKey = [_ccm k1N:_ecdhSecret salt:ProvisioningSalt P:prsk];
                    NSLog(@"SessionKey: %@", SessionKey);
                    
                    //calculate SessionNonceNew which will be used to encrypt ProvisioningData
                    NSData *prsn = [[NSData alloc]initWithBytes:(char[]){'p', 'r', 's', 'n'} length:4];
                    NSData *SessionNonce = [_ccm k1N:_ecdhSecret salt:ProvisioningSalt P:prsn];
                    NSLog(@"SessionNonce: %@", SessionNonce);
                    NSData *SessionNonceNew = [[NSData alloc]initWithData:[SessionNonce subdataWithRange:NSMakeRange(3, 13)]];
                    NSLog(@"SessionNonceNew: %@", SessionNonceNew);
                    
                    //calculate DeviceKey, it's VERY IMPORTANT for model configuration
                    NSData *prdk = [[NSData alloc]initWithBytes:(char[]){'p', 'r', 'd', 'k'} length:4];
                    _DevKey = [_ccm k1N:_ecdhSecret salt:ProvisioningSalt P:prdk];
                    
                    //assemble ProvisioningData and encrypt
                    NSMutableData *ProvisioningData = [[NSMutableData alloc]init];
                    [ProvisioningData appendData:[crypto dataFormHexString:netkeyString1]];
                    [ProvisioningData appendData:[crypto dataFormHexString:KeyIndexStriing]];
                    [ProvisioningData appendData:[crypto dataFormHexString:FlagsString]];
                    [ProvisioningData appendData:[crypto dataFormHexString:IVIndexString]];
                    [ProvisioningData appendData:[self updateUnicastAddressPoll:_numOfElements]];
                    NSLog(@"ProvisioningData: %@", ProvisioningData);
                    [ProvisioningSendingPDU appendBytes:(char[]){0x07} length:1];   //append pduType
                    [ProvisioningSendingPDU appendData:[_ccm mesh_CCM_encrypt:ProvisioningData K:SessionKey nonce:SessionNonceNew dataLength:ProvisioningData.length MICSize:8]];
                    NSLog(@"ProvisioningSendingPDU: %@", ProvisioningSendingPDU);

                    [peripheral writeValue:ProvisioningSendingPDU
                         forCharacteristic:dataInChar
                                      type:CBCharacteristicWriteWithoutResponse];
                }
            }
            else{
                NSLog(@"authentication failed");
                {
                    //stop the timer
                    [_ProvisionerTimer invalidate];
                    
                    NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus"
                                                                                 object:nil
                                                                            userInfo:@{@"1":@"ProvisioningStatusAuthenticationFailed"}];
                    [[NSNotificationCenter defaultCenter] postNotification:notification];
                }
            }
            
        }
            break;

#pragma mark - ProvisioningPDUTypeComplete
        case ProvisioningPDUTypeComplete: //0x08
            NSLog(@"ProvisioningPDUTypeComplete");
        {
            //stop the timer
            [_ProvisionerTimer invalidate];
            
            //save DeviceKey into UserDefaults NVM
            NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
            [user setObject:_DevKey forKey:@"deviceKeyIdentifier"];
            NSLog(@"DevKey: %@", _DevKey);
            
            //notification to ProvisioningViewController/ProvisioningInterfaceController to show alert, "ProvisioningSuccessful"
            NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus"
                                                                         object:nil
                                                                       userInfo:@{@"1":@"ProvisioningStatusSuccessful"}];
            [[NSNotificationCenter defaultCenter] postNotification:notification];
        }
            break;

#pragma mark - ProvisioningPDUTypeFailed
        case ProvisioningPDUTypeFailed:
            NSLog(@"ProvisioningPDUTypeFailed");
        {
            //stop the timer
            [_ProvisionerTimer invalidate];
            
            //notification to ProvisioningViewController/ProvisioningInterfaceController to show alert, "ProvisioningStatusFailed"
            NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus" object:nil userInfo:@{@"1":@"ProvisioningStatusFailed"}];
            [[NSNotificationCenter defaultCenter] postNotification:notification];
        }
            
        default:
            NSLog(@"unknow ProvisioningPDUType");
            break;
    }
    
}

//retrieve unicast address and update the unicast address pointer depending on numOfElements
- (NSData *)updateUnicastAddressPoll:(UInt8)numOfElements
{
    NSData *unicastAddress;
    UInt16 u16_unicastAddress;
    
    //retrieve unicastAddress
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    u16_unicastAddress = [user integerForKey:@"unicastAddressIdentifier"];
    
    //change it to Uint16
    u16_unicastAddress = CFSwapInt16(u16_unicastAddress);
    unicastAddress = [NSData dataWithBytes:&u16_unicastAddress length:sizeof(UInt16)];
    
    //store unicast address poll pointer to NVM
    u16_unicastAddress = CFSwapInt16(u16_unicastAddress);
    u16_unicastAddress += numOfElements;
    [user setInteger:u16_unicastAddress forKey:@"unicastAddressIdentifier"];
    
    //store primary element to NVM
    [user setObject:unicastAddress forKey:@"primaryElementIdentifier"];
    NSLog(@"primary element: %@", unicastAddress);
        
    return unicastAddress;
}

//get ProvisioningInvitation PDU
- (NSData *)provInvitation{
    NSData *temp = [[NSData alloc]initWithBytes:(char[]){0x03, 0x00, 0x05} length:3];
    return temp;
}

//get ProvisioningStart PDU
- (NSData *)provStart{
    NSMutableData *temp = [[NSMutableData alloc]initWithBytes:(char[]){0x03, 0x02} length:2];
    [temp appendData:_ProvisioningStartPDUValue];
    return temp;
}

@end
