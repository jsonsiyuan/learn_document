//
//  proxy.m
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "Proxy.h"
#import "crypto.h"
#import "NVM.h"

@interface Proxy()
@property (strong, nonatomic) NSData *encryptionKey;
@property (strong, nonatomic) NSData *privacyKey;
@property (strong, nonatomic) NSData *NID;
@property (strong, nonatomic) NSData *TTL;
@property (strong, nonatomic) NSData *Src ;
@property (strong, nonatomic) NSData *Dst ;
@property (strong, nonatomic) NSData *AID;
@property (strong, nonatomic) NSData *IVIndex;
@property (strong, nonatomic) crypto *ccm;
@property (strong, nonatomic) NVM *nvm;
@property UInt8 meshAccessSeq;
@property (strong, nonatomic) NSMutableData *segmentedPDU;
//@property UInt8 numOfElements;
//@property (strong, nonatomic) NSData *primaryElement;
@property (strong, nonatomic) NSData *targetModel;
@property (strong, nonatomic) NSData *targetElement;
//@property (strong, nonatomic) NSData *deviceKey;

@property (strong, nonatomic)NSTimer *modelConfigurationTimer;

@end

//https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.service.mesh_proxy.xml
//mesh proxy service uuid: 0x1828
//mesh proxy data in char uuid: 0x2add
//mesh proxy data out char uuid: 0x2ade

NSString *netkeyString = @"18eed9c2a56add85049ffc3c59ad0e1f";
NSString *appkeyString = @"F30AC76210160E03F2D8B4F1CF4510EF";

UInt8 numSegmentedMessage;

@implementation Proxy

- (instancetype)initWith
{

    if (self = [super init]) {
        _meshProxyServiceUUIDString                 = @"1828";
        _meshProxyDataInCharacteristicUUIDString    = @"2ADD";
        _meshProxyDataOutCharacteristicUUIDString   = @"2ADE";

        _ccm = [[crypto alloc]init];
        
        _nvm = [[NVM alloc]init];
        
        _segmentedPDU = [[NSMutableData alloc]init];
        
        NSString *PString = @"00";
        NSData *N = [crypto dataFormHexString:netkeyString];
        NSData *P = [crypto dataFormHexString:PString];
        NSData *k2Output = [_ccm k2N:N P:P];
        _NID = [k2Output subdataWithRange:NSMakeRange(0, 1)];
        _encryptionKey = [k2Output subdataWithRange:NSMakeRange(1, 16)];
        _privacyKey = [k2Output subdataWithRange:NSMakeRange(17, 16)];
    {
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        _numOfElements = [user integerForKey:@"numOfElementsIdentifier"];
        NSLog(@"_numOfElements: %u", _numOfElements);
        _primaryElement = [user objectForKey:@"primaryElementIdentifier"];
        NSLog(@"_primaryElement: %@", _primaryElement);
        _deviceKey = [user objectForKey:@"deviceKeyIdentifier"];
        NSLog(@"_deviceKey: %@", _deviceKey);
    }
        _targetModel        = [[NSData alloc]initWithBytes:(char[]){0x00, 0x10} length:2];  //GenericOnOff Server
        _IVIndex = [[NSData alloc]initWithBytes:(char[]){0, 0, 0, 0} length:4];
        
        _modelConfigurationTimer = [[NSTimer alloc]init];
    }
    return self;
}

//timerFired callback for provisioning timeout
- (void)modelConfigurationTimerFired:(NSTimer *)timer{
    
    NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus" object:nil userInfo:@{@"1":@"ModelConfigurationTimerFired"}];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    
}

- (NSData *)getNonce:(UInt8)aType
              cTLTTL:(NSData *)cTTL
                 SEQ:(NSData *)aSEQ
                 MIC:(UInt8)aMIC
                 SRC:(NSData *)aSRC
                 DST:(NSData*)aDST
               index:(NSData*)aIV
{
    NSMutableData *nonce = [[NSMutableData alloc]init];
    
    [nonce appendBytes:&aType length:sizeof(UInt8)];   //nonce type

    //networkNonce
    if( 0 == aType){
        [nonce appendData:cTTL]; //CTL+TTL
        [nonce appendData:aSEQ];    //SEQ
        [nonce appendData:aSRC];    //SRC
        [nonce appendBytes:(char[]){0x00, 0x00} length:2];    //padding
        [nonce appendData:aIV];     //IV Index
    }
    else{
        [nonce appendBytes:&aMIC length:sizeof(UInt8)]; //ASZMIC
        [nonce appendData:aSEQ];    //SEQ
        [nonce appendData:aSRC];    //SRC
        [nonce appendData:aDST];    //DST
        [nonce appendData:aIV];     //IV Index
    }
    NSLog(@"getNonce: %@", nonce);
    return nonce;
}

//
- (NSData *)getSeginfoFromSeqZero:(segInfo)aInfo{
    NSMutableData *data = [[NSMutableData alloc]init];
    
    return data;
}

#pragma mark - PDU

- (NSData *)getUnsegAccessMsgByAppKey:(NSData*)netKey
                       AppKey:(NSData*)appKey
                       cTLTTL:(NSData*)aCTLTTL
                          SRC:(NSData*)aSRC
                          DST:(NSData*)aDST
                       IVIdex:(NSData*)aIVI
                       opcode:(NSData*)aOpcode
                        value:(NSData*)aValue
{
    NSMutableData *pdu = [[NSMutableData alloc]init];
    NSData *applicationNonce = [[NSData alloc]init];
    
    //prepare SEQ
    NSData *newSEQ             = [_nvm retrieveSequenceNumber];
    NSLog(@"newSEQ: %@", newSEQ);
    NSLog(@"appKey: %@", appKey);
    
    //prepare network nonce
    NSData *networkNonce = [self getNonce:0x00
                                   cTLTTL:aCTLTTL
                                      SEQ:newSEQ
                                      MIC:0x00
                                      SRC:aSRC
                                      DST:aDST
                                    index:aIVI];
    
    //prepare application nonce
    applicationNonce = [self getNonce:0x01
                                   cTLTTL:aCTLTTL
                                      SEQ:newSEQ
                                      MIC:0x00
                                      SRC:aSRC
                                      DST:aDST
                                    index:aIVI];
    
    
    //prepare access layer PDU
    NSMutableData *accessPDU = [[NSMutableData alloc]init];
    [accessPDU appendData:aOpcode];
    [accessPDU appendData:aValue];
    
    //prepare network PDU which will be encrypted by CCM
    NSMutableData *nwkPDU = [[NSMutableData alloc]init];
    [nwkPDU appendData:aDST];
    
    NSData* AID = [_ccm k4N:appKey];
    UInt8 *u8_AID = (UInt8*)[AID bytes];
    *u8_AID = *u8_AID | 0x40;   //enable AKF
    [nwkPDU appendBytes:u8_AID length:1];
    
    
    NSData *accessENCPDU = [[NSData alloc]init];
    accessENCPDU = [_ccm mesh_CCM_encrypt:accessPDU K:appKey nonce:applicationNonce dataLength:accessPDU.length MICSize:4];
    
    NSLog(@"accessENCPDU: %@", accessENCPDU);
    [nwkPDU appendData:accessENCPDU];
    NSLog(@"nwkPDU: %@", nwkPDU);
    
    NSData* nwkENCPDU = [_ccm mesh_CCM_encrypt:nwkPDU K:netKey nonce:networkNonce dataLength:nwkPDU.length MICSize:4];
    NSLog(@"nwkENCPDU: %@", nwkENCPDU);
    
    //prepare Obfusecation PDU
    [pdu appendBytes:(char[]){0x00} length:1];  //proxy PDU type, networkPDU
    [pdu appendData:_NID];  //append NID
    
    NSData *obfPDU = [_ccm obfuscateEncryptedPDU:nwkENCPDU
                               cTLTTL:aCTLTTL
                            seqNum:newSEQ
                                   IVIndex:aIVI
                                privacyKey:_privacyKey
                                srcAddr:aSRC];
    [pdu appendData:obfPDU];
    [pdu appendData:nwkENCPDU];
    
    return pdu;
}

- (NSData *)getUnsegAccessMsgByDevKey:(NSData*)netKey
                              devKey:(NSData*)devKey
                              cTLTTL:(NSData*)aCTLTTL
                                 SRC:(NSData*)aSRC
                                 DST:(NSData*)aDST
                              IVIdex:(NSData*)aIVI
                              opcode:(NSData*)aOpcode
                               value:(NSData*)aValue
{
    NSMutableData *pdu = [[NSMutableData alloc]init];
    NSData *deviceNonce = [[NSData alloc]init];
    
    //prepare SEQ
    NSData *newSEQ             = [_nvm retrieveSequenceNumber];
    NSLog(@"newSEQ: %@", newSEQ);
    
    //prepare network nonce
    NSData *networkNonce = [self getNonce:0x00
                                   cTLTTL:aCTLTTL
                                      SEQ:newSEQ
                                      MIC:0x00
                                      SRC:aSRC
                                      DST:aDST
                                    index:aIVI];
    
    //prepare deviceNonce
    deviceNonce = [self getNonce:0x02
                              cTLTTL:aCTLTTL
                                 SEQ:newSEQ
                                 MIC:0x00
                                 SRC:aSRC
                                 DST:aDST
                               index:aIVI];
    
    
    
    //prepare access layer PDU
    NSMutableData *accessPDU = [[NSMutableData alloc]init];
    [accessPDU appendData:aOpcode];
    [accessPDU appendData:aValue];
    
    //prepare network PDU which will be encrypted by CCM
    NSMutableData *nwkPDU = [[NSMutableData alloc]init];
    [nwkPDU appendData:aDST];
    
    //use devKey
    [nwkPDU appendBytes:(char[]){0x00} length:1];
    
    
    NSData *accessENCPDU = [[NSData alloc]init];
    accessENCPDU = [_ccm mesh_CCM_encrypt:accessPDU K:devKey nonce:deviceNonce dataLength:accessPDU.length MICSize:4];
    
    NSLog(@"accessENCPDU: %@", accessENCPDU);
    [nwkPDU appendData:accessENCPDU];
    NSLog(@"nwkPDU: %@", nwkPDU);
    
    NSData* nwkENCPDU = [_ccm mesh_CCM_encrypt:nwkPDU K:netKey nonce:networkNonce dataLength:nwkPDU.length MICSize:4];
    NSLog(@"nwkENCPDU: %@", nwkENCPDU);
    
    //prepare Obfusecation PDU
    [pdu appendBytes:(char[]){0x00} length:1];  //proxy PDU type, networkPDU
    [pdu appendData:_NID];  //append NID
    
    NSData *obfPDU = [_ccm obfuscateEncryptedPDU:nwkENCPDU
                               cTLTTL:aCTLTTL
                            seqNum:newSEQ
                                   IVIndex:aIVI
                                privacyKey:_privacyKey
                                srcAddr:aSRC];
    [pdu appendData:obfPDU];
    [pdu appendData:nwkENCPDU];
    
    return pdu;
    
}

- (NSData *)getPDUForModelAppBind:(NSData*)element
                         keyIndex:(NSData*)keyIndex
                      targetModel:(NSData*)model
                              SRC:(NSData*)aSrc
                              DST:(NSData*)aDst

{
    NSMutableData *aValue = [[NSMutableData alloc]init];
    [aValue appendData:element];
    [aValue appendData:keyIndex];
    [aValue appendData:model];
    
    NSData *PDU = [self getUnsegAccessMsgByDevKey:_encryptionKey devKey:_deviceKey cTLTTL:[NSData dataWithBytes:(char[]){0x04} length:1] SRC:aSrc DST:aDst IVIdex:[NSData dataWithBytes:(char[]){0, 0, 0, 0} length:4] opcode:[NSData dataWithBytes:(char[]){0x80, 0x3d} length:2] value:aValue];
    
    return PDU;
}

- (NSData *)getPDUForModelSubcriptionAdd:(NSData*)element
                                targetAddress:(NSData*)address
                             targetModel:(NSData*)model
                                     SRC:(NSData*)aSrc
                                     DST:(NSData*)aDst{
    NSMutableData *aValue = [[NSMutableData alloc]init];
    [aValue appendData: element];
    [aValue appendData:address];
    [aValue appendData:model];
    
    NSData *PDU = [self getUnsegAccessMsgByDevKey:_encryptionKey
                                           devKey:_deviceKey
                                           cTLTTL:[NSData dataWithBytes:(char[]){0x04} length:1]
                                              SRC:aSrc
                                              DST:aDst
                                           IVIdex:[NSData dataWithBytes:(char[]){0, 0, 0, 0} length:4]
                                           opcode:[NSData dataWithBytes:(char[]){0x80, 0x1b} length:2]
                                            value:aValue];
    
    return PDU;
}

- (NSData *)getPDUForGenericOnOffServer:(BOOL)OnOff{
    NSData *SEQ = [_nvm retrieveSequenceNumber];
    _meshAccessSeq = [self convertSEQ2TransID:SEQ];  //update GENERIC_ONOFF_SET application sequence number
    
    NSData *applicationKey = [crypto dataFormHexString:appkeyString];
    NSMutableData *aValue = [[NSMutableData alloc]init];
    UInt8 onoff = (OnOff == true)? 1 : 0;
    [aValue appendBytes:&onoff length:1];   //ONOFF
    [aValue appendBytes:&_meshAccessSeq length:1];  //TID
    [aValue appendBytes:(char[]){0x00, 0x00} length:2]; //Transition Time + Delay
    NSLog(@"aValue: %@", aValue);
    
    NSData *PDU = [self getUnsegAccessMsgByAppKey:_encryptionKey
                                           AppKey:applicationKey
                                           cTLTTL:[NSData dataWithBytes:(char[]){0x04} length:1]
                                              SRC:[NSData dataWithBytes:(char[]){0x01, 0x23} length:2]
                                              DST:[NSData dataWithData:_primaryElement]
                                           IVIdex:[NSData dataWithBytes:(char[]){0, 0, 0, 0} length:4]
                                           opcode:[NSData dataWithBytes:(char[]){0x82, 0x02} length:2]
                                            value:[NSData dataWithData:aValue]];
    
    return PDU;
}

- (NSData*)getElementByModel:(NSData *)CompositionData
              primaryElement:(NSData *)pElement
                 targetModel:(NSData*)tModel{
    //This is the example unicast address
    UInt16 elementValue;
    [pElement getBytes:&elementValue length:pElement.length];
    
    UInt16 CID;
    [CompositionData getBytes:&CID range:NSMakeRange(2, 2)];
    NSLog(@"CID: 0x%X", CID);
    
    UInt16 PID;
    [CompositionData getBytes:&PID range:NSMakeRange(4, 2)];
    NSLog(@"PID: 0x%X", PID);
    
    UInt16 VID;
    [CompositionData getBytes:&VID range:NSMakeRange(6, 2)];
    NSLog(@"VID: 0x%X", VID);
    
    UInt16 CRPL;
    [CompositionData getBytes:&CRPL range:NSMakeRange(8, 2)];
    NSLog(@"CRPL: 0x%X", CRPL);
    
    UInt16 Feature;
    [CompositionData getBytes:&Feature range:NSMakeRange(10, 2)];
    NSLog(@"Feature: 0x%X", Feature);
    
    for (UInt8 elementIndex = 0; elementIndex < _numOfElements; elementIndex++) {
        UInt8 index = 12;   //10 + 2
        UInt16 Loc;
        [CompositionData getBytes:&Loc range:NSMakeRange(index, 2)];
        index += 2;
        
        UInt8 NumS;
        [CompositionData getBytes:&NumS range:NSMakeRange(index, 1)];
        index++;
        
        UInt8 NumV;
        [CompositionData getBytes:&NumV range:NSMakeRange(index, 1)];
        index++;
        
        NSLog(@"Loc: 0x%X, NumS: 0x%X, NumV: 0x%X", Loc, NumS, NumV);
        
        for (UInt8 modelIndex = 0; modelIndex < NumS; modelIndex++) {
            NSData *model = [[NSData alloc]initWithData:[CompositionData subdataWithRange:NSMakeRange(index, 2)]];
            index = index + 2;
            NSLog(@"model: %@, tModel: %@", model, tModel);
            if ([model isEqual:tModel]) {
                elementValue = elementValue + elementIndex;
                elementValue = CFSwapInt16(elementValue);
                NSData *targetElement = [[NSData alloc]initWithBytes:&elementValue length:sizeof(UInt16)];
                NSLog(@"find elementIndex: 0x%X, modelIndex: 0x%X", elementIndex, modelIndex);
                return targetElement;
            }
        }
    }
    
    return nil;
}

//convert PDU to segInfo, it includes:
// * SZMIC, SeqZero, SegO and SegN
- (segInfo)getSeqInfoFromPDU:(NSData*)aPDU{
    segInfo info;
    UInt32 u32_segmentInfo;
    
    [aPDU getBytes:&u32_segmentInfo length:aPDU.length];
    u32_segmentInfo = CFSwapInt32HostToBig(u32_segmentInfo);
    
    info.segO = (u32_segmentInfo >>5) & 0x1f;;
    info.segN = u32_segmentInfo & 0x1f;
    info.seqZero = (u32_segmentInfo >> 10) & 0x1fff;
    
    if (0x80000000 & u32_segmentInfo) {
        info.SZMIC = true;
    }
    else{
        info.SZMIC = false;
    }
    
    return info;   //make compiler happy
}

- (NSData *)prosySegmentedAckMsg:(UInt16)seqZero block:(UInt32)aBlock{
    NSMutableData *data = [[NSMutableData alloc]initWithBytes:(char[]){0x00} length:1];   //AID
    
    //SeqZero
    seqZero = seqZero & 0x1fff;     //13-bit
    seqZero = seqZero << 2;
    
    //assemble seqZero after AID
    UInt8 s0 = seqZero;
    UInt8 s1 = seqZero >> 8;
    [data appendBytes:&s1 length:sizeof(UInt8)];
    [data appendBytes:&s0 length:sizeof(UInt8)];
    
    //assemble blockAck after seqZero
    //BlockAck
    UInt32 u32_BlockAck = 0;
    for (NSInteger i = 0; i < aBlock; i++) {
        u32_BlockAck = u32_BlockAck | 1 << i;
    }
    u32_BlockAck = CFSwapInt32HostToBig(u32_BlockAck);
    [data appendBytes:&u32_BlockAck length:sizeof(UInt32)];
    
    return data;
}

- (void)proxySendModelConfigAppKeyAddMsg:(CBPeripheral *)peripheral dataInChar:(CBCharacteristic *)dataInChar
{
    
    NSMutableData* accessPDUAppKeyAdd = [[NSMutableData alloc]initWithBytes:(char[]){0, 0, 0, 0} length:4];//opcode: 0x00, netkey+appkey: 0x000000
    [accessPDUAppKeyAdd appendData:[crypto dataFormHexString:appkeyString]]; //adding APPKEY
    
    NSData* SEQ1 = [_nvm retrieveSequenceNumber];
    NSLog(@"SEQ1: %@", SEQ1);
    
    UInt32 u32_SeqZero ;
    [SEQ1 getBytes:&u32_SeqZero length:3];
    u32_SeqZero = u32_SeqZero << 8;
    u32_SeqZero = CFSwapInt32HostToBig(u32_SeqZero);
    NSLog(@"u32_SeqZero: 0x%X", (unsigned int)u32_SeqZero);
    
    u32_SeqZero = u32_SeqZero << 10;
    NSLog(@"u32_SeqZero: 0x%X", (unsigned int)u32_SeqZero);
    //UInt32 u32_SegO = 0;
    UInt32 u32_SegN = 1;
    u32_SeqZero |= u32_SegN;
    //u32_SeqZero |= u32_SegN << 5;
    NSLog(@"u32_SeqZero: 0x%X", (unsigned int)u32_SeqZero);
    
    UInt8 u8_SeqZero_0 = u32_SeqZero;
    UInt8 u8_SeqZero_1 = u32_SeqZero >> 8;
    UInt8 u8_SeqZero_2 = u32_SeqZero >> 16;
    
    NSMutableData *SeqZero = [[NSMutableData alloc]init];
    [SeqZero appendBytes:&u8_SeqZero_2 length:1];    //SeqZero
    [SeqZero appendBytes:&u8_SeqZero_1 length:1];    //SeqZero
    [SeqZero appendBytes:&u8_SeqZero_0 length:1];    //SeqZero
    NSLog(@"SeqZero: %@", SeqZero);
    
    //application encrypted msg
    NSData* aNonce = [self getNonce:0x02 cTLTTL:_TTL SEQ:SEQ1 MIC:0x00 SRC:_Dst DST:_Src index:_IVIndex];
    NSData* accessENCPDUAppKeyAdd = [_ccm mesh_CCM_encrypt:accessPDUAppKeyAdd K:_deviceKey nonce:aNonce dataLength:0 MICSize:4];
    NSLog(@"accessENCPDUAppKeyAdd: %@", accessENCPDUAppKeyAdd);
    
    NSMutableData* nwkPDUAppKeyAdd1 = [[NSMutableData alloc]init];
    [nwkPDUAppKeyAdd1 appendData:_Src];// DST
    [nwkPDUAppKeyAdd1 appendBytes:(char[]){0x80} length:1]; //SEG+AID
    [nwkPDUAppKeyAdd1 appendData:SeqZero];
    [nwkPDUAppKeyAdd1 appendData:[accessENCPDUAppKeyAdd subdataWithRange:NSMakeRange(0, 12)]];
    NSLog(@"nwkPDUAppKeyAdd1: %@", nwkPDUAppKeyAdd1);
    
    NSData *nNonce1 = [self getNonce:0x00 cTLTTL:_TTL SEQ:SEQ1 MIC:0x00 SRC:_Dst DST:_Src index:_IVIndex];
    NSData* nwkENCPDUAppKeyAdd1 = [_ccm mesh_CCM_encrypt:nwkPDUAppKeyAdd1
                                             K:_encryptionKey
                                               nonce:nNonce1
                                            dataLength:0
                                          MICSize:4];
    NSLog(@"nwkENCPDUAppKeyAdd1: %@", nwkENCPDUAppKeyAdd1);
    
    
    NSData* obfPDUAppKeyAdd1 = [[NSData alloc]init];
    obfPDUAppKeyAdd1 = [_ccm obfuscateEncryptedPDU:nwkENCPDUAppKeyAdd1 cTLTTL:_TTL seqNum:SEQ1 IVIndex:_IVIndex privacyKey:_privacyKey srcAddr:_Dst];
    NSLog(@"obfPDUAppKeyAdd1: %@", obfPDUAppKeyAdd1);
    
    NSMutableData* PDU1 = [[NSMutableData alloc]init];
    [PDU1 appendBytes:(char[]){0x00} length:1];
    [PDU1 appendData:_NID];
    [PDU1 appendData:obfPDUAppKeyAdd1];
    [PDU1 appendData:nwkENCPDUAppKeyAdd1];
    NSLog(@"PDU1: %@", PDU1);
    
    [peripheral writeValue:PDU1 forCharacteristic:dataInChar type:CBCharacteristicWriteWithoutResponse];
    
    
//Model Config AppKey Add2
    //[NSThread sleepForTimeInterval:0.2];
    NSData* SEQ2 = [_nvm retrieveSequenceNumber];
    NSLog(@"SEQ2: %@", SEQ2);
    
    u32_SeqZero |= 0x01 << 5;
    NSLog(@"u32_SeqZero: 0x%X", (unsigned int)u32_SeqZero);
    
    u8_SeqZero_0 = u32_SeqZero;
    u8_SeqZero_1 = u32_SeqZero >> 8;
    u8_SeqZero_2 = u32_SeqZero >> 16;
    
    NSMutableData *SeqZero2 = [[NSMutableData alloc]init];
    [SeqZero2 appendBytes:&u8_SeqZero_2 length:1];    //SeqZero
    [SeqZero2 appendBytes:&u8_SeqZero_1 length:1];    //SeqZero
    [SeqZero2 appendBytes:&u8_SeqZero_0 length:1];    //SeqZero
    NSLog(@"SeqZero2: %@", SeqZero2);
    
    NSMutableData* nwkPDUAppKeyAdd2 = [[NSMutableData alloc]init];
    [nwkPDUAppKeyAdd2 appendData:_Src];// DST
    [nwkPDUAppKeyAdd2 appendBytes:(char[]){0x80} length:1]; //SEG+AID
    [nwkPDUAppKeyAdd2 appendData:SeqZero2];
    [nwkPDUAppKeyAdd2 appendData:[accessENCPDUAppKeyAdd subdataWithRange:NSMakeRange(12, 12)]];
    NSLog(@"nwkPDUAppKeyAdd2: %@", nwkPDUAppKeyAdd2);
    
    NSData *nNonce2 = [self getNonce:0x00 cTLTTL:_TTL SEQ:SEQ2 MIC:0x00 SRC:_Dst DST:_Src index:_IVIndex];
    NSData* nwkENCPDUAppKeyAdd2 = [_ccm mesh_CCM_encrypt:nwkPDUAppKeyAdd2 K:_encryptionKey nonce:nNonce2 dataLength:0 MICSize:4];
    NSLog(@"nwkENCPDUAppKeyAdd2: %@", nwkENCPDUAppKeyAdd2);
    
    NSData* obfPDUAppKeyAdd2 = [[NSData alloc]init];
    obfPDUAppKeyAdd2 = [_ccm obfuscateEncryptedPDU:nwkENCPDUAppKeyAdd2
                                            cTLTTL:_TTL
                                            seqNum:SEQ2
                                           IVIndex:_IVIndex
                                        privacyKey:_privacyKey
                                           srcAddr:_Dst];
    NSLog(@"obfPDUAppKeyAdd2: %@", obfPDUAppKeyAdd2);
    
    NSMutableData *PDU2 = [[NSMutableData alloc]init];
    [PDU2 appendBytes:(char[]){0x00} length:1];
    [PDU2 appendData:_NID];
    [PDU2 appendData:obfPDUAppKeyAdd2];
    [PDU2 appendData:nwkENCPDUAppKeyAdd2];
    
    NSLog(@"PDU2: %@", PDU2);
    
    [peripheral writeValue:PDU2 forCharacteristic:dataInChar type:CBCharacteristicWriteWithoutResponse];
}

- (void)proxySendSegmentedAckMsg:(CBPeripheral*)peripheral dataInChar:(CBCharacteristic *)dataInChar SegInfo:(segInfo)segInfo
{
    //send 3.5.2.3.1 Segment Acknowledgment message
    
    NSData *newSEQ             = [_nvm retrieveSequenceNumber];
    NSLog(@"newSEQ: %@", newSEQ);
    
    //networkNonce
    NSData *cTLTTL = [[NSData alloc]initWithBytes:(char[]){0x87} length:1];
    NSData *networkNonce = [[NSData alloc]initWithData:[self getNonce:0x00 cTLTTL:cTLTTL SEQ:newSEQ MIC:0x00 SRC:_Dst DST:_Src index:_IVIndex]];
    
    NSMutableData *outNwkRawPDU = [[NSMutableData alloc]init];
    [outNwkRawPDU appendData:_Src]; //DST
    [outNwkRawPDU appendData:[self prosySegmentedAckMsg:segInfo.seqZero block:numSegmentedMessage]];
    NSLog(@"outNwkRawPDU: %@", outNwkRawPDU);
    
    NSData *outNwkEncPDU = [_ccm mesh_CCM_encrypt:outNwkRawPDU
                                      K:_encryptionKey
                                        nonce:networkNonce
                                     dataLength:outNwkRawPDU.length
                                   MICSize:8];
    NSLog(@"outNwkEncPDU: %@", outNwkEncPDU);
    
    
    NSData *newCTTL = [[NSData alloc]initWithBytes:(char[]){0x87} length:1];
    NSData* outNwkObPDU = [_ccm obfuscateEncryptedPDU:outNwkEncPDU
                                    cTLTTL:newCTTL
                                 seqNum:newSEQ
                                        IVIndex:_IVIndex
                                     privacyKey:_privacyKey
                                     srcAddr:_Dst];
    
    NSMutableData *outNwkPDU = [[NSMutableData alloc]initWithBytes:(char[]){0x00} length:1];  //Proxy
    [outNwkPDU appendData:_NID]; //+ NID
    [outNwkPDU appendData:outNwkObPDU];
    [outNwkPDU appendData:outNwkEncPDU];
    
    NSLog(@"full: %@", outNwkPDU);
    
    [peripheral writeValue: outNwkPDU
         forCharacteristic: dataInChar
                      type:CBCharacteristicWriteWithoutResponse];
}

#pragma mark - mesh Proxy parser
//parser incoming packet
- (void)proxyPDUParser:(CBPeripheral *)peripheral
            dataInChar: (CBCharacteristic *)dataInChar
           dataOutChar: (CBCharacteristic *)dataOutChar
             //deviceKey: (NSData *)aKey
{
    NSData *nwkSEQ;
    UInt8 pduType ;
    
    NSLog(@"imcoming PDU: %@", dataOutChar);
    
    //data [0], SAR+PDUTyp e
    [dataOutChar.value getBytes:&pduType range:NSMakeRange(0, 1)];
    
    switch (pduType & 0x3F) {
        case 0x00:
        {
            NSLog(@"Proxy - Network");
#if 0
            NSLog(@"obfPDU: %@", [dataOutChar.value subdataWithRange:NSMakeRange(1, dataOutChar.value.length - 1)]);
            NSLog(@"encPDU: %@", [dataOutChar.value subdataWithRange:NSMakeRange(8, dataOutChar.value.length - 8)]);
            NSLog(@"encMIC: %@", [dataOutChar.value subdataWithRange:NSMakeRange(dataOutChar.value.length - 4, 4)]);
#endif
            
#pragma mark Deobfusecation
            NSData *obfNwkPDU = [[NSData alloc]initWithData:[dataOutChar.value subdataWithRange:NSMakeRange(1, dataOutChar.value.length - 1)]];
            NSData *encNwkPDU = [[NSData alloc]initWithData:[dataOutChar.value subdataWithRange:NSMakeRange(8, dataOutChar.value.length - 8 )]];
            NSData *encNwkMIC = [[NSData alloc]init];
            
            NSData *deObfNwkPDU = [_ccm deObfuscation:obfNwkPDU IVIndex:_IVIndex privacyKey:_privacyKey];
            NSLog(@"deObfNwkPDU: %@", deObfNwkPDU);
            
            //nwkNID  = [obfNwkPDU subdataWithRange:NSMakeRange(0, 1)];      //IVI+NID
            _TTL = [deObfNwkPDU subdataWithRange:NSMakeRange(0, 1)];    //CTL+TTL
            nwkSEQ  = [deObfNwkPDU subdataWithRange:NSMakeRange(1, 3)];     //SEQ
            _Src  = [deObfNwkPDU subdataWithRange:NSMakeRange(4, 2)];     //SRC
            
#pragma mark Decryption
            //network nonce
            NSData *networkNonce = [self getNonce:0x00
                                           cTLTTL:_TTL
                                              SEQ:nwkSEQ
                                              MIC:0x00
                                              SRC:_Src
                                              DST:_Dst
                                            index:_IVIndex];
            
            
            //decrypted network PDU
            NSData *decNwkPDU = [_ccm mesh_CCM_decrypt:encNwkPDU
                                                   MIC:encNwkMIC
                                                         key:_encryptionKey
                                                       nonce:networkNonce];
            NSLog(@"decNwkPDU: %@", decNwkPDU);
            
            //Lower Transportation PDU
            _Dst = [decNwkPDU subdataWithRange:NSMakeRange(0, 2)];
            
            UInt8 u8_AID;
            [decNwkPDU getBytes:&u8_AID range:NSMakeRange(2, 1)];   //DST+AID
            NSLog(@"u8_AID: 0x%X", u8_AID );
            
#pragma mark Incoming PDU Parser
            //determine the message is segmented or unsegmented
            if(0x80 & u8_AID){
#pragma mark Segmented MSG
                
                

                segInfo segInfo = [self getSeqInfoFromPDU:[decNwkPDU subdataWithRange:NSMakeRange(2, 4)]];
                
                NSLog(@"SZMIC: %@ SeqZero: 0x%X, SegO: 0x%X, SegN: 0x%X, numSegmentedMessage: 0x%X", segInfo.SZMIC? @"YES":@"No", segInfo.seqZero, segInfo.segO, segInfo.segN, numSegmentedMessage);

                if(0 == segInfo.segO ){
                    [_segmentedPDU appendData:[decNwkPDU subdataWithRange:NSMakeRange(6, decNwkPDU.length - 6 - 4)]];   //don't cut MIC, it's nwkMIC
                    numSegmentedMessage = 1;  //segmented message counter
                }
                else if ( segInfo.segO < segInfo.segN){
                    [_segmentedPDU appendData:[decNwkPDU subdataWithRange:NSMakeRange(6, decNwkPDU.length - 6 - 4)]];
                    //NSLog(@"");
                    numSegmentedMessage++;  //segmented message counter
                }
                else if(( segInfo.segN == segInfo.segO ) && (numSegmentedMessage == segInfo.segN ) ){
                    [_segmentedPDU appendData:[decNwkPDU subdataWithRange:NSMakeRange(6, decNwkPDU.length - 6 - 4)]];
                    NSLog(@"_segmentedPDU: %@", _segmentedPDU);
                    
                    UInt32 u32_seqAuth = 0;
                    [nwkSEQ getBytes:&u32_seqAuth length:3];
                    u32_seqAuth = CFSwapInt32HostToBig(u32_seqAuth) >> 8 ;
                    u32_seqAuth = u32_seqAuth & 0xffe000;
                    u32_seqAuth = u32_seqAuth | segInfo.seqZero;
                    NSLog(@"u32_seqAuth: 0x%08X", (unsigned int)u32_seqAuth);
                    
                    UInt8 u8_seqAuth_0 = u32_seqAuth;
                    UInt8 u8_seqAuth_1 = u32_seqAuth >> 8;
                    UInt8 u8_seqAuth_2 = u32_seqAuth >> 16;
                    
                    NSMutableData *seqAuth = [[NSMutableData alloc]init];
                    [seqAuth appendBytes:&u8_seqAuth_2 length:1];    //seqAuth
                    [seqAuth appendBytes:&u8_seqAuth_1 length:1];    //seqAuth
                    [seqAuth appendBytes:&u8_seqAuth_0 length:1];    //seqAuth
                    
                    //device nonce
                    NSData *deviceNonce = [[NSData alloc]initWithData:[self getNonce:0x02
                                                                              cTLTTL:_TTL
                                                                                 SEQ:seqAuth
                                                                                 MIC:0x80
                                                                                 SRC:_Src
                                                                                 DST:_Dst
                                                                               index:_IVIndex]];
                    
                    //MIC
                    NSData *MIC = [_segmentedPDU subdataWithRange:NSMakeRange(_segmentedPDU.length - 8, 8)];
                    NSLog(@"MIC: %@", MIC);
                    NSData *decUpperPDU = [_ccm mesh_CCM_decrypt:_segmentedPDU
                                                             MIC:MIC
                                                                    key:_deviceKey
                                                                  nonce:deviceNonce];
                    
                    NSLog(@"decUpperPDU: %@", decUpperPDU);
                    
                    _targetElement = [self getElementByModel:decUpperPDU primaryElement:_primaryElement targetModel:_targetModel];
                    NSLog(@"_targetElement: %@", _targetElement);

#pragma mark Segment Acknowledgment Message
                    [self proxySendSegmentedAckMsg:peripheral dataInChar:dataInChar SegInfo:segInfo];
                    
                    //reset _segmentedPDU
                    [_segmentedPDU resetBytesInRange:NSMakeRange(0, _segmentedPDU.length)];
                    _segmentedPDU.length = 0;
                    NSLog(@"_segmentedPDU empty: %@", _segmentedPDU);
                    numSegmentedMessage = 0;
                    
                    [self proxySendModelConfigAppKeyAddMsg:peripheral dataInChar:dataInChar];
                }
            }
            else{
#pragma mark Unsegmented Access PDU
                if(0x40 & u8_AID){
                    NSLog(@"appKey Encryption");
                    NSData *appNonce = [self getNonce:0x01 cTLTTL:_TTL SEQ:nwkSEQ MIC:0x00 SRC:_Src DST:_Dst index:_IVIndex];
                    NSData *decAccessMsgByAppKey =[_ccm mesh_CCM_decrypt:[decNwkPDU subdataWithRange:NSMakeRange(3, decNwkPDU.length - 3)] MIC:[decNwkPDU subdataWithRange:NSMakeRange(decNwkPDU.length - 4, 4)] key:_deviceKey nonce:appNonce];
                    NSLog(@"decAccessMsgByAppKey: %@", decAccessMsgByAppKey);
                    
                }
                else{
                    NSLog(@"DevKey Encryption");
                    NSData *devNonce = [self getNonce:0x02 cTLTTL:_TTL SEQ:nwkSEQ MIC:0x00 SRC:_Src DST:_Dst index:_IVIndex];

                    NSData *data = [decNwkPDU subdataWithRange:NSMakeRange(3, decNwkPDU.length - 3 - 4)];
                    NSData *MIC = [decNwkPDU subdataWithRange:NSMakeRange(decNwkPDU.length - 4 - 4, 4)];
                    NSLog(@"data: %@", data);
                    NSLog(@"MIC: %@", MIC);
                    
                    NSData *decAccessMsgByDevKey = [_ccm mesh_CCM_decrypt:data MIC:MIC key:_deviceKey nonce:devNonce];
                    NSLog(@"decAccessMsgByDevKey: %@", decAccessMsgByDevKey);
                    
                    NSData *opcode = [decAccessMsgByDevKey subdataWithRange:NSMakeRange(0, 2)]; //get opcode
                    
                    if( [opcode isEqual:[NSData dataWithBytes:(char[]){0x80, 0x03} length:2] ] ){
                        NSLog(@"App Key Status");
                        //Sending Model App Bind Message
                        [peripheral writeValue:[self getPDUForModelAppBind:[NSData dataWithData:_targetElement]
                                                                  keyIndex:[NSData dataWithBytes:(char[]){0x00, 0x00} length:2]
                                                               targetModel:[NSData dataWithBytes:(char[]){0x00, 0x10} length:2]
                                                                       SRC:[NSData dataWithBytes:(char[]){0x01, 0x23} length:2]
                                                                       DST:[NSData dataWithData:_primaryElement]] forCharacteristic:dataInChar type:CBCharacteristicWriteWithoutResponse];

                    }
                    else if ([opcode isEqual:[NSData dataWithBytes:(char[]){0x80, 0x3e} length:2] ]){
                        NSLog(@"Model App Bind Status");
                        //Sending Model Subscription Add Message
                        [peripheral writeValue:[self getPDUForModelSubcriptionAdd:[NSData dataWithData:_targetElement]
                                                                    targetAddress:[NSData dataWithBytes:(char[]){0x00, 0xC0} length:2]
                                                                      targetModel:[NSData dataWithBytes:(char[]){0x00, 0x10} length:2]
                                                                              SRC:[NSData dataWithBytes:(char[]){0x01, 0x23} length:2]
                                                                              DST:[NSData dataWithData:_primaryElement]] forCharacteristic:dataInChar type:CBCharacteristicWriteWithoutResponse];
                    }
                    else if ([opcode isEqual:[NSData dataWithBytes:(char[]){0x80, 0x1f} length:2] ]){
                        //stop model configuration timer
                        [_modelConfigurationTimer invalidate];
                        
                        //Model Configuration is done!
                        NSLog(@"Model Subscription Status");
                        
                        NSNotification *notification = [NSNotification notificationWithName:@"ProvisioningStatus" object:nil userInfo:@{@"1":@"ModelConfigurationStatusSuccessful"}];
                        [[NSNotificationCenter defaultCenter] postNotification:notification];
                    }
                }
            }
        }
            break;
            
        case 0x01:
            NSLog(@"Proxy - Mesh Beacon");
            [peripheral writeValue:[self prepareModelConfig:_deviceKey destAddr:nil modelID:nil value:nil]
                             forCharacteristic: dataInChar
                                          type:CBCharacteristicWriteWithoutResponse];
            
            _modelConfigurationTimer = [NSTimer scheduledTimerWithTimeInterval:5
                                                                        target:self
                                                            selector:@selector(modelConfigurationTimerFired:)
                                                                      userInfo:nil
                                                                       repeats:NO];
            break;
            
        default:
            break;
    }
}

#pragma mark - utility
- (UInt8)convertSEQ2TransID:(NSData*)aData{
    UInt32 value;
    [aData getBytes:&value length:sizeof(value)];
    NSLog(@"accessSeq: 0x%X", (unsigned int)(value >> 16));
    return value >> 16;
}

- (NSData *) prepareModelConfig:(NSData *)devKey destAddr: (NSData *)dst modelID:(NSData *)id value:(NSData *)value{
    //prepare sequence number
    NSData *SEQ             = [_nvm retrieveSequenceNumber];
    
    //application raw data, Config Composition Data Get
    NSData *model = [[NSData alloc]initWithBytes:(char[]){0x80, 0x08} length:2];
    
    //application raw data, Config Composition Data Get, page = 0xff
    UInt8 page = 0xff; //page 255
    
    NSMutableData *accessPDU = [[NSMutableData alloc]init];
    [accessPDU appendData:model];
    [accessPDU appendBytes:&page length:1];
    NSLog(@"Access Raw Data: %@", accessPDU);

    //prepare accessNonce
    NSMutableData *accessNonce = [[NSMutableData alloc]init];
    
    UInt8 nonceType = 0x02;
    UInt16 pad = 0x0000;
    
    NSData *IVIndex         = [[NSData alloc]initWithBytes:(char[]){0, 0, 0, 0}         length:4];
    NSMutableData *NID      = [[NSMutableData alloc]initWithBytes:(char[]){0x00}        length:1];
    [NID appendData:_NID];
    NSData *TTL             = [[NSMutableData alloc]initWithBytes:(char[]){0x08}        length:1];
    
    NSLog(@"Seq: %@", SEQ);
    NSData *SRC             = [[NSMutableData alloc]initWithBytes:(char[]){0x01, 0x26}  length:2];
    NSData *DST             = [[NSMutableData alloc]initWithData:_primaryElement];
    
    NSMutableData *networkPDU = [[NSMutableData alloc]init];
    
    [accessNonce appendBytes:&nonceType length:sizeof(nonceType)];
    [accessNonce appendBytes:&pad length:1];
    [accessNonce appendData:SEQ];
    [accessNonce appendData:SRC];
    [accessNonce appendData:DST];
    [accessNonce appendData:IVIndex];
    NSLog(@"accessNonce: %@", accessNonce);
    
    //AID, unsegmented, AF = 0, SEQ = 0, App Key Identifier = 0x00
    UInt8 AID = 0x00;
    NSLog(@"AID: %x", AID);
    
    NSLog(@"DeviceKey: %@", devKey);
    
    
    NSLog(@"encAccessMessage: %@", [_ccm mesh_CCM_encrypt:accessPDU
                                              K:devKey
                                                nonce:accessNonce
                                             dataLength:3
                                           MICSize:4]);
    
    //network layer raw data, network nonce
    NSMutableData *networkNonce = [[NSMutableData alloc]init];
    nonceType = 0x00;
    [networkNonce appendBytes:&nonceType length:1];
    [networkNonce appendData:TTL];
    [networkNonce appendData:SEQ];
    [networkNonce appendData:SRC];
    [networkNonce appendBytes:&pad length:2];
    [networkNonce appendData:IVIndex];
    NSLog(@"networkNonce: %@", networkNonce);
    
    [networkPDU appendData:DST];
    [networkPDU appendBytes:&AID length:1];
    [networkPDU appendData:[_ccm mesh_CCM_encrypt:accessPDU
                                      K:devKey
                                        nonce:accessNonce
                                     dataLength:3
                                   MICSize:4]];
    NSLog(@"networkPDU: %@", networkPDU);
    
    NSData *enc = [_ccm mesh_CCM_encrypt:networkPDU
                             K:_encryptionKey
                               nonce:networkNonce
                            dataLength:networkPDU.length
                          MICSize:4];
    NSLog(@"encNetPdu: %@", enc);
    
    NSData* obData = [_ccm obfuscateEncryptedPDU:enc
                               cTLTTL:TTL
                            seqNum:SEQ
                                   IVIndex:IVIndex
                                privacyKey:_privacyKey
                                srcAddr:SRC];
    
    [NID appendData:obData];
    [NID appendData:enc];
    
    NSLog(@"full: %@", NID);
    
    return NID;
}



@end
