//
//  SequenceNumber.m
//
//  Created by RenKai on 2018/10/22.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "NVM.h"

@interface NVM()
@property (weak, nonatomic) NSUserDefaults *userDefaults;
@end

NSString *seqIdentifier         = @"SequenceNumber";
UInt32 u32_sequenceNumber;

@implementation NVM
- (instancetype)init{
    if (self = [super init]) {
        //Initial user default area and Sequence Number is stored here
        _userDefaults = [NSUserDefaults standardUserDefaults];
        NSInteger seqNumber       = [_userDefaults integerForKey:seqIdentifier];
        
        NSLog(@"%ld", (long)seqNumber);
        
        if (!seqNumber) {
            // if there is no value for the key, set it to 1
            u32_sequenceNumber = 1;
            [_userDefaults setInteger:u32_sequenceNumber forKey:seqIdentifier];
            [_userDefaults synchronize];
        }
        else{
            u32_sequenceNumber = (UInt32)seqNumber;
        }
    }
    
    return self;
}

//increase Sequence Number, store it in NVM and return it as NSData
- (NSData *)retrieveSequenceNumber{
    [self incrementAndStore];
    return [self convertToData:u32_sequenceNumber];
}

- (void)incrementAndStore{
    u32_sequenceNumber += 1;
    [_userDefaults setInteger:u32_sequenceNumber forKey:seqIdentifier];
    [_userDefaults synchronize];
}

- (NSData *)convertToData:(UInt32) aNumber{
    UInt8 octet1 = (aNumber & 0x00FF0000) >> 16;
    UInt8 octet2 = (aNumber & 0x0000FF00) >> 8;
    UInt8 octet3 = aNumber & 0x000000FF;
    NSData* data = [[NSData alloc]initWithBytes:(UInt8[]){octet1, octet2, octet3} length:3];
    return data;
}

@end
