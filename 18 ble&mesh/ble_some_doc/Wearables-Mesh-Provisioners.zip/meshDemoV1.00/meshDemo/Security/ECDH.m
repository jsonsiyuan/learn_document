//
//  ECDH.m
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//
//

#import "ECDH.h"



static int getRandomNumber(uint64_t *p_vli, int NUM_ECC_DIGITS)
{
    int success = SecRandomCopyBytes(kSecRandomDefault, NUM_ECC_DIGITS * 8, (uint8_t*)p_vli);
    return (success == 0) ? 1: 0;
}


@interface ECDH () {
    int _bytes, _numDigits;
    uint64_t *_curve_p, *_curve_b, *_curve_Gx, *_curve_Gy, *_curve_n;
    NSData *_publicKey;
}

@end


@implementation ECDH

+ (NSData *)getAuthValue{
    NSData *authValue = [[NSData alloc]initWithBytes:(char[]){0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} length:16];
    return authValue;
}

+ (NSData *)getRandomNumber{
    
    uint64_t RN_MSB, RN_LSB;
    
    getRandomNumber(&RN_MSB, 1);
    getRandomNumber(&RN_LSB, 1);

    NSMutableData *randomNumber = [[NSMutableData alloc]initWithBytes:&RN_MSB length:sizeof(uint64_t)];
    [randomNumber appendBytes:&RN_LSB length:sizeof(uint64_t)];
    return randomNumber;
}

+ (SecKeyRef)getSecKeyFromPublicKey:(NSData *)publicKey
{
    NSMutableData *secPublicKey = [[NSMutableData alloc]initWithBytes:(char[]){0x04} length:1];
    [secPublicKey appendData:publicKey];
    
    NSMutableDictionary *keyPairAttr = [[NSMutableDictionary alloc] init];
    
    //type
    [keyPairAttr setObject:(__bridge id)kSecAttrKeyTypeECSECPrimeRandom
                    forKey:(__bridge id)kSecAttrKeyType];
    
    //class
    [keyPairAttr setObject:(__bridge id)kSecAttrKeyClassPublic forKey:(__bridge id)kSecAttrKeyClass];
    
    //error
    CFErrorRef *createKeyError = nil;
    
    //convert
    SecKeyRef SecPublicKey = SecKeyCreateWithData((CFDataRef)secPublicKey, (__bridge CFDictionaryRef)keyPairAttr, createKeyError);
    
    return SecPublicKey;
    
}

+ (NSData *)ecdhSecretCalculation:(SecKeyRef *)publicKey private:(SecKeyRef *)privateKey
{
    //ECDH calculation
    CFErrorRef* error = nil;
    NSMutableDictionary *keyPairAttr = [[NSMutableDictionary alloc] init];
    
    //type
    [keyPairAttr setObject:(__bridge id)kSecAttrKeyTypeECSECPrimeRandom
                    forKey:(__bridge id)kSecAttrKeyType];
    

    SecKeyAlgorithm algorithm = kSecKeyAlgorithmECDHKeyExchangeStandardX963SHA256;
    
    CFDataRef shared = SecKeyCopyKeyExchangeResult(*privateKey,
                                                   algorithm,
                                                   *publicKey,
                                                   (__bridge CFDictionaryRef)keyPairAttr,
                                                   error);
    
    NSData *ecdhSecret = (__bridge_transfer NSData*)shared;
    
    return ecdhSecret;
}

+ (NSData *)getPublicKeyFromSecKey:(SecKeyRef *) secPublicKey{
    CFErrorRef*  copyExternalError = nil;
    CFDataRef  representation = SecKeyCopyExternalRepresentation(*secPublicKey, copyExternalError);
    if (copyExternalError) {
        NSLog(@"copyExternalError");
    }
    
    //signed long dataLength = CFDataGetLength(representation);
    UInt8 byteBuffer[64];
    CFDataGetBytes(representation, CFRangeMake(1, 64), byteBuffer);
    
    NSData *provPublicKey = [[NSData alloc]initWithBytes:byteBuffer length: 64];

    return provPublicKey;
}

+ (void)generateKeyPair:(SecKeyRef *)publicKey privateTag:(SecKeyRef *)privateKey {
    NSMutableDictionary *privateKeyAttr = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *publicKeyAttr = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *keyPairAttr = [[NSMutableDictionary alloc] init];
    
    //type
    [keyPairAttr setObject:(__bridge id)kSecAttrKeyTypeECSECPrimeRandom
                    forKey:(__bridge id)kSecAttrKeyType];
    //length
    [keyPairAttr setObject:[NSNumber numberWithInt:256]
                    forKey:(__bridge id)kSecAttrKeySizeInBits];
    
    [privateKeyAttr setObject:[NSNumber numberWithBool:false] forKey:(__bridge id)kSecAttrIsPermanent];
    [publicKeyAttr setObject:[NSNumber numberWithBool:false] forKey:(__bridge id)kSecAttrIsPermanent];
    
    [keyPairAttr setObject:privateKeyAttr forKey:(__bridge id)kSecPrivateKeyAttrs];
    [keyPairAttr setObject:publicKeyAttr forKey:(__bridge id)kSecPublicKeyAttrs];
    
    OSStatus err = SecKeyGeneratePair((__bridge CFDictionaryRef)keyPairAttr, publicKey, privateKey);
    err = err; //make compiler happy
}

@end
