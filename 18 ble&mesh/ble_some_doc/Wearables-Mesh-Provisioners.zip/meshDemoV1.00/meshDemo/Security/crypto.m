 //
//  crypto.m
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "crypto.h"
#import <CommonCrypto/CommonCryptor.h>

#define _blocksCount 1024
#define _bufferSize (_blocksCount * kCCBlockSizeAES128)

@implementation crypto


#pragma mark - CMAC

/* For CMAC Calculation */
unsigned char const_Rb[16] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x87
};
unsigned char const_Zero[16] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* Basic Functions */

void xor_128(unsigned char *a, unsigned char *b, unsigned char *out)
{
    int i;
    for (i=0;i<16; i++)
    {
        out[i] = a[i] ^ b[i];
    }
}

/* AES-CMAC Generation Function */

void leftshift_onebit(unsigned char *input,unsigned char *output)
{
    int         i;
    unsigned char overflow = 0;
    
    for ( i=15; i>=0; i-- ) {
        output[i] = input[i] << 1;
        output[i] |= overflow;
        overflow = (input[i] & 0x80)?1:0;
    }
    return;
}

void generate_subkey(unsigned char *key, unsigned char *K1, unsigned
                     char *K2)
{
    unsigned char L[16];
    unsigned char Z[16];
    unsigned char tmp[16];
    int i;
    
    for ( i=0; i<16; i++ ) Z[i] = 0;
    
    //AES_128(key,Z,L);
    size_t outLength;
    
    CCCryptorStatus result = CCCrypt(kCCEncrypt,
                                     kCCAlgorithmAES128,
                                     kCCOptionECBMode,
                                     key,
                                     16,
                                     nil,
                                     Z,
                                     16,
                                     L,
                                     16,
                                     &outLength);
    
    if (result != kCCSuccess) {
        //Catch the error here
        NSLog(@"AES128 Encryption Error");
        //_errorMessage = @"AES128 Encryption Error";
        //_errorNumber = 4;
    }
    
    if ( (L[0] & 0x80) == 0 ) { /* If MSB(L) = 0, then K1 = L << 1 */
        leftshift_onebit(L,K1);
    } else {    /* Else K1 = ( L << 1 ) (+) Rb */
        leftshift_onebit(L,tmp);
        xor_128(tmp,const_Rb,K1);
    }
    
    if ( (K1[0] & 0x80) == 0 ) {
        leftshift_onebit(K1,K2);
    } else {
        leftshift_onebit(K1,tmp);
        xor_128(tmp,const_Rb,K2);
    }
    return;
}

void padding ( unsigned char *lastb, unsigned char *pad, int length )
{
    int         j;
    
    /* original last block */
    for ( j=0; j<16; j++ ) {
        if ( j < length ) {
            pad[j] = lastb[j];
        } else if ( j == length ) {
            pad[j] = 0x80;
        } else {
            pad[j] = 0x00;
        }
    }
}

void AES_CMAC ( unsigned char *key, unsigned char *input, int length,
               unsigned char *mac )
{
    unsigned char       X[16],Y[16], M_last[16], padded[16];
    unsigned char       K1[16], K2[16];
    int         n, i, flag;
    generate_subkey(key,K1,K2);
    
    n = (length+15) / 16;       /* n is number of rounds */
    
    if ( n == 0 ) {
        n = 1;
        flag = 0;
    } else {
        if ( (length%16) == 0 ) { /* last block is a complete block */
            flag = 1;
        } else { /* last block is not complete block */
            flag = 0;
        }
    }
    
    if ( flag ) { /* last block is complete block */
        xor_128(&input[16*(n-1)],K1,M_last);
    } else {
        padding(&input[16*(n-1)],padded,length%16);
        xor_128(padded,K2,M_last);
    }
    
    for ( i=0; i<16; i++ ) X[i] = 0;
    for ( i=0; i<n-1; i++ ) {
        xor_128(X,&input[16*i],Y); /* Y := Mi (+) X  */
        //AES_128(key,Y,X);      /* X := AES-128(KEY, Y); */
        size_t outLength;
        
        CCCryptorStatus result = CCCrypt(kCCEncrypt,
                                         kCCAlgorithmAES128,
                                         kCCOptionECBMode,
                                         key,
                                         16,
                                         nil,
                                         Y,
                                         16,
                                         X,
                                         16,
                                         &outLength);
        
        if (result != kCCSuccess) {
            NSLog(@"AES128 Encryption Error");
        }
    }
    
    xor_128(X,M_last,Y);
    
    size_t outLength;
    
    CCCryptorStatus result = CCCrypt(kCCEncrypt,
                                     kCCAlgorithmAES128,
                                     kCCOptionECBMode,
                                     key,
                                     16,
                                     nil,
                                     Y,
                                     16,
                                     X,
                                     16,
                                     &outLength);
    
    if (result != kCCSuccess) {
        NSLog(@"AES128 Encryption Error");
    }
    
    for ( i=0; i<16; i++ ) {
        mac[i] = X[i];
    }
}

- (NSData*) SALT: (NSData*) M {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.4
    unsigned char ZERO[16] = {0x00};
    
    NSData* zeroKey = [[NSData alloc] initWithBytes:ZERO length:16];
    return [self mesh_CMAC:M K: zeroKey];
}

- (NSData*) mesh_CMAC: (NSData*) data K: (NSData*) nsKey {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.2
    //k is the 128-bit key
    //m is the variable length data to be authenticated
    unsigned char* k  = (unsigned char*)[nsKey bytes];
    unsigned char* m = (unsigned char*)[data bytes];
    unsigned char macChar[16];
    
    AES_CMAC(k, m, (int)data.length, macChar);
    NSData *output = [NSData dataWithBytes:macChar length:16];
    
    return output;
}

#pragma mark - e function
- (NSData*) mesh_e: (NSData*) data andKey: (NSData*) nsKey {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.1
    //k is the 128-bit key
    //plaintext is the variable length data to be encrypted
    unsigned char* key  = (unsigned char*)[nsKey bytes];
    unsigned char* plaintext = (unsigned char*)[data bytes];
    
    unsigned char outbuf[16] = {0x00};
    size_t outLength;

    CCCryptorStatus result = CCCrypt(kCCEncrypt,
                                     kCCAlgorithmAES128,
                                     kCCOptionECBMode,
                                     key,
                                     16,
                                     nil,
                                     plaintext,
                                     16,
                                     outbuf,
                                     16,
                                     &outLength);
    result = result;
    return [[NSData alloc] initWithBytes:outbuf length:16];
}
/*
+ (NSData *)cryptData:(NSData *)dataIn
            operation:(CCOperation)operation  // kCC Encrypt, Decrypt
                 mode:(CCMode)mode            // kCCMode ECB, CBC, CFB, CTR, OFB, RC4, CFB8
            algorithm:(CCAlgorithm)algorithm  // CCAlgorithm AES DES, 3DES, CAST, RC4, RC2, Blowfish
              padding:(CCPadding)padding      // cc NoPadding, PKCS7Padding
            keyLength:(size_t)keyLength       // kCCKeySizeAES 128, 192, 256
                   iv:(NSData *)iv            // CBC, CFB, CFB8, OFB, CTR
                  key:(NSData *)key
                error:(NSError **)error
{
    if (key.length != keyLength) {
        NSLog(@"CCCryptorArgument key.length: %lu != keyLength: %zu", (unsigned long)key.length, keyLength);
        if (error) {
            *error = [NSError errorWithDomain:@"kArgumentError key length" code:key.length userInfo:nil];
        }
        return nil;
    }
    
    size_t dataOutMoved = 0;
    size_t dataOutMovedTotal = 0;
    CCCryptorStatus ccStatus = 0;
    CCCryptorRef cryptor = NULL;
    
    ccStatus = CCCryptorCreateWithMode(operation, mode, algorithm,
                                       padding,
                                       iv.bytes, key.bytes,
                                       keyLength,
                                       NULL, 0, 0, // tweak XTS mode, numRounds
                                       kCCModeOptionCTR_BE, // CCModeOptions
                                       &cryptor);
    
    if (cryptor == 0 || ccStatus != kCCSuccess) {
        NSLog(@"CCCryptorCreate status: %d", ccStatus);
        if (error) {
            *error = [NSError errorWithDomain:@"kCreateError" code:ccStatus userInfo:nil];
        }
        CCCryptorRelease(cryptor);
        return nil;
    }
    
    size_t dataOutLength = CCCryptorGetOutputLength(cryptor, dataIn.length, true);
    NSMutableData *dataOut = [NSMutableData dataWithLength:dataOutLength];
    char *dataOutPointer = (char *)dataOut.mutableBytes;
    
    ccStatus = CCCryptorUpdate(cryptor,
                               dataIn.bytes, dataIn.length,
                               dataOutPointer, dataOutLength,
                               &dataOutMoved);
    dataOutMovedTotal += dataOutMoved;
    
    if (ccStatus != kCCSuccess) {
        NSLog(@"CCCryptorUpdate status: %d", ccStatus);
        if (error) {
            *error = [NSError errorWithDomain:@"kUpdateError" code:ccStatus userInfo:nil];
        }
        CCCryptorRelease(cryptor);
        return nil;
    }
    
    ccStatus = CCCryptorFinal(cryptor,
                              dataOutPointer + dataOutMoved, dataOutLength - dataOutMoved,
                              &dataOutMoved);
    if (ccStatus != kCCSuccess) {
        NSLog(@"CCCryptorFinal status: %d", ccStatus);
        if (error) {
            *error = [NSError errorWithDomain:@"kFinalError" code:ccStatus userInfo:nil];
        }
        CCCryptorRelease(cryptor);
        return nil;
    }
    
    CCCryptorRelease(cryptor);
    
    dataOutMovedTotal += dataOutMoved;
    dataOut.length = dataOutMovedTotal;
    
    return dataOut;
}
 */


#pragma mark - AES128 CCM
- (NSData*) mesh_CCM_encrypt: (NSData*) data
                     K:(NSData*) nsKey
                   nonce:(NSData *) nsNonce
                dataLength:(UInt8) length
              MICSize:(UInt8) size {
  
    
    VPCCM *ccm = [[VPCCM alloc] initWithKey:nsKey
                                                iv:nsNonce
                                             adata:NULL
                                         tagLength:size
                                          fileSize:data.length];
    
    NSMutableData *cipher = [[NSMutableData alloc] init];
    
    unsigned char *bytes = (unsigned char *)[data bytes];
    
    NSData *cryptoData = nil;
    
    NSInteger len = data.length % _bufferSize;
    cryptoData = [[NSData alloc] initWithBytes:[ccm encryptBlock:bytes length:len] length:len];
    [cipher appendData:cryptoData];
    
    //Append tag
    NSData *MIC = [ccm getTag];
    
    [cipher appendData:MIC];
    
    return cipher;
}

- (NSData* )mesh_CCM_decrypt:(NSData *)nsData
                               MIC:(NSData *)nsMIC
                               key:(NSData *)nsKey
                             nonce:(NSData *)nsNonce{
    
    NSData *cryptoData = [nsData subdataWithRange:NSMakeRange(0, nsData.length - nsMIC.length)];
    
    VPCCM *ccm = [[VPCCM alloc] initWithKey:nsKey
                                                iv:nsNonce
                                             adata:NULL
                                         tagLength:nsMIC.length
                                          fileSize:nsData.length];
    
    if ([ccm verifyTagWithData:nsData]) {
        [ccm initialize];
        
        NSMutableData *plainText = [[NSMutableData alloc] init];
        
        unsigned char *bytes = (unsigned char *)[nsData bytes];
        
        NSInteger len = cryptoData.length % _bufferSize;
        
        [plainText appendBytes:[ccm decryptBlock:bytes length:len exitNext:NULL] length:len] ;
        
        return plainText;
        
    }
    else{
        return NULL;
    }
}

- (NSData*) obfuscateEncryptedPDU: (NSData*) nsPDUData
                           cTLTTL:(NSData*)nsCTLTTL
                   seqNum:(NSData*) nsSeq
                          IVIndex:(NSData*) nsIVIndex
                       privacyKey:(NSData*) nsPrivacyKey
                       srcAddr:(NSData*) nsSrc {
    //refer to Mesh Profile v1.0.1, Section 3.8.7.3
    NSMutableData* encryptedDstPduMIC = [[NSMutableData alloc] init];
    [encryptedDstPduMIC appendData:nsPDUData];
    NSData* privacyRandom = [encryptedDstPduMIC subdataWithRange:NSMakeRange(0, 7)];
    
    NSMutableData* privacyPlaintext = [[NSMutableData alloc] init];
    const char zeroArray[] = { 0x00, 0x00, 0x00, 0x00, 0x00 };
    NSData* padding = [[NSData alloc] initWithBytes:zeroArray length:5];
    [privacyPlaintext appendData:padding];
    [privacyPlaintext appendData:nsIVIndex];
    [privacyPlaintext appendData:privacyRandom];
    
    NSData* PECB = [[self mesh_e:privacyPlaintext andKey:nsPrivacyKey] subdataWithRange:NSMakeRange(0, 6)];
    NSMutableData* obfuscateData = [[NSMutableData alloc] init];
    [obfuscateData appendData:nsCTLTTL];
    [obfuscateData appendData:nsSeq];
    [obfuscateData appendData:nsSrc];
    
    NSData* obfuscatedData = [self xor:obfuscateData withData:PECB];
    return obfuscatedData;
}

- (NSData*) deObfuscation: (NSData*) nsENCPDUData
                  IVIndex:(NSData*) nsIVIndex
               privacyKey:(NSData*) nsPrivacyKey {
    //refer to Mesh Profile v1.0.1, Section 3.8.7.3
        NSData* obfuscatedData = [nsENCPDUData subdataWithRange:NSMakeRange(1, 6)];
    NSData* privacyRandom = [nsENCPDUData subdataWithRange:NSMakeRange(7, 7)];
    
    const char zeroArray[] = { 0x00, 0x00, 0x00, 0x00, 0x00 };
    NSData* padding = [[NSData alloc] initWithBytes:zeroArray length:5];
    NSMutableData* privacyPlaintext = [[NSMutableData alloc] init];
    [privacyPlaintext appendData:padding];
    [privacyPlaintext appendData:nsIVIndex];
    [privacyPlaintext appendData:privacyRandom];
    
    NSData* PECB = [[self mesh_e:privacyPlaintext andKey:nsPrivacyKey] subdataWithRange:NSMakeRange(0, 6)];
    
    NSData* deobfuscatedData = [self xor:obfuscatedData withData:PECB];
    return deobfuscatedData;
}



- (NSData*) k1N: (NSData*) nsN salt: (NSData*) nsSalt P: (NSData*) nsP {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.5
    //N is 0 or more octets
    //SALT is 128 bits
    //P is 0 or more octets
    //The key (T) is computed as follows:
    //      T = AES-CMAC(SALT, N)
    //The output of the key generation function k1 is as follows:
    //      k1(N, SALT, P) = AES-CMAC(T, P)
    
    NSData* T = [self mesh_CMAC: nsN K: nsSalt];
    NSData* output = [self mesh_CMAC: nsP K: T];
    return output;
}

- (NSData*) k2N: (NSData*) nsN P: (NSData*) nsP {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.6
    //N is 128 bits
    //P is 1 or more octets
    //The key (T) is computed as follows:
    //      T = AES-CMAC (SALT, N)
    //SALT is the 128-bit value computed as follows
    //      SALT = s1(“smk2”)
    //The output of the key generation function k2 is as follows:
    //      T0 = empty string (zero length)
    //      T1 = AES-CMACT (T0 || P || 0x01)
    //      T2 = AES-CMACT (T1 || P || 0x02)
    //      T3 = AES-CMACT (T2 || P || 0x03)
    //k2(N, P) = (T1 || T2 || T3) mod 2(263)
    
    const char smk2String[] = { 's', 'm', 'k', '2' }; //smk2 string.
    NSData* smk2 = [[NSData alloc] initWithBytes:smk2String length:4];
    NSData* salt = [self SALT:smk2];
    NSData* tKey = [self mesh_CMAC:nsN K:salt];
    
    const unsigned char* p = [nsP bytes];
    NSMutableData *t1Arguments = [[NSMutableData alloc] init];
    [t1Arguments appendBytes:p length:1];
    uint8_t one = 1;
    [t1Arguments appendBytes:&one length:1];
    
    NSData* t1 = [self mesh_CMAC:t1Arguments K:tKey];
    
    NSMutableData *t2Arguments = [[NSMutableData alloc] init];
    [t2Arguments appendData:t1];
    [t2Arguments appendBytes:p length:nsP.length];
    uint8_t two = 0x02;
    [t2Arguments appendBytes:&two length:1];
    
    NSData* t2 = [self mesh_CMAC:t2Arguments K:tKey];
    
    NSMutableData *t3Arguments = [[NSMutableData alloc] init];
    [t3Arguments appendData:t2];
    [t3Arguments appendBytes:p length:nsP.length];
    uint8_t three = 0x03;
    [t3Arguments appendBytes:&three length:1];
    
    NSData* t3 = [self mesh_CMAC:t3Arguments K:tKey];
    
    NSMutableData* data = [[NSMutableData alloc] init];
    [data appendData:t1];
    [data appendData:t2];
    [data appendData:t3];
    
    const unsigned char* dataPtr = [data bytes];
    unsigned char firstOffset = dataPtr[15] & 0x7F;
    data = (NSMutableData*)[data subdataWithRange: NSMakeRange(16, [data length] - 16)];
    NSMutableData* output = [[NSMutableData alloc] init];
    [output appendBytes:&firstOffset length:1];
    [output appendData:data];
    
    return output;
}

- (NSData*) k3N: (NSData*) nsN {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.7
    //The inputs to function k3 are:
    //      N is 128 bits
    //The key (T) is computed as follows:
    //      T = AES-CMAC (SALT, N)
    //SALT is a 128-bit value computed as follows:
    //      SALT = s1(“smk3”)
    //The output of the derivation function k3 is as follows:
    //      k3(N) = AES-CMACT ( “id64” || 0x01 ) mod 2(64)

    const char smk3String[] = { 's', 'm', 'k', '3' }; //smk3 string.
    NSData* smk3 = [[NSData alloc] initWithBytes:smk3String length:4];
    NSData* salt = [self SALT:smk3];
    NSData* t = [self mesh_CMAC: nsN K: salt];
    
    const char cmacInput[] = { 'i', 'd', '6', '4', 0x01 };
    NSData* cmacInputData = [[NSData alloc] initWithBytes:cmacInput length:5];
    NSData* data = [self mesh_CMAC:cmacInputData K:t];
    
    NSData *output = (NSMutableData*)[data subdataWithRange: NSMakeRange(8, [data length] - 8)];
    return output;
}

- (NSData*) k4N: (NSData*) nsN {
    //refer to Mesh Profile v1.0.1, Section 3.8.2.8
    //The inputs to function k4 are:
    //N is 128 bits
    //The key (T) is computed as follows:
    //      T = AES-CMAC (SALT, N)
    //SALT is a 128-bit value computed as follows:
    //      SALT = s1(“smk4”)
    //The output of the derivation function k4 is as follows:
    //      K4(N) = AES-CMACT ( “id6” || 0x01 ) mod 26
    
    const char smk4String[] = { 's', 'm', 'k', '4' }; //smk4 string.
    NSData* smk4 = [[NSData alloc] initWithBytes:smk4String length:4];
    NSData* salt = [self SALT:smk4];
    NSData* t = [self mesh_CMAC: nsN K: salt];
    
    const char cmacInput[] = { 'i', 'd', '6', 0x01 }; //id6 string. || 0x01
    NSData* cmacInputData = [[NSData alloc] initWithBytes:cmacInput length:4];
    NSData* data = [self mesh_CMAC:cmacInputData K:t];
    
    const unsigned char* dataPtr = [data bytes];
    const unsigned char outputBytes = dataPtr[15] & 0x3F;
    NSData *output = [[NSData alloc] initWithBytes:&outputBytes length:sizeof(outputBytes)];
    return output;
}

- (NSData*) xor: (NSData*) someData withData: (NSData*) otherData {
    const char *someDataBytes   = [someData bytes];
    const char *otherDataBytes  = [otherData bytes];
    NSMutableData *result = [[NSMutableData alloc] init];
    for (int i = 0; i < someData.length; i++){
        const char resultByte = someDataBytes[i] ^ otherDataBytes[i];
        [result appendBytes:&resultByte length:1];
    }
    return result;
}

#pragma mark -
#pragma mark hexString
+ (NSData*)dataFormHexString:(NSString*)hexString{
    hexString=[[hexString uppercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (!(hexString && [hexString length] > 0 && [hexString length]%2 == 0)) {
        return nil;
    }
    Byte tempbyt[1]={0};
    NSMutableData* bytes=[NSMutableData data];
    for(int i=0;i<[hexString length];i++)
    {
        unichar hex_char1 = [hexString characterAtIndex:i];
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16;
        else
            return nil;
        i++;
        
        unichar hex_char2 = [hexString characterAtIndex:i];
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48);
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55;
        else
            return nil;
        
        tempbyt[0] = int_ch1+int_ch2;
        [bytes appendBytes:tempbyt length:1];
    }
    return bytes;
}

+ (NSString *)hexStringFromData:(NSData*)data{
    return [[[[NSString stringWithFormat:@"%@",data]
              stringByReplacingOccurrencesOfString: @"<" withString: @""]
             stringByReplacingOccurrencesOfString: @">" withString: @""]
            stringByReplacingOccurrencesOfString: @" " withString: @""];
}

@end
