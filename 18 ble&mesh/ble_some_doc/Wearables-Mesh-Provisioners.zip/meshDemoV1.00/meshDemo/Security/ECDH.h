//
//  ECDH.h
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>


@interface ECDH : NSObject

+ (void)generateKeyPair:(SecKeyRef *)publicKey privateTag:(SecKeyRef *)privateKey ;

+ (NSData *)getPublicKeyFromSecKey:(SecKeyRef *) secPublicKey;

+ (NSData *)ecdhSecretCalculation:(SecKeyRef *)publicKey private:(SecKeyRef *)privateKey;
+ (SecKeyRef)getSecKeyFromPublicKey:(NSData *)publicKey;
+ (NSData *)getAuthValue;
+ (NSData *)getRandomNumber;

@end
