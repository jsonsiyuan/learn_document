//
//  crypto.h
//
//  Created by RenKai on 2018/10/9.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VPCCM.h"

@interface crypto : NSObject {
}


//- (instancetype)initialCrypto;


- (NSData*) SALT: (NSData*) M;

- (NSData*) mesh_CMAC: (NSData*) data K: (NSData*) nsKey ;

- (NSData*) mesh_CCM_encrypt: (NSData*) data
                     K:(NSData*) nsKey
                 nonce:(NSData *) nsNonce
            dataLength:(UInt8) length
               MICSize:(UInt8) size ;

- (NSData*) obfuscateEncryptedPDU: (NSData*) nsPDUData
                           cTLTTL:(NSData*)nsCTLTTL
                           seqNum:(NSData*) nsSeq
                          IVIndex:(NSData*) nsIVIndex
                       privacyKey:(NSData*) nsPrivacyKey
                          srcAddr:(NSData*) nsSrc ;

- (NSData*) deObfuscation: (NSData*) nsENCPDUData
                  IVIndex:(NSData*) nsIVIndex
               privacyKey:(NSData*) nsPrivacyKey ;

//MARK
- (NSData*) k1N: (NSData*) nsN salt: (NSData*) nsSalt P: (NSData*) nsP;
- (NSData*) k2N: (NSData*) nsN P: (NSData*) nsP;
- (NSData*) k3N: (NSData*) nsN;
- (NSData*) k4N: (NSData*) nsN;
- (NSData*) xor: (NSData*) someData withData: (NSData*) otherData ;

- (NSData* )mesh_CCM_decrypt:(NSData *)nsData
                         MIC:(NSData *)nsMIC
                         key:(NSData *)nsKey
                       nonce:(NSData *)nsNonce;


+ (NSData *)dataFormHexString:(NSString*)hexString;
+ (NSString *)hexStringFromData:(NSData*)data;

@end
