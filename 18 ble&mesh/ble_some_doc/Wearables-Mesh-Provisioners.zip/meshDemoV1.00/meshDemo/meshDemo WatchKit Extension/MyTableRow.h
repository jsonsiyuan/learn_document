//
//  MyTableRow.h
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 2018/12/23.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WatchKit/WatchKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyTableRow : NSObject
@property (strong, nonatomic) IBOutlet WKInterfaceLabel *titleLable;

@end

NS_ASSUME_NONNULL_END
