//
//  ProvisionInterfaceController.h
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 2018/12/23.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "ECDH.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ProvisioningInterfaceControllerDelegate <NSObject>

@required
- (void)dataFromInterfaceController:(NSData *)data;

@end

@interface ProvisionInterfaceController : WKInterfaceController
@property (nonatomic, retain) NSData *devKey;
@property (nonatomic, weak) id<ProvisioningInterfaceControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
