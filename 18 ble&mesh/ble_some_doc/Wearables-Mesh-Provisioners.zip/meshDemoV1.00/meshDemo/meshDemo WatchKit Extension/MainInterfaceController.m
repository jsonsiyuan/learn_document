//
//  MainInterfaceController.m
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 2018/12/23.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "MainInterfaceController.h"
#import "ProvisionInterfaceController.h"
#import "ProxyInterfaceController.h"

@interface MainInterfaceController() <ProvisioningInterfaceControllerDelegate>
@property (strong, nonatomic) IBOutlet WKInterfaceButton *Provisioning;
@property (strong, nonatomic) IBOutlet WKInterfaceButton *Proxy;
@end


@implementation MainInterfaceController 

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    
    // Configure interface objects here.
    
    NSLog(@"Main IC: %@", (NSData *)context );

}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (void)dataFromInterfaceController:(NSData *)data
{
    //_devKey = data;
    //NSLog(@"label: %@", _devKey);
}

- (IBAction)tapDidToProvisioning {
    NSLog(@"tapped provisioning");
    [self pushControllerWithName:@"ProvisionIC" context:self];
}

- (IBAction)tapDidToProxy {
    NSLog(@"tapped proxy");
    
    [self pushControllerWithName:@"ProxyIC" context:nil];
}


- (id)contextForSegueWithIdentifier:(NSString *)segueIdentifier{
    NSLog(@"segueIdentifier: %@", segueIdentifier);

    return self;
}


@end
