//
//  ProxyInterfaceController.m
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 02/11/2017.
//  Copyright © 2017 Kai Ren. All rights reserved.
//

#import "ProxyInterfaceController.h"
#import "MainInterfaceController.h"
#import "ECDH.h"
#import "crypto.h"
#import "proxy.h"

@interface ProxyInterfaceController() <CBCentralManagerDelegate, CBPeripheralDelegate>

@property(strong, nonatomic)CBCentralManager *centralManager;
@property(strong, nonatomic)CBPeripheral *targetProxyPeripheral;
@property (weak, nonatomic) IBOutlet WKInterfaceButton  *connectButton;
@property (weak, nonatomic) IBOutlet WKInterfaceButton  *disconnectButton;

@property (strong, nonatomic) CBService *proxyService;
@property (strong, nonatomic) CBCharacteristic *proxyDataIn;
@property (strong, nonatomic) CBCharacteristic *proxyDataOut;

@property (strong, nonatomic) Proxy *proxy;
@property (weak, nonatomic) IBOutlet WKInterfaceSwitch* mySwitch;

@end

@implementation ProxyInterfaceController

- (instancetype)initWithContext:(id)context {
    self = [super init];
    if (self){
        //init Core Bluetooth
        self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:NULL];
        _proxy = [[Proxy alloc]initWith];
        //_proxy.deviceKey = (NSData*)context;
    }
    
    //disable disconnectButton and mySwitch because with any peripheral connection and
    //proxy intialization
    [self.disconnectButton setHidden:true];
    [self.mySwitch setHidden:true];
    
    return self;
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
}

//perform scanning
- (void) startScanning{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString: _proxy.meshProxyServiceUUIDString]]
                                                options:nil];
    NSLog(@"start to scan. ");
}

//stop scanning
- (void) stopScanning{
    [self.centralManager stopScan ];
    NSLog(@"stop to scan. ");
}



#pragma mark IOOutlet callback

- (IBAction)connectButton {
    NSLog(@"connectButton pressed. ");
    [self startScanning];
}

- (IBAction)discoonectButton {
    NSLog(@"disconnectButton pressed. ");
    [_centralManager cancelPeripheralConnection:_targetProxyPeripheral];
}

- (IBAction)flashSwitchAction:(BOOL)value {
    if (value == true){
        [_targetProxyPeripheral writeValue:[_proxy getPDUForGenericOnOffServer:value]
                         forCharacteristic:_proxyDataIn
                                      type:CBCharacteristicWriteWithoutResponse];
        NSLog(@"ON - Writing value for characteristic %@", self.proxyDataIn);
        
    }
    else{
        [_targetProxyPeripheral writeValue:[_proxy getPDUForGenericOnOffServer:value]
                         forCharacteristic:_proxyDataIn
                                      type:CBCharacteristicWriteWithoutResponse];
        NSLog(@"OFF - Writing value for characteristic %@", self.proxyDataIn);
    }
}

#pragma mark - CBCentralManagerDelegate protocol
- (void)centralManagerDidUpdateState:(nonnull CBCentralManager *)central {
    if ([central state] == CBManagerStatePoweredOn) {
        NSLog(@"state: power on. ");
    }
    else{
        NSLog(@"state: something else. ");
        
    }
}

//invoked when connection is dropper
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral
                 error:(NSError *)error{
    NSLog(@"disconnect with peripheral %@", peripheral);
    
    //hide mySwitch and disconnectButtion
    [_disconnectButton setHidden:true];
    [_mySwitch setHidden:true];
}

//invoked when scan the new peripheral
- (void)centralManager:(CBCentralManager *)central
  didDiscoverPeripheral:(CBPeripheral *)peripheral
     advertisementData:(NSDictionary<NSString *,id> *)advertisementData
                  RSSI:(NSNumber *)RSSI{
    [central stopScan];
    
    _targetProxyPeripheral = peripheral;
    NSLog(@"advertisement: %@", advertisementData);
    
    //connect with the proxy peripheral
    [central connectPeripheral:peripheral options:nil];
}

//invoked when connection is established with corresponding peripheral
- (void)centralManager:(CBCentralManager *)central
  didConnectPeripheral:(CBPeripheral *)peripheral{
    NSLog(@"connected peripheral: %@", peripheral);
    
    //disconnectButtion can be visible here when connection is established
    [_disconnectButton setHidden:false];
      
    //make self as delegate
    _targetProxyPeripheral.delegate = self;
      
    //create a UUID and add it into the array in order to discover the specified service
    //in this case, we do the search for mesh Proxy Service
    NSArray *serviceArray = [NSArray array];
    serviceArray = [NSArray arrayWithObject:[CBUUID UUIDWithString:_proxy.meshProxyServiceUUIDString ]];
    [peripheral discoverServices:serviceArray];
}

#pragma mark - CBPeripheralDelegate protocol

//invoked when discover the services
- (void)peripheral:(CBPeripheral *)peripheral
        didDiscoverServices:(NSError *)error{
    
    NSLog(@"service count: %lu", (unsigned long)peripheral.services.count);
    
    // Loop through the newly filled peripheral.services array, just in case there's more than one.
    for (CBService *service in peripheral.services) {
        [peripheral discoverCharacteristics:nil forService:service];
    }
}

//invoked when discover characteristics by specified service
- (void)peripheral:(CBPeripheral *)peripheral
didDiscoverCharacteristicsForService:(CBService *)service
             error:(NSError *)error{
    
    for (CBCharacteristic *characteristic in service.characteristics) {
        NSLog(@"discover char 0x%@", characteristic.UUID);
        
        [peripheral discoverDescriptorsForCharacteristic:characteristic];
        [peripheral readValueForCharacteristic:characteristic];
        NSLog(@"maximumLen with = %lu, without %lu ",
              (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithResponse],
              (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithoutResponse]);
        
        
        
        if ( [characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataInCharacteristicUUIDString ]]){
            _proxyDataIn = characteristic;
        }
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString ]]){
            _proxyDataOut = characteristic;
        }
    }
}

//invoked when discover discriptor in this characteristic
- (void)peripheral:(CBPeripheral *)peripheral
        didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error{
    //enable the notification when this characteristic supports
    for(CBDescriptor *discriptor in characteristic.descriptors){
        NSLog(@"discriptor: %@", discriptor);
        [peripheral setNotifyValue:true forCharacteristic:characteristic];
    }
}

//invoked when enable notification successful or not
- (void)peripheral:(CBPeripheral *)peripheral
didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error{
    if(nil == error){
        NSLog(@"notification enabled.");
        
        //set mySwitch to visible because it can send message out
        [_mySwitch setHidden:false];
    }
    else{
        NSLog(@"notification disable.");
    }
}

//retrieve characteristic's value from server, invoked when new data packet is received
//parser data here
- (void)peripheral:(CBPeripheral *)peripheral
didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error{
#if 0
    NSLog(@"target char: %@", characteristic);
#endif
    
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString]] && characteristic.isNotifying ) {
    
        //[_proxy proxyPDUParser:_targetProxyPeripheral
        //            dataInChar:_proxyDataIn
        //           dataOutChar:_proxyDataOut];
    }
}



@end




