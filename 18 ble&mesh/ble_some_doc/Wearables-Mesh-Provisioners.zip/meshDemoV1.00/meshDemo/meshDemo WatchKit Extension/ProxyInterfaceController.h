//
//  ProxyInterfaceController.h
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 02/11/2017.
//  Copyright © 2017 Kai Ren. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <Foundation/Foundation.h>

@interface ProxyInterfaceController : WKInterfaceController
@property (strong, nonatomic)NSData *DeviceKey; 

@end

