//
//  MainInterfaceController.h
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 2018/12/23.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainInterfaceController : WKInterfaceController
@property (strong, nonatomic) NSData *devKey;

@end

NS_ASSUME_NONNULL_END
