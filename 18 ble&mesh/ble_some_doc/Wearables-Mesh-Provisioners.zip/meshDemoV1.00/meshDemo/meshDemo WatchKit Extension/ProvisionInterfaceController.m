//
//  ProvisionInterfaceController.m
//  meshDemo WatchKit Extension
//
//  Created by RenKai on 2018/12/23.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>
#import "ProvisionInterfaceController.h"
#import "Provisioning.h"
#import "MyTableRow.h"
#import "proxy.h"

@interface ProvisionInterfaceController () <CBCentralManagerDelegate, CBPeripheralDelegate>

@property(strong, nonatomic)CBCentralManager *centralManager;   //ble manage for provision scan
@property(strong, nonatomic)Provisioning *Provisioner;
@property(strong, nonatomic)NSMutableArray *peripherals;
@property(strong, nonatomic)CBPeripheral *targetPeripheral;
//@property(strong, nonatomic)UITableView *deviceTable;
@property(strong, nonatomic)CBCharacteristic *provDataIn;
@property(strong, nonatomic)CBCharacteristic *provDataOut;

//@property (nonatomic, strong) UIActivityIndicatorView * activityIndicator;

@property (strong, nonatomic) Proxy *proxy;
@property(strong, nonatomic)CBPeripheral *targetProxyPeripheral;
@property (strong, nonatomic) CBCharacteristic *proxyDataIn;
@property (strong, nonatomic) CBCharacteristic *proxyDataOut;

@property (strong, nonatomic) IBOutlet WKInterfaceTable *unprovisionedDevice;
@property (strong, nonnull) MyTableRow *table;
@property (strong, nonatomic) NSData *devkey;
@property (strong, nonatomic) IBOutlet WKInterfaceImage *activityIndicator;

@end

BOOL isProvisioning;
BOOL isProvisioningSuccessful;

@implementation ProvisionInterfaceController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    
    self.delegate = context;
    
    // Configure interface objects here.
    [self loadTableData];
    
    _Provisioner = [[Provisioning alloc]init];
    
    //initial centralManage with delegate
    self.centralManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
    
    _peripherals = [[NSMutableArray alloc]init];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(execute:)
                                                     name:@"ProvisioningStatus"
                                                   object:nil];
                                                   
    _proxy = [[Proxy alloc]initWith];
}

#pragma mark - Alert Action
- (void)showProvisioningStatus:(NSString *)errorMsg {
    
    //Stop animator for provisioning progress
    [_activityIndicator stopAnimating];
    
    NSMutableArray<WKAlertAction*> *keyArray = [NSMutableArray array];
    
    WKAlertAction *action = [WKAlertAction actionWithTitle:@"OK" style:WKAlertActionStyleDefault handler:^{
        //[self pushControllerWithName:@"MainIC" context:self->_devkey];
        [self popController];
    }];
    
    [keyArray addObject:action];
    
    [self presentAlertControllerWithTitle:@"Provisioning Status"
                                  message:errorMsg
                           preferredStyle:WKAlertControllerStyleAlert
                                  actions:keyArray];
    
}

- (id)contextForSegueWithIdentifier:(NSString *)segueIdentifier{
    NSLog(@"segueIdentifier: %@", segueIdentifier);
    return self.devkey;
}

- (void)execute:(NSNotification *)notification {
    NSLog(@"notification: %@", notification);
   
    if( [[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusAuthenticationFailed"]){
        NSLog(@"ProvisioningStatusAuthenticationFailed");
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusSuccessful"]){
        NSLog(@"ProvisioningStatusSuccessful");
        isProvisioningSuccessful = true;
        
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        _proxy.numOfElements = [user integerForKey:@"numOfElementsIdentifier"];
        NSLog(@"_numOfElements: %u", _proxy.numOfElements);
        _proxy.primaryElement = [user objectForKey:@"primaryElementIdentifier"];
        NSLog(@"_primaryElement: %@", _proxy.primaryElement);
        _proxy.deviceKey = [user objectForKey:@"deviceKeyIdentifier"];
        NSLog(@"_deviceKey: %@", _proxy.deviceKey);
        
        [_centralManager cancelPeripheralConnection:_targetPeripheral];
        
        [NSThread sleepForTimeInterval:1.0];
        //_devkey = [notification object];
        //if ([_delegate respondsToSelector:@selector(dataFromInterfaceController:)])
        //{
        //    [_delegate dataFromInterfaceController:_devkey];
        //}
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusTimerFired"]){
        NSLog(@"ProvisioningStatusTimerFired");
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusFailed"]){
        NSLog(@"ProvisioningStatusFailed");
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ModelConfigurationTimerFired"]){
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ModelConfigurationStatusSuccessful"]){
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    
    //disconnect with the unprovisioned device
    //[_centralManager cancelPeripheralConnection:_targetPeripheral];
    isProvisioning = false;
    
    
}

- (void)loadTableData{
    //NSArray *array = [NSArray arrayWithObjects:@"title1", @"title2", @"title3", nil];

    [self.unprovisionedDevice setNumberOfRows:_peripherals.count withRowType:@"myrow"];
    
    for (NSInteger i = 0; i < self.peripherals.count; i++) {
        CBPeripheral *p = [_peripherals objectAtIndex:i];
        MyTableRow* row = [self.unprovisionedDevice rowControllerAtIndex:i];
        [row.titleLable setText: p.name];
    }
}

- (void)table:(WKInterfaceTable *)table didSelectRowAtIndex:(NSInteger)rowIndex{
    //NSLog(@"selector %d", rowIndex);
    _targetPeripheral = [_peripherals objectAtIndex:rowIndex];
    NSLog(@"row: %d, target: %@", rowIndex, _targetPeripheral);
    
    //connect with the target peripheral
    [_centralManager stopScan];
    [_centralManager connectPeripheral:_targetPeripheral options:nil];
    
    // Animate a series of images prefixed with the string "Activity"
    [_activityIndicator setImageNamed:@"Activity"];
    [_activityIndicator startAnimatingWithImagesInRange:NSMakeRange(0, 15) duration:1.0 repeatCount:0];
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}
- (IBAction)provisionScan {
    NSLog(@"start to scan for unprovisioned nodes");
    [self startProvScan];
}

//start to perform scanning to search unprovisioned device
- (void)startProvScan{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID  UUIDWithString:_Provisioner.meshProvServiceUUIDString]] options:@{CBCentralManagerRestoredStateScanOptionsKey:@(YES)}];
    
    //clear all the objects
    [_peripherals removeAllObjects];
    
    //flag to provisioning
    isProvisioning = true;
    isProvisioningSuccessful = false;
}

//stop unprovisioned device scanning
- (void)stopScan{
    [self.centralManager stopScan];
}

//perform proxy & model configuration scanning
- (void) startModelScan{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString: _proxy.meshProxyServiceUUIDString]]
                                                options:nil];
    NSLog(@"start to scan. ");
}


- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    if ([central state] == CBManagerStatePoweredOn) {
        NSLog(@"CBManager state: power on");
    }
    else{
        NSLog(@"CBManager state: others");
    }
}
//invoked when connection is dropped
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"prov: disconnect with peripheral %@", peripheral);
    if (isProvisioningSuccessful) {
        [self startModelScan];
    }
}

//invoked when scan certain peripheral which includes the service
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI{
    
    //Provisioning
    if (isProvisioning) {
    for (NSInteger i = 0; i < self.peripherals.count; i++) {
        CBPeripheral *p = [_peripherals objectAtIndex:i];
        if (peripheral.identifier == p.identifier) {
            NSLog(@"duplicated peripheral.identifier");
            return;
        }
        
    }
    
    [self.peripherals addObject:peripheral];
    NSLog(@"a new peripheral added %@", peripheral);
    [self loadTableData];
    }
    else{
        //model configuration
        [central stopScan];
        
        _targetProxyPeripheral = peripheral;
        NSLog(@"advertisement: %@", advertisementData);
        
        //connect with the proxy peripheral
        [central connectPeripheral:peripheral options:nil];
    }
}

//invoked when connection is established with corresponding peripheral
- (void)centralManager:(CBCentralManager *)central
  didConnectPeripheral:(CBPeripheral *)peripheral{
    //provisioning
    if (isProvisioning) {
    NSLog(@"connected peripheral: %@", peripheral);
    
    //make self as delegate
    _targetPeripheral.delegate = self;
    
    //create a UUID and add it into the array in order to discover the specified service
    //in this case, we do the search for mesh Proxy Service
    NSArray *serviceArray = [NSArray array];
    serviceArray = [NSArray arrayWithObject:[CBUUID UUIDWithString:_Provisioner.meshProvServiceUUIDString ]];
    [peripheral discoverServices:serviceArray];
    }
    else{
        //model configuration
        NSLog(@"connected peripheral: %@", peripheral);
        
        //disconnectButtion can be visible here when connection is established
        //[_disconnectButton setHidden:false];
        
        //make self as delegate
        _targetProxyPeripheral.delegate = self;
        
        //create a UUID and add it into the array in order to discover the specified service
        //in this case, we do the search for mesh Proxy Service
        NSArray *serviceArray = [NSArray array];
        serviceArray = [NSArray arrayWithObject:[CBUUID UUIDWithString:_proxy.meshProxyServiceUUIDString ]];
        [peripheral discoverServices:serviceArray];
    }
}

#pragma mark - CBPeripheralDelegate protocol

//invoked when discover the target service
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"service count: %u", peripheral.services.count);
    
    // Loop through the newly filled peripheral.services array, just in case there's more than one.
    for (CBService *service in peripheral.services) {
        [peripheral discoverCharacteristics:nil forService:service];
    }
}

//invoked when discover the target characteristic
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (isProvisioning) {
    for (CBCharacteristic *characteristic in service.characteristics ) {
        NSLog(@"discover char 0x%@", characteristic.UUID);
        
        [peripheral discoverDescriptorsForCharacteristic:characteristic];
        [peripheral readValueForCharacteristic:characteristic];
        NSLog(@"maximumLen with = %lu, without %lu ",
              (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithResponse],
              (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithoutResponse]);
        
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataInCharacteristicUUIDString]]) {
            _provDataIn = characteristic;
        }
        
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataOutCharacteristicUUIDString]]) {
            _provDataOut = characteristic;
        }
    }
    }
    else{
        //model configuration
        for (CBCharacteristic *characteristic in service.characteristics) {
            NSLog(@"discover char 0x%@", characteristic.UUID);
            
            [peripheral discoverDescriptorsForCharacteristic:characteristic];
            [peripheral readValueForCharacteristic:characteristic];
            NSLog(@"maximumLen with = %lu, without %lu ",
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithResponse],
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithoutResponse]);
            
            
            
            if ( [characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataInCharacteristicUUIDString ]]){
                _proxyDataIn = characteristic;
            }
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString ]]){
                _proxyDataOut = characteristic;
            }
        }
    }
    
}

//invoked when discover target discriptor in this characteristic
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    
    for ( CBDescriptor *descriptor in characteristic.descriptors ) {
        NSLog(@"descriptor: %@", descriptor);
        
        //enable notification
        [peripheral setNotifyValue:true forCharacteristic:characteristic];
    }
}

//invoked when enable notification is sucessful
-(void) peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    
    if (nil == error) {
        NSLog(@"notification enabled.");
        if (isProvisioning) {
        [_targetPeripheral writeValue:[_Provisioner provInvitation]
                    forCharacteristic:_provDataIn
                                 type:CBCharacteristicWriteWithoutResponse];
    }
        
    }
    else{
        NSLog(@"notification disable.");
    }
}

//retrieve characteristic's value from server, invoked when new data packet is received
//parser data here
- (void)peripheral:(CBPeripheral *)peripheral
didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error{
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataOutCharacteristicUUIDString]] && characteristic.isNotifying ) {
        NSLog(@"prov char: %@", characteristic);
        [_Provisioner provPDUParser:_targetPeripheral
                         dataInChar:_provDataIn
                        dataOutChar:_provDataOut];
    }
    
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString]] && characteristic.isNotifying ) {
        NSLog(@"proxy char: %@", characteristic);
        [_proxy proxyPDUParser:_targetProxyPeripheral
                    dataInChar:_proxyDataIn
                   dataOutChar:_proxyDataOut];
    }
}

@end



