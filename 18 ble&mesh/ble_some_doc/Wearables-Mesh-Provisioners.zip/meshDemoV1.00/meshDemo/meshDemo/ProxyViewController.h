//
//  ProxyViewController.h
//  meshDemo
//
//  Created by RenKai on 02/11/2017.
//  Copyright © 2017 Kai Ren. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ProxyViewController : UIViewController
@property (strong, nonatomic)NSData *DeviceKey; 

@end

