//
//  MainViewController.h
//  meshDemo
//
//  Created by RenKai on 2018/12/20.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *didTapToProvPage;

@property (strong, nonatomic) IBOutlet UIButton *didTapToProxyPage;

@end

NS_ASSUME_NONNULL_END
