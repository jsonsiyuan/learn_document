//
//  ProvisioningViewController.m
//  meshDemo
//
//  Created by RenKai on 2018/12/19.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import "ProvisioningViewController.h"
#import "Provisioning.h"
#import "proxy.h"

@interface ProvisioningViewController () <CBCentralManagerDelegate, CBPeripheralDelegate, UITableViewDelegate, UITableViewDataSource>

@property(strong, nonatomic)CBCentralManager *centralManager;   //ble manage for provision scan
@property(strong, nonatomic)Provisioning *Provisioner;
@property(strong, nonatomic)NSMutableArray *peripherals;
@property(strong, nonatomic)CBPeripheral *targetPeripheral;
@property(strong, nonatomic)UITableView *deviceTable;
@property(strong, nonatomic)CBCharacteristic *provDataIn;
@property(strong, nonatomic)CBCharacteristic *provDataOut;

@property (nonatomic, strong) UIActivityIndicatorView * activityIndicator;

@property (strong, nonatomic) Proxy *proxy;
@property(strong, nonatomic)CBPeripheral *targetProxyPeripheral;
@property (strong, nonatomic) CBCharacteristic *proxyDataIn;
@property (strong, nonatomic) CBCharacteristic *proxyDataOut;


@end

BOOL isProvisioning;
BOOL isProvisioningSuccessful;

@implementation ProvisioningViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.    
    self.navigationItem.title = @"Provisioning";
    
    UIBarButtonItem *scanButton = [[UIBarButtonItem alloc]initWithTitle:@"Scan"
                                                                  style:UIBarButtonItemStyleDone target:self action:@selector(scanForProvNode:)];
    
    //self.navigationItem.rightBarButtonItem = scanButton;
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc]initWithTitle:@"Back" style:UIBarButtonItemStyleDone target:self action:@selector(backToMainMenu:)];
    self.navigationItem.rightBarButtonItems = @[scanButton, backButton];
    
    //Initial Provisioning class
    _Provisioner = [[Provisioning alloc]init];
    
    //initial centralManage with delegate
    self.centralManager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
    
    _peripherals = [[NSMutableArray alloc]init];
    
    //tableview create
    _deviceTable = [[UITableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain];
    
    //initial delegate and datasource for tableview
    _deviceTable.dataSource = self;
    _deviceTable.delegate = self;
    
    [self.view addSubview:_deviceTable];
    
    //creating activity indicator 
    self.activityIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:(UIActivityIndicatorViewStyleGray)];
    [self.view addSubview:self.activityIndicator];
    
    //activity indicator frame location and size
    self.activityIndicator.frame= CGRectMake(self.view.bounds.origin.x - 50 + self.view.bounds.size.width / 2, self.view.bounds.origin.y - 50 + self.view.bounds.size.height / 2, 100, 100);
    
    //activity indicator color
    //self.activityIndicator.color = [UIColor redColor];
    
    //activity indicator background color
    //self.activityIndicator.backgroundColor = [UIColor cyanColor];
    
    //getting rid of this indicator when it's stop
    self.activityIndicator.hidesWhenStopped = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(execute:)
                                                     name:@"ProvisioningStatus"
                                                   object:nil];
    
    _proxy = [[Proxy alloc]initWith];
}

#pragma mark - Alert Controller
// Alert Controller
- (void)showProvisioningStatus:(NSString *)errorMsg {
    
    //Initial AlertController
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Provisioning Status"
                                                                   message:errorMsg
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    //Add alert action
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController popViewControllerAnimated:YES];
    }]];
    
    //push alert controller
    [self presentViewController:alert animated:true completion:nil];
}

- (void)execute:(NSNotification *)notification {
    NSLog(@"notification: %@", notification);
    
    if( [[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusAuthenticationFailed"]){
        NSLog(@"ProvisioningStatusAuthenticationFailed");
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusSuccessful"]){
        NSLog(@"ProvisioningStatusSuccessful");
        isProvisioningSuccessful = true;
        
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        _proxy.numOfElements = [user integerForKey:@"numOfElementsIdentifier"];
        NSLog(@"_numOfElements: %u", _proxy.numOfElements);
        _proxy.primaryElement = [user objectForKey:@"primaryElementIdentifier"];
        NSLog(@"_primaryElement: %@", _proxy.primaryElement);
        _proxy.deviceKey = [user objectForKey:@"deviceKeyIdentifier"];
        NSLog(@"_deviceKey: %@", _proxy.deviceKey);
        
        [_centralManager cancelPeripheralConnection:_targetPeripheral];
        
        [NSThread sleepForTimeInterval:1.0];
        
        if ([_delegate respondsToSelector:@selector(dataFromController:)])
        {
            [_delegate dataFromController:nil];
        }
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusTimerFired"]){
        NSLog(@"ProvisioningStatusTimerFired");
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ProvisioningStatusFailed"]){
        NSLog(@"ProvisioningStatusFailed");
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ModelConfigurationTimerFired"]){
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    else if ([[notification.userInfo objectForKey:@"1"] isEqualToString:@"ModelConfigurationStatusSuccessful"]){
        [self showProvisioningStatus:[notification.userInfo objectForKey:@"1"]];
    }
    
    //disconnect with the unprovisioned device
    //[_centralManager cancelPeripheralConnection:_targetPeripheral];
    isProvisioning = false;
    
    //stop activity indicator
    [self.activityIndicator stopAnimating];
}

#pragma mark - TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _peripherals.count;
}
/*-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80.0;
}*/

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CBPeripheral *p = [_peripherals objectAtIndex:indexPath.row];
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    cell.textLabel.text = p.name;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _targetPeripheral = [_peripherals objectAtIndex:indexPath.row];
    NSLog(@"section: %ld, row: %ld, target: %@", (long)indexPath.section, (long)indexPath.row, _targetPeripheral);
    
    //connect with the target peripheral
    [_centralManager stopScan];
    [_centralManager connectPeripheral:_targetPeripheral options:nil];
    
    [self.activityIndicator startAnimating];

}


#pragma mark - IOOutlet
- (void)scanForProvNode:(UIBarButtonItem *)sender{
    NSLog(@"scan for provisioning devices");
    [self startProvScan];
}

- (void)backToMainMenu:(UIBarButtonItem *)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
    
    //[self dismissViewControllerAnimated:YES completion:nil];
    //[self dismissModalViewControllerAnimated:YES];
}

#pragma mark - CBCentralManagerDelegate protocol

//start to perform scanning to search unprovisioned device
- (void)startProvScan{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID  UUIDWithString:_Provisioner.meshProvServiceUUIDString]] options:@{CBCentralManagerRestoredStateScanOptionsKey:@(YES)}];
    
    //clear all the objects
    [_peripherals removeAllObjects];
    
    //flag to provisioning
    isProvisioning = true;
    isProvisioningSuccessful = false;
}

//stop unprovisioned device scanning
- (void)stopScan{
    [self.centralManager stopScan];
}

//perform proxy & model configuration scanning
- (void) startModelScan{
    [self.centralManager scanForPeripheralsWithServices:@[[CBUUID UUIDWithString: _proxy.meshProxyServiceUUIDString]]
                                                options:nil];
    NSLog(@"start to scan. ");
}


- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    if ([central state] == CBManagerStatePoweredOn) {
        NSLog(@"CBManager state: power on");
    }
    else{
        NSLog(@"CBManager state: others");
    }
}
//invoked when connection is dropped
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"prov: disconnect with peripheral %@", peripheral);
    if (isProvisioningSuccessful) {
        [self startModelScan];
    }
}

//invoked when scan certain peripheral which includes the service
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI{
    
    //Provisioning
    if (isProvisioning) {
        for (NSInteger i = 0; i < self.peripherals.count; i++) {
            CBPeripheral *p = [_peripherals objectAtIndex:i];
            if (peripheral.identifier == p.identifier) {
                NSLog(@"duplicated peripheral.identifier");
                return;
            }
            
        }
        
        [self.peripherals addObject:peripheral];
        NSLog(@"a new peripheral added %@", peripheral);
        [_deviceTable reloadData];
    }
    else{
        //model configuration
        [central stopScan];
        
        _targetProxyPeripheral = peripheral;
        NSLog(@"advertisement: %@", advertisementData);
        
        //connect with the proxy peripheral
        [central connectPeripheral:peripheral options:nil];
    }
}

//invoked when connection is established with corresponding peripheral
- (void)centralManager:(CBCentralManager *)central
  didConnectPeripheral:(CBPeripheral *)peripheral{
    //provisioning
    if (isProvisioning) {
        NSLog(@"connected peripheral: %@", peripheral);
        
        //make self as delegate
        _targetPeripheral.delegate = self;
        
        //create a UUID and add it into the array in order to discover the specified service
        //in this case, we do the search for mesh Proxy Service
        NSArray *serviceArray = [NSArray array];
        serviceArray = [NSArray arrayWithObject:[CBUUID UUIDWithString:_Provisioner.meshProvServiceUUIDString ]];
        [peripheral discoverServices:serviceArray];
    }
    else{
        //model configuration
        NSLog(@"connected peripheral: %@", peripheral);
        
        //disconnectButtion can be visible here when connection is established
        //[_disconnectButton setHidden:false];
        
        //make self as delegate
        _targetProxyPeripheral.delegate = self;
        
        //create a UUID and add it into the array in order to discover the specified service
        //in this case, we do the search for mesh Proxy Service
        NSArray *serviceArray = [NSArray array];
        serviceArray = [NSArray arrayWithObject:[CBUUID UUIDWithString:_proxy.meshProxyServiceUUIDString ]];
        [peripheral discoverServices:serviceArray];
    }
}

#pragma mark - CBPeripheralDelegate protocol

//invoked when discover the target service
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"service count: %lu", peripheral.services.count);
    
    // Loop through the newly filled peripheral.services array, just in case there's more than one.
    for (CBService *service in peripheral.services) {
        [peripheral discoverCharacteristics:nil forService:service];
    }
}

//invoked when discover the target characteristic
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (isProvisioning) {
        for (CBCharacteristic *characteristic in service.characteristics ) {
            NSLog(@"discover char 0x%@", characteristic.UUID);
            
            [peripheral discoverDescriptorsForCharacteristic:characteristic];
            //[peripheral readValueForCharacteristic:characteristic];
            NSLog(@"maximumLen with = %lu, without %lu ",
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithResponse],
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithoutResponse]);
            
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataInCharacteristicUUIDString]]) {
                _provDataIn = characteristic;
            }
            
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataOutCharacteristicUUIDString]]) {
                _provDataOut = characteristic;
            }
        }
    }
    else{
        //model configuration
        for (CBCharacteristic *characteristic in service.characteristics) {
            NSLog(@"discover char 0x%@", characteristic.UUID);
            
            [peripheral discoverDescriptorsForCharacteristic:characteristic];
            [peripheral readValueForCharacteristic:characteristic];
            NSLog(@"maximumLen with = %lu, without %lu ",
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithResponse],
                  (unsigned long)[peripheral maximumWriteValueLengthForType:CBCharacteristicWriteWithoutResponse]);
            
            
            
            if ( [characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataInCharacteristicUUIDString ]]){
                _proxyDataIn = characteristic;
            }
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString ]]){
                _proxyDataOut = characteristic;
            }
        }
    }
    
}

//invoked when discover target discriptor in this characteristic
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    
    for ( CBDescriptor *descriptor in characteristic.descriptors ) {
        NSLog(@"descriptor: %@", descriptor);
        
        //enable notification
        [peripheral setNotifyValue:true forCharacteristic:characteristic];
    }
}

//invoked when enable notification is sucessful
-(void) peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    
    if (nil == error) {
        NSLog(@"notification enabled.");
        if (isProvisioning) {
            [_targetPeripheral writeValue:[_Provisioner provInvitation]
                        forCharacteristic:_provDataIn
                                     type:CBCharacteristicWriteWithoutResponse];
        }
        
    }
    else{
        NSLog(@"notification disable.");
    }
}

//retrieve characteristic's value from server, invoked when new data packet is received
//parser data here
- (void)peripheral:(CBPeripheral *)peripheral
didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error{
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_Provisioner.meshProvDataOutCharacteristicUUIDString]] && characteristic.isNotifying ) {
        NSLog(@"prov char: %@", characteristic);
        [_Provisioner provPDUParser:_targetPeripheral
                         dataInChar:_provDataIn
                        dataOutChar:_provDataOut];
    }
    
    if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:_proxy.meshProxyDataOutCharacteristicUUIDString]] && characteristic.isNotifying ) {
        NSLog(@"proxy char: %@", characteristic);
        [_proxy proxyPDUParser:_targetProxyPeripheral
                    dataInChar:_proxyDataIn
                   dataOutChar:_proxyDataOut];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

@end
