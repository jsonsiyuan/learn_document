//
//  ProvisioningViewController.h
//  meshDemo
//
//  Created by RenKai on 2018/12/19.
//  Copyright © 2019 Bluetooth SIG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "MainViewController.h"

@protocol ProvisioningViewControllerDelegate <NSObject>

@required
- (void)dataFromController:(NSData *)data;

@end

@interface ProvisioningViewController : UIViewController

@property (nonatomic, retain) NSData *devKey;
@property (nonatomic, weak) id<ProvisioningViewControllerDelegate> delegate;

@end

