//
//  AppDelegate.h
//  BLE_Application
//
//  Created by Matchbox on 18/02/2014.
//  Copyright (c) 2014 Matchbox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
