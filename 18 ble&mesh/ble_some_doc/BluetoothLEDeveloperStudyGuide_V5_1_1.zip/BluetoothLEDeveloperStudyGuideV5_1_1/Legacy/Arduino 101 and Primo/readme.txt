Folders:

BLE - contains the standard, unmodified example sketches from the Nordic Semiconductors SDK

Solutions - contains the full solutions for the Arduino lab