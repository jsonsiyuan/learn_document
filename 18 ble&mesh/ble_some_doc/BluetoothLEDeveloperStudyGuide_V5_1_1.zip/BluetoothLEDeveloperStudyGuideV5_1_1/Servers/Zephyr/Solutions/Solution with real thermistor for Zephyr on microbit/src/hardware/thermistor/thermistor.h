void thermistor_init();
float readTemperature();
u16_t get_sensor_reading();
u16_t simulate_sensor_reading();

// adc
u16_t get_sensor_reading();