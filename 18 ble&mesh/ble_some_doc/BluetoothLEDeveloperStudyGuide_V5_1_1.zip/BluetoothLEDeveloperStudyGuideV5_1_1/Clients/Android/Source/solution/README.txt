To use the solution code, create a new Android Studio project using the name "Bdsk" and Company domain "bluetooth.com". When the project has been created and successfully built, replace the contents of the folder Bdsk\app\src\main with the contents of the Bluetooth Developer Starter Kit folder "Android\Source\solution" (except for this readme file).

You'll probably need to clean the project after copying the solution files in and then rebuild.

If you have problems, create the project again and then copy the java files first and attempt to build, then the resource files, one folder at a time, building at each step and finally, update the manifest to match the one provided in the solution.